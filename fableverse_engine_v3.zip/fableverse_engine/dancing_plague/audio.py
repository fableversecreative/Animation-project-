import numpy as np, wave, math, random
SR=44100; DUR=59.95; N=int(SR*DUR)
rnd=np.random.default_rng(7)
def tt(d): return np.arange(int(SR*d))/SR
def env(n,a=0.005,r=0.1):
    e=np.ones(n); na=max(1,int(a*SR)); nr=max(1,int(r*SR))
    e[:na]=np.linspace(0,1,na); e[-nr:]*=np.linspace(1,0,nr); return e
def lp(x,k):
    k=max(1,int(k)); return np.convolve(x,np.ones(k)/k,'same')
def place(buf,x,t,g=1.0,pan=0.0):
    i=int(t*SR); 
    if i>=len(buf): return
    x=x[:len(buf)-i]
    l=g*math.cos((pan+1)*math.pi/4); r=g*math.sin((pan+1)*math.pi/4)
    buf[i:i+len(x),0]+=x*l*1.41; buf[i:i+len(x),1]+=x*r*1.41
noise=lambda d: rnd.standard_normal(int(SR*d))
def whoosh(d=0.5,up=True):
    n=noise(d); t=tt(d); e=np.sin(np.pi*t/d)**2
    out=np.zeros_like(n); 
    for k,w in ((3,0.5),(9,0.3),(30,0.2)): out+=lp(n,k)*w
    return out*e*0.6
def riser(d=0.6):
    t=tt(d); return (lp(noise(d),4)*0.4+0.2*np.sin(2*np.pi*(300+900*t/d)*t))*(t/d)**2
def impact(d=0.9,f=55):
    t=tt(d); sub=np.sin(2*np.pi*(f*np.exp(-t*3))*t*2)*np.exp(-t*5)
    click=noise(d)*np.exp(-t*80)*0.6; crunch=lp(noise(d),3)*np.exp(-t*14)*0.4
    return sub+click+crunch
def pop(f=600):
    t=tt(0.12); return np.sin(2*np.pi*f*t*(1+3*np.exp(-t*40)))*np.exp(-t*35)
def boing():
    t=tt(0.5); return np.sin(2*np.pi*(180+120*np.sin(2*np.pi*9*t))*t)*np.exp(-t*6)*0.8
def ting(f=1800):
    t=tt(1.0); x=sum(np.sin(2*np.pi*f*m*t+ 2*np.sin(2*np.pi*f*1.4*t)*np.exp(-t*6))*a for m,a in ((1,1),(2.01,0.4),(3.03,0.2)))
    return x*np.exp(-t*5)*0.5
def tick(): t=tt(0.03); return np.sin(2*np.pi*2400*t)*np.exp(-t*200)*0.6
def thunk(): t=tt(0.25); return (np.sin(2*np.pi*110*t)*np.exp(-t*25)+lp(noise(0.25),6)*np.exp(-t*30)*0.6)
def clang():
    t=tt(0.9); x=sum(np.sin(2*np.pi*f*t)*a for f,a in ((523,1),(1187,.6),(1789,.5),(2650,.3)))
    return (x*np.exp(-t*6)*0.5+noise(0.9)*np.exp(-t*60)*0.5)
def crash():
    t=tt(1.0); x=lp(noise(1.0),2)*np.exp(-t*5)
    for k in range(6): 
        i=int(rnd.uniform(0,0.4)*SR); x[i:i+3000]+=thunk()[:3000][:len(x[i:i+3000])]*0.8
    return x
def chomp(): t=tt(0.15); return lp(noise(0.15),5)*np.exp(-t*30)*np.sin(np.pi*t/0.15)
def scratch():
    t=tt(0.6); f=600+500*np.sin(2*np.pi*3*t); return (np.sin(2*np.pi*np.cumsum(f)/SR)*0.3+lp(noise(0.6),2)*0.5)*np.exp(-t*3)
def click(): t=tt(0.08); return noise(0.08)*np.exp(-t*120)+np.sin(2*np.pi*3000*t)*np.exp(-t*90)*0.5
def puff(): t=tt(0.6); return lp(noise(0.6),20)*np.exp(-t*6)*1.5
def rumble(d):
    t=tt(d); x=lp(noise(d),60)*3; 
    steps=np.zeros_like(t)
    for k in np.arange(0,d-0.06,0.07): 
        i=int((k+rnd.uniform(0,0.03))*SR); steps[i:i+800]+=np.exp(-np.arange(800)/120)*rnd.uniform(0.3,1)
    return (x*0.6+lp(steps,8)*1.5)*np.minimum(1,np.minimum(t/0.3,(d-t)/0.4))
def engine(d,f=38):
    t=tt(d); x=np.sign(np.sin(2*np.pi*f*t+0.3*np.sin(2*np.pi*7*t)))*0.3; return lp(x,10)*np.minimum(1,np.minimum(t/0.2,(d-t)/0.5))
def strain(): t=tt(0.7); return lp(noise(0.7),3)*np.sin(np.pi*t/0.7)*0.4
def ring():
    t=tt(0.8); x=np.sin(2*np.pi*1100*t)*(0.5+0.5*np.sign(np.sin(2*np.pi*20*t))); return x*0.4*np.minimum(1,(0.8-t)*8)
def chalk(): t=tt(0.12); return lp(noise(0.12),2)*np.sin(np.pi*t/0.12)*0.5
def cheer(d=1.6):
    t=tt(d); x=np.zeros_like(t)
    for k in range(10):
        f=rnd.uniform(500,900); x+=np.sin(2*np.pi*f*t*(1+0.05*np.sin(2*np.pi*rnd.uniform(5,9)*t)))*rnd.uniform(.2,.5)
    return x*np.minimum(1,np.minimum(t/0.1,(d-t)/0.6))*0.25
def splash(): t=tt(0.4); return lp(noise(0.4),2)*np.exp(-t*10)*0.6


sfx=np.zeros((N,2))
P=place
def tap():
    t=tt(0.09); return lp(lp(noise(0.09),4)*np.exp(-t*80)+np.sin(2*np.pi*160*t)*np.exp(-t*60),3)*0.7
def knock(): t=tt(0.15); return lp(np.sin(2*np.pi*200*t)*np.exp(-t*40)+lp(noise(0.15),6)*np.exp(-t*50)*0.6,3)
def bell(f=392,d=3.0):
    t=tt(d); x=sum(np.sin(2*np.pi*f*m*t)*a*np.exp(-t*k) for m,a,k in ((1,1,1.2),(2.0,0.4,1.8),(2.76,0.25,2.5)))
    return x*0.4
def soft_whoosh(d=0.4): return lp(whoosh(d),6)*0.7
def chime(f): t=tt(1.2); return (np.sin(2*np.pi*f*t)+0.3*np.sin(2*np.pi*2*f*t))*np.exp(-t*4)*0.3
def soft_pop(f=500): return lp(pop(f),3)*0.6
def stamp_hit():
    t=tt(0.5); return lp(np.sin(2*np.pi*(60+40*np.exp(-t*30))*t)*np.exp(-t*9)+lp(noise(0.5),8)*np.exp(-t*25)*0.5,3)
# hook: a few soft shoe taps, gentle swish into the crowd
for k in (0.15,0.47,0.79): P(sfx,tap(),k,0.7,0.1)
P(sfx,soft_whoosh(0.7),0.95,0.5)
P(sfx,soft_whoosh(0.5),7.2,0.5)          # flash back to July
P(sfx,chime(880),13.67,0.5); P(sfx,chime(660),14.84,0.5)   # no music / no reason
for i in range(3): P(sfx,chime(1320 if i%2 else 990),16.0+i*0.8,0.2)
for k in (20.55,20.7,20.85): P(sfx,soft_pop(620),k,0.5)
P(sfx,soft_pop(420),21.69,0.6)
P(sfx,stamp_hit(),31.66,0.6); P(sfx,lp(noise(0.9),5)*np.exp(-tt(0.9)*3)*0.25,31.75,0.5)   # hot blood + soft hiss
P(sfx,chime(1320),34.13,0.5)
for k in (35.75,36.2,36.65): P(sfx,knock(),k,0.6)
for k in (37.25,37.6,37.95): P(sfx,soft_pop(640),k,0.45)
P(sfx,soft_whoosh(0.35),42.2,0.6); P(sfx,knock(),42.3,0.9)       # sign flip + gavel
P(sfx,stamp_hit(),43.95,0.9); P(sfx,stamp_hit(),45.2,0.9)
P(sfx,bell(392,3.0),46.7,0.55)
P(sfx,chime(1760),51.0,0.5); P(sfx,chime(2200),51.15,0.4)
P(sfx,soft_whoosh(0.5),52.3,0.5)
for k in (55.3,55.6,55.9): P(sfx,chime(1100+rnd.uniform(-150,150)),k,0.25)
P(sfx,tap(),58.3,0.9); P(sfx,tap(),58.45,0.8)
# music: medieval jig in 6/8, ~ 112 dotted-quarter
mus=np.zeros((N,2))
e8=60/112/3   # eighth note in 6/8 at dotted-quarter 112
def lute(f,d=0.3):
    t=tt(d); return (np.sin(2*np.pi*f*t)+0.5*np.sin(2*np.pi*2*f*t)+0.25*np.sin(2*np.pi*3*f*t)+0.12*np.sin(2*np.pi*4*f*t))*np.exp(-t*9)
def recorder(f,d):
    t=tt(d); vib=1+0.006*np.sin(2*np.pi*5.5*t)
    x=np.sin(2*np.pi*f*vib*t)+0.15*np.sin(2*np.pi*2*f*vib*t)+lp(noise(d),3)*0.04
    return x*np.minimum(1,np.minimum(t/0.03,(d-t)/0.05))*0.5
def tabor(): t=tt(0.18); return (np.sin(2*np.pi*(140+60*np.exp(-t*30))*t)*np.exp(-t*18)+lp(noise(0.18),2)*np.exp(-t*35)*0.5)
D_=146.83; A_=220.0
roots=[D_,D_,155.56*0+130.81,A_]  # D D C A
scale={'D':587.33,'E':659.26,'F':698.46,'G':783.99,'A':880.0,'C':523.25,'d':293.66*2}
mel=['A','G','F','E','F','G','A','A','D','D','E','F', 'G','F','E','D','E','C','D','D','A','A','D','D']
def jig(a,b,dense=1.0,gain=1.0):
    k=0; t=a
    while t<b-0.01:
        bar=(k//6)%4; r=roots[bar]
        if k%3==0: P(mus,lp(tabor(),3),t,0.55*gain if k%6==0 else 0.35*gain)
        if k%3==0: P(mus,lute(r,0.35),t,0.6*gain,-0.3)
        if k%3!=0: P(mus,lute(r*1.5 if k%3==1 else r*2,0.25)*0.6,t,0.5*gain,-0.2)
        if dense>0.5:
            m=mel[k%24]
            P(mus,lp(recorder(scale[m],e8*0.95),5),t,0.32*gain,0.25)
        t+=e8; k+=1
jig(0.0,43.95)
# tape-stop into silence at 'banned music'
i0=int(43.55*SR); i1=int(43.95*SR); seg=mus[i0:i1].copy(); n=len(seg)
sp=np.linspace(1,0.15,n); pos=np.cumsum(sp); pos=pos/pos[-1]*(n-1)*0.6
for ch in range(2): mus[i0:i1,ch]=np.interp(pos,np.arange(n),seg[:,ch])*np.linspace(1,0,n)
mus[i1:]=0
# shrine choir pad + low drone
t=tt(6.0); pad=sum(np.sin(2*np.pi*f*t*(1+0.003*np.sin(2*np.pi*0.4*t+j)))*a for j,(f,a) in enumerate(((220,0.5),(277.18,0.35),(329.63,0.35),(440,0.2))))
pad=lp(pad,4)*np.minimum(1,np.minimum(t/0.8,(6.0-t)/1.0))*0.45
P(mus,pad,46.4,0.9)
# september: slow sparse lute
for k,f in enumerate([293.66,220,246.94,220,196,220]):
    P(mus,lute(f,0.8)*0.6,52.5+k*0.45,0.5)
# mystery: soft drone
t=tt(2.3); P(mus,np.sin(2*np.pi*110*t)*0.3*np.minimum(1,np.minimum(t/0.3,(2.3-t)/0.4)),55.2,0.8)
# party returns for the loop
jig(58.6,59.95,1.0,1.0)
def verb(x,dec=0.35,dl=(0.031,0.047,0.061,0.083)):
    y=x.copy()
    for d in dl:
        k=int(d*SR); z=np.zeros_like(x); z[k:]=x[:-k]*dec; y+=z
    return y
mus=verb(mus,0.25); sfx=verb(sfx,0.2)
def wr(fn,x):
    w=wave.open(fn,'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    x=x/ (np.abs(x).max()+1e-9)*0.9
    w.writeframes((x*32767).astype(np.int16).tobytes()); w.close()
wr('music.wav',mus); wr('sfx.wav',sfx)
print('ok')
