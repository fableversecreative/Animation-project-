import numpy as np, cv2, math, json, sys, os, random
from rig import *

W, H, FPS = 1080, 1920, 30
DUR = 59.95
NF = int(round(DUR * FPS))
S = float(os.environ.get('S', '0.3333333'))
OW, OH = int(round(W * S)), int(round(H * S))
MARG = 420

def rng(seed): return random.Random(seed)

# ---------------- backgrounds (cached, design coords + margin) ----------------
_bg = {}
def gradient(img, y0, y1, c0, c1):
    for y in range(max(0, y0), min(img.shape[0], y1)):
        t = (y - y0) / max(1, y1 - y0)
        img[y, :] = [int(lerp(c0[i], c1[i], t)) for i in range(3)]

BGOFF = {}
def bgimg(kind):
    if kind in _bg: return _bg[kind]
    if kind.endswith('_blur'):
        b = bgimg(kind[:-5]); k = int(28 * S) | 1
        BGOFF[kind] = BGOFF[kind[:-5]]
        _bg[kind] = cv2.GaussianBlur(b, (k, k), 0); return _bg[kind]
    field = kind in ('day', 'gold', 'dusk')
    mxl, mxr = (900, 3600) if field else (MARG, MARG)
    BGOFF[kind] = (mxl, MARG)
    bw, bh = int((W + mxl + mxr) * S), int((H + 2 * MARG) * S)
    img = np.zeros((bh, bw, 3), np.uint8)
    d = D(img, Aff(mxl * S, MARG * S, S))
    XL, XR = -mxl, W + mxr
    r = rng(hash(kind) % 1000)
    if kind in ('day', 'gold', 'dusk'):
        sky = {'day': (C('7fc4ef'), C('f3e6c4')), 'gold': (C('f2a65a'), C('ffe2a8')), 'dusk': (C('6a5fa8'), C('f6a26a'))}[kind]
        hz = 900
        gradient(img, 0, int((MARG + hz) * S), sky[0], sky[1])
        sx, sy = (760, 520) if kind == 'day' else (300, 760)
        sc_ = C('fff4c2') if kind == 'day' else C('ffd27a')
        for rr, a in ((260, 0.12), (170, 0.2)):
            ov = img.copy(); d2 = D(ov, d.M); d2.ell(sx, sy, rr, rr, sc_, None, 0)
            img[:] = cv2.addWeighted(ov, a, img, 1 - a, 0)
        d.ell(sx, sy, 90, 90, sc_, None, 0)
        # clouds
        for i in range(16):
            cx = r.uniform(XL, XR); cy = r.uniform(150, 600)
            for j in range(4):
                d.ell(cx + j * 60 - 90, cy + (0 if j % 3 else -25), 80, 46, shade(sky[1], 1.04) if kind != 'day' else C('ffffff'), None, 0)
        # far hills
        for layer, (col, base, amp) in enumerate(((C('9fb38a') if kind == 'day' else C('c98f6a'), hz - 60, 60), (C('7f9a6a') if kind == 'day' else C('a8755a'), hz - 15, 35))):
            xs = np.linspace(XL, XR, 160)
            ys = base - amp * (0.5 + 0.5 * np.sin(xs / 210 + layer * 2.1)) - 18 * np.sin(xs / 67 + layer)
            pts = np.concatenate([np.stack([xs, ys], 1), [[XR, hz + 40], [XL, hz + 40]]])
            d.poly(pts, col, None)
        # field
        fc0 = {'day': C('dda23a'), 'gold': C('df9536'), 'dusk': C('c07e3c')}[kind]
        fc1 = shade(fc0, 1.12)
        gradient(img, int((MARG + hz) * S), bh, shade(fc0, 0.92), fc1)
        # trees on horizon
        for i in range(30):
            tx = r.uniform(XL, XR); ty = hz + r.uniform(-4, 10); s_ = r.uniform(0.5, 1.0)
            d.tube([(tx, ty), (tx + 4, ty - 120 * s_)], 10 * s_, C('8a7a6a'), INK, 2)
            for j in range(4):
                d.ell(tx + r.uniform(-50, 50) * s_, ty - 130 * s_ + r.uniform(-30, 30) * s_, 50 * s_, 34 * s_, C('6d8c5a') if kind == 'day' else C('8a7a4a'), INK, 2)
        # farmhouse far right
        hx = 930
        for hx in (930, 2600, -700):
          d.poly([(hx, hz + 10), (hx + 150, hz + 10), (hx + 150, hz - 60), (hx, hz - 60)], C('e8dcc4'), INK, 3)
          d.poly([(hx - 15, hz - 60), (hx + 165, hz - 60), (hx + 75, hz - 115)], C('b0473c'), INK, 3)
          d.poly([(hx + 60, hz + 10), (hx + 90, hz + 10), (hx + 90, hz - 30), (hx + 60, hz - 30)], C('7a5530'), INK, 2)
        # far fence
        for i in range(int(XL / 60), int(XR / 60)):
            fx = i * 60
            d.line([(fx, hz + 30), (fx, hz - 5)], C('7a5a3a'), 4)
        d.line([(XL, hz + 5), (XR, hz + 5)], C('7a5a3a'), 3); d.line([(XL, hz + 18), (XR, hz + 18)], C('7a5a3a'), 3)
        # wheat: rows + ear glyphs with perspective
        for i in range(60):
            y = hz + 20 + (i / 60) ** 1.7 * (H + MARG - hz)
            d.line([(XL, y), (XR, y + r.uniform(-6, 6))], shade(fc0, r.choice((0.86, 1.1))), 3 + (y - hz) / 120)
        # cloud shadows
        ov = img.copy(); d3 = D(ov, d.M)
        for i in range(12):
            d3.ell(r.uniform(XL, XR), hz + r.uniform(150, 900), r.uniform(300, 600), r.uniform(60, 150), shade(fc0, 0.72), None, 0)
        img[:] = cv2.addWeighted(ov, 0.35, img, 0.65, 0)
        glyphs = []
        ng = int(13000 * (XR - XL) / 1920)
        for i in range(ng):
            y = hz + 22 + (r.random() ** 1.35) * (H + MARG - hz)
            glyphs.append((y, r.uniform(XL, XR), r.choice((0.74, 0.86, 1.0, 1.12, 1.22)), r.uniform(-0.25, 0.25)))
        glyphs.sort()
        for y, x, f_, sw in glyphs:
            sz = 0.12 + (y - hz) / 1000.0
            if sz > 0.32:
                wheat_ear(d, x, y, 120 * sz * 1.6, sw * 0.4, sz * 0.9, shade(fc0, f_), ink=(sz > 0.75), awn=(sz > 0.5))
            else:
                col = shade(fc0, f_)
                d.line([(x, y), (x + sw * 20 * sz, y - 70 * sz)], shade(col, 0.78), max(1.0, 3 * sz))
                for j in range(3):
                    d.ell(x + sw * 26 * sz + (j % 2 * 2 - 1) * 3 * sz, y - (66 + j * 12) * sz, 4 * sz + 0.8, 7 * sz + 1, shade(col, 1.0 if j % 2 else 0.88), None, 0, ang=sw * 0.5 + (j % 2 * 2 - 1) * 0.4, n=8)
                d.line([(x + sw * 26 * sz, y - 100 * sz), (x + sw * 30 * sz, y - 128 * sz)], shade(col, 1.15), max(0.8, 1.2 * sz))
    elif kind == 'tent':
        gradient(img, 0, bh, C('d9c7a0'), C('bfa77a'))
        for i in range(-3, 14):
            x = i * 110; d.line([(x, -MARG), (x + 40, H + MARG)], C('c7b386'), 8)
        d.poly([(-MARG, 1480), (W + MARG, 1480), (W + MARG, H + MARG), (-MARG, H + MARG)], C('8a6a44'), INK, 5)
        for i in range(-3, 16): d.line([(i * 90, 1480), (i * 90 - 60, H + MARG)], C('7a5c38'), 4)
    elif kind == 'house':
        gradient(img, 0, bh, C('c9935e'), C('a8743f'))
        for i in range(-6, 30):
            y = i * 80; d.line([(-MARG, y), (W + MARG, y)], C('8e5f33'), 5)
        d.poly([(120, 300), (560, 300), (560, 760), (120, 760)], C('9fd3ec'), INK, 8)
        d.line([(340, 300), (340, 760)], INK, 8); d.line([(120, 530), (560, 530)], INK, 8)
        d.poly([(-MARG, 1500), (W + MARG, 1500), (W + MARG, H + MARG), (-MARG, H + MARG)], C('6b4a2e'), INK, 5)
    elif kind == 'blue':
        img[:] = C('1f4f8a')
        for i in range(-10, 40):
            d.line([(i * 60, -MARG), (i * 60, H + MARG)], C('3a6ca8'), 2)
            d.line([(-MARG, i * 60), (W + MARG, i * 60)], C('3a6ca8'), 2)
    _bg[kind] = img
    return img

VIG = None
def vignette():
    global VIG
    if VIG is None:
        y, x = np.mgrid[0:OH, 0:OW]
        r = np.sqrt(((x - OW / 2) / (OW / 2)) ** 2 + ((y - OH / 2) / (OH / 2)) ** 2)
        VIG = (1 - 0.28 * np.clip(r - 0.55, 0, 1) ** 1.5)[..., None].astype(np.float32)
    return VIG

# ---------------- camera ----------------
def cam_keys(keys, t):
    """keys: list of (time, cx, cy, z, rot). smootherstep between."""
    if t <= keys[0][0]: k = keys[0]; return k[1:]
    for a, b in zip(keys, keys[1:]):
        if t <= b[0]:
            u = (t - a[0]) / max(1e-6, b[0] - a[0])
            e = b[5] if len(b) > 5 else 's'
            u = smooth(u) if e == 's' else eout(u) if e == 'o' else u
            return tuple(lerp(a[i], b[i], u) for i in range(1, 5))
    k = keys[-1]; return k[1:5]

def camM(cx, cy, z, rot, shake=(0, 0)):
    R = Aff(0, 0, z, rot)
    T = Aff(-cx, -cy)
    C2 = Aff(W / 2 + shake[0], H / 2 + shake[1])
    return Aff(0, 0, S) @ C2 @ R @ T

def shake_at(t, kicks, amp=14):
    sx = sy = 0
    for k in kicks:
        dt = t - k
        if 0 <= dt < 0.25:
            a = amp * (1 - dt / 0.25)
            sx += a * math.sin(dt * 90); sy += a * math.cos(dt * 70)
    return sx, sy

# ---------------- HUD helpers (screen design coords) ----------------
def hud_text(img, txt, x, y, size, rgb=(255, 255, 255), scale=1.0, alpha=1.0, rot=0.0, font=None):
    spr = text_sprite(txt, int(size * S), rgb, 0.14, font)
    blit(img, spr, x * S, y * S, scale, alpha, rot)

def pop(t, t0, dur=0.25):
    if t < t0: return 0.0
    return back((t - t0) / dur, 2.2)

def tag(img, txt, t, t0, t1, y=170):
    if t < t0 or t > t1: return
    a = clamp((t - t0) / 0.15) * clamp((t1 - t) / 0.2)
    sc = 0.6 + 0.4 * pop(t, t0, 0.3)
    hd = D(img, Aff(0, 0, S))
    w = len(txt) * 30 + 70
    ov = img.copy(); D(ov, Aff(0, 0, S)).poly([(540 - w / 2 * sc, y - 42 * sc), (540 + w / 2 * sc, y - 42 * sc), (540 + w / 2 * sc, y + 42 * sc), (540 - w / 2 * sc, y + 42 * sc)], C('2a1a2a'), None)
    img[:] = cv2.addWeighted(ov, 0.6 * a, img, 1 - 0.6 * a, 0)
    hud_text(img, txt, 540, y, 54, (255, 214, 64), sc, a)

def board(img, t, t0, army, emus, flip_t=None, y=330, x=540):
    """wooden scoreboard"""
    if t < t0: return
    sc = pop(t, t0, 0.35)
    d = D(img, Aff(0, 0, S)).sub(Aff(x, y, sc))
    d.poly([(-300, -95), (300, -95), (300, 95), (-300, 95)], C('8a5a32'), INK, 7)
    for i in range(-2, 3): d.line([(-296, i * 38), (296, i * 38)], C('734a28'), 3)
    d.poly([(-6, -80), (6, -80), (6, 80), (-6, 80)], C('5a3a20'), None)
    hud_text(img, 'ARMY', x - 150 * sc, y - 45 * sc, 46, (255, 240, 220), sc)
    hud_text(img, 'EMUS', x + 150 * sc, y - 45 * sc, 46, (255, 240, 220), sc)
    e = emus
    sp = 1.0
    if flip_t is not None and t >= flip_t:
        sp = 0.7 + 0.3 * back((t - flip_t) / 0.3)
    hud_text(img, str(army), x - 150 * sc, y + 35 * sc, 84, (255, 255, 255), sc)
    hud_text(img, str(e), x + 150 * sc, y + 35 * sc, 84, (255, 214, 64), sc * sp)

def counter(img, t, t0, t1, v0, v1, label, y=330, x=540, color=(255, 214, 64)):
    if t < t0: return
    u = eout((t - t0) / max(0.01, t1 - t0))
    v = int(round(lerp(v0, v1, u)))
    sc = pop(t, t0, 0.3)
    d = D(img, Aff(0, 0, S)).sub(Aff(x, y, sc))
    d.poly([(-280, -100), (280, -100), (280, 100), (-280, 100)], C('2a1a2a'), C('ffd640'), 6)
    hud_text(img, label, x, y - 50 * sc, 40, (255, 255, 255), sc)
    hud_text(img, f'{v:,}', x, y + 30 * sc, 90, color, sc)

def world_text(d, txt, x, y, size, rgb):
    q = d.tp([(x, y)])[0]
    spr = text_sprite(txt, max(6, int(size * d.k)), rgb, 0.0)
    blit(d.img, spr, q[0], q[1])

# ---------------- crowd helper ----------------
def herd(d, t, n, seed, x0, x1, y0, y1, speed=0.0, flip=1, run=1.0, scale_base=0.55, neckf=0.6, wrap=None, faces=None):
    r = rng(seed)
    items = []
    for i in range(n):
        x = r.uniform(x0, x1); y = r.uniform(y0, y1); ph = r.uniform(0, 6.28)
        items.append((y, x, ph, i))
    items.sort()
    for y, x, ph, i in items:
        sc = scale_base * (0.45 + 0.55 * (y - y0) / max(1, y1 - y0)) * 1.0 + 0.0
        xx = x + speed * t * flip * (0.8 + 0.4 * ((i * 37) % 10) / 10)
        if wrap: xx = (xx - wrap[0]) % (wrap[1] - wrap[0]) + wrap[0]
        if run > 0.6: trail(d, xx, y, t, flip, sc, i, 0.8)
        emu(d, xx, y, sc, flip, run, ph + t * 14 * (0.5 + run * 0.5), neckf, face='open')

def dust(d, x, y, t, t0, n=6, size=40, seed=1):
    if t < t0 or t > t0 + 0.9: return
    u = (t - t0) / 0.9; r = rng(seed)
    for i in range(n):
        a = r.uniform(math.pi, 2 * math.pi); dd = 30 + u * r.uniform(60, 140)
        rr = size * (0.5 + u) * (1 - u * 0.7)
        d.ell(x + math.cos(a) * dd, y + math.sin(a) * dd * 0.5, rr, rr * 0.8, C('e2cfa6'), INK, 2)

def speedlines(d, t, y0, y1, n=14, seed=3, dirn=-1):
    r = rng(seed)
    for i in range(n):
        y = r.uniform(y0, y1); x = ((r.uniform(0, 1400) + dirn * t * 2600) % 1600) - 260
        d.line([(x, y), (x + 220 * -dirn, y)], C('fff6dc'), 6)

def bullets_row(d, x, y, n, sc=1.0, t=0, t0=0, step=0.08):
    for i in range(n):
        if t < t0 + i * step: continue
        p = pop(t, t0 + i * step, 0.2)
        bx = x + i * 70 * sc
        L = d.sub(Aff(bx, y, sc * p))
        L.poly([(-14, 0), (14, 0), (14, -60), (-14, -60)], C('d9a640'), INK, 4)
        L.poly([(-14, -60), (14, -60), (8, -88), (0, -96), (-8, -88)], C('b87333'), INK, 4)

def crate(d, x, y, sc=1.0, label='', empty=False, tilt=0.0):
    L = d.sub(Aff(x, y, sc, tilt))
    L.poly([(-110, 0), (110, 0), (110, -140), (-110, -140)], C('a87444'), INK, 5)
    for k in (-35, -70, -105): L.line([(-110, k), (110, k)], C('8a5a32'), 3)
    L.line([(-110, 0), (110, -140)], C('7a4e2a'), 6)
    if not empty:
        for i in range(6):
            L.poly([(-90 + i * 32, -140), (-70 + i * 32, -140), (-75 + i * 32, -175), (-85 + i * 32, -175)], C('d9a640'), INK, 3)

# ---------------- shots ----------------
SH = []
def shot(t0, t1, bg=None, light=None):
    def deco(fn):
        SH.append(dict(t0=t0, t1=t1, fn=fn, bg=bg)); return fn
    return deco

def emu_eye_world(x, y, sc, flip=1, **kw):
    dummy = np.zeros((4, 4, 3), np.uint8)
    q = emu(D(dummy, Aff()), x, y, sc, flip, **kw)
    return q

HERO = dict(x=470, y=1650, sc=2.3)

def draw_hero(d, t, face='open', mouth=None, look=(0, 0), tilt=0.0, wink=False, blink=False):
    return emu(d, HERO['x'], HERO['y'], HERO['sc'], 1, 0.0, 0, 0.0, face=face, mouth=mouth, tilt=tilt,
               bob=math.sin(t * 2.2) * 4, look=look, wink=wink, blink=blink, star=True)

EYE = None
def hero_eye():
    global EYE
    if EYE is None: EYE = emu_eye_world(HERO['x'], HERO['y'], HERO['sc'])
    return EYE

def blinkat(t, times):
    return any(0 <= t - k < 0.12 for k in times)

# ================= DANCING PLAGUE SHOTS =================
GROUND = 1350
_orig_bgimg = bgimg
_SP = [(1250, 1960), (1080, 1720), (880, 1580), (990, 1420), (850, 1270), (780, 1140), (900, 1010), (770, 900), (695, 845)]
def _smooth_path(p, n=10):
    out = []
    for i in range(len(p) - 1):
        p0 = np.array(p[max(0, i - 1)], float); p1 = np.array(p[i], float); p2 = np.array(p[i + 1], float); p3 = np.array(p[min(len(p) - 1, i + 2)], float)
        for k in range(n):
            t_ = k / n
            out.append(tuple(0.5 * ((2 * p1) + (-p0 + p2) * t_ + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t_ ** 2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t_ ** 3)))
    out.append(tuple(p[-1]))
    return out
SHRINE_PATH_PTS = _smooth_path(_SP)
_cum = [0.0]
for i in range(len(SHRINE_PATH_PTS) - 1):
    _cum.append(_cum[-1] + math.hypot(SHRINE_PATH_PTS[i + 1][0] - SHRINE_PATH_PTS[i][0], SHRINE_PATH_PTS[i + 1][1] - SHRINE_PATH_PTS[i][1]))
def path_at(u):
    dist = clamp(u) * _cum[-1]
    i = max(0, min(len(_cum) - 2, int(np.searchsorted(_cum, dist)) - 1))
    f_ = (dist - _cum[i]) / max(1e-6, _cum[i + 1] - _cum[i])
    p, q = SHRINE_PATH_PTS[i], SHRINE_PATH_PTS[i + 1]
    return lerp(p[0], q[0], f_), lerp(p[1], q[1], f_), (1 if q[0] > p[0] else -1)

def _houses():
    r = rng(51)
    hs = []
    x = -700
    walls = ['f1e3c4', 'e9c9a8', 'f3d9a0', 'd9e3e6', 'efd1c8', 'e6dcc0']
    while x < 2400:
        w = r.choice((230, 250, 270, 300)); fl = r.choice((3, 3, 4))
        hs.append(dict(x=x, w=w, fl=fl, wall=C(r.choice(walls)), roof=C(r.choice(('a8452f', '8f3b2a', 'b9583a'))), seed=r.randint(0, 999)))
        x += w + r.choice((0, 0, 10))
    return hs
HOUSES = _houses()
WINDOWS = []
for h in HOUSES:
    for f_ in range(1, h['fl']):
        for k in (0.3, 0.7):
            WINDOWS.append((h['x'] + h['w'] * k, GROUND - 60 - f_ * 175 - 70))
DOOR_X = [h['x'] + h['w'] * 0.5 for h in HOUSES]
def near_windows(cx, n, fl=1):
    ys = sorted(set(round(w[1]) for w in WINDOWS), reverse=True)
    row = [i for i, w in enumerate(WINDOWS) if round(w[1]) == ys[fl - 1]]
    row.sort(key=lambda i: abs(WINDOWS[i][0] - cx))
    return row[:n]

def draw_house(d, h):
    x, w, fl = h['x'], h['w'], h['fl']
    top = GROUND - fl * 175
    beam = C('4a2f20')
    d.poly([(x, GROUND), (x + w, GROUND), (x + w, top), (x, top)], h['wall'], INK, 5)
    for f_ in range(fl + 1):
        y = GROUND - f_ * 175
        d.line([(x, y), (x + w, y)], beam, 10)
    for k in range(0, 5):
        px = x + k * w / 4
        d.line([(px, GROUND), (px, top)], beam, 8)
    rr = rng(h['seed'])
    for f_ in range(1, fl):
        y0 = GROUND - f_ * 175; y1 = y0 - 175
        for k in range(4):
            if rr.random() < 0.45:
                ax = x + k * w / 4; bx = ax + w / 4
                d.line([(ax, y0), (bx, y1)], beam, 6); d.line([(bx, y0), (ax, y1)], beam, 6)
    # gable roof
    d.poly([(x - 18, top), (x + w + 18, top), (x + w / 2, top - 220)], h['roof'], INK, 5)
    for k in range(1, 6):
        yy = top - k * 36; hw = (w / 2 + 18) * (1 - k * 36 / 220)
        d.line([(x + w / 2 - hw, yy), (x + w / 2 + hw, yy)], shade(h['roof'], 0.8), 3)
    d.poly([(x + w / 2 - 22, top - 70), (x + w / 2 + 22, top - 70), (x + w / 2 + 22, top - 120), (x + w / 2 - 22, top - 120)], C('cfe6ef'), INK, 4)
    # windows
    for f_ in range(1, fl):
        for k in (0.3, 0.7):
            cx = x + w * k; cy = GROUND - 60 - f_ * 175 - 70
            d.poly([(cx - 34, cy - 46), (cx + 34, cy - 46), (cx + 34, cy + 46), (cx - 34, cy + 46)], C('2c3440'), INK, 4)
            d.line([(cx, cy - 46), (cx, cy + 46)], C('6a4a30'), 4); d.line([(cx - 34, cy), (cx + 34, cy)], C('6a4a30'), 4)
            d.poly([(cx - 58, cy - 48), (cx - 36, cy - 48), (cx - 36, cy + 48), (cx - 58, cy + 48)], C('3f6b4a'), INK, 3)
            d.poly([(cx + 36, cy - 48), (cx + 58, cy - 48), (cx + 58, cy + 48), (cx + 36, cy + 48)], C('3f6b4a'), INK, 3)
            d.poly([(cx - 40, cy + 48), (cx + 40, cy + 48), (cx + 36, cy + 64), (cx - 36, cy + 64)], C('7a5530'), INK, 3)
            for j in range(4): d.dot(cx - 27 + j * 18, cy + 46, 7, C('d9453a') if j % 2 else C('f2b440'))
    # door
    dx = x + w * 0.5
    d.poly(list(bez((dx - 48, GROUND), (dx - 48, GROUND - 190), (dx, GROUND - 190), 6)) + list(bez((dx, GROUND - 190), (dx + 48, GROUND - 190), (dx + 48, GROUND), 6)), C('7a4a2a'), INK, 5)
    for k in (-24, 0, 24): d.line([(dx + k, GROUND - 4), (dx + k, GROUND - 150)], C('5e3820'), 3)
    d.dot(dx + 30, GROUND - 80, 5, C('e0b84a'))

def bgimg(kind):
    if kind in _bg: return _bg[kind]
    if kind.endswith('_blur'):
        b = bgimg(kind[:-5]); k = int(28 * S) | 1
        BGOFF[kind] = BGOFF[kind[:-5]]
        _bg[kind] = cv2.GaussianBlur(b, (k, k), 0); return _bg[kind]
    if kind not in ('street', 'street_eve', 'shrine', 'hall'):
        return _orig_bgimg(kind)
    mxl, mxr = 700, 1300
    BGOFF[kind] = (mxl, MARG)
    bw, bh = int((W + mxl + mxr) * S), int((H + 2 * MARG) * S)
    img = np.zeros((bh, bw, 3), np.uint8)
    d = D(img, Aff(mxl * S, MARG * S, S))
    XL, XR = -mxl, W + mxr
    r = rng(7)
    if kind in ('street', 'street_eve'):
        sky = (C('86c3ea'), C('f6e6c6')) if kind == 'street' else (C('5d5aa0'), C('f4a565'))
        gradient(img, 0, int((MARG + 900) * S), sky[0], sky[1])
        for i in range(10):
            cx = r.uniform(XL, XR); cy = r.uniform(100, 600)
            for j in range(4): d.ell(cx + j * 60 - 90, cy + (0 if j % 3 else -25), 80, 44, C('ffffff') if kind == 'street' else C('f7c9a0'), None, 0)
        # back rooftops for depth
        for i in range(-8, 30):
            bx = i * 160 + (i % 3) * 30; bh_ = 700 + (i * 37 % 5) * 40
            d.poly([(bx, GROUND - 420), (bx + 170, GROUND - 420), (bx + 170, GROUND - bh_), (bx, GROUND - bh_)], shade(C('d9c7a8'), 0.95 if kind == 'street' else 0.8), None)
            d.poly([(bx - 10, GROUND - bh_), (bx + 180, GROUND - bh_), (bx + 85, GROUND - bh_ - 120)], shade(C('b9785a'), 0.95 if kind == 'street' else 0.8), None)
        # cathedral (bigger)
        sp = C('c98a7a'); spd = shade(sp, 0.8)
        d.poly([(560, 1100), (860, 1100), (860, 420), (560, 420)], sp, INK, 5)
        d.ell(710, 620, 80, 80, C('8fb6d8'), INK, 5)
        for k in range(8): a_ = k * math.pi / 4; d.line([(710, 620), (710 + 78 * math.cos(a_), 620 + 78 * math.sin(a_))], spd, 4)
        for k in range(5): d.poly([(580 + k * 56, 900), (610 + k * 56, 900), (610 + k * 56, 760), (580 + k * 56, 760)], spd, INK, 3)
        d.poly([(600, 420), (820, 420), (820, 260), (600, 260)], sp, INK, 5)
        d.poly([(580, 260), (840, 260), (710, -180)], sp, INK, 5)
        for k in range(1, 9): d.line([(710 - k * 13, -180 + k * 50), (710 + k * 13, -180 + k * 50)], spd, 4)
        d.poly([(700, -180), (720, -180), (710, -240)], C('e0b84a'), INK, 3)
        for h in HOUSES: draw_house(d, h)
        # bunting strung between houses
        cols = [C('d9453a'), C('f2b440'), C('3f6fb8'), C('f6f1e6'), C('5f8a4a')]
        for row, yy in enumerate((GROUND - 470, GROUND - 640)):
            pts = []
            for i in range(-6, 26):
                xa = i * 140 - 30 * row; xb = xa + 140
                for k in range(7):
                    u_ = k / 6; px = lerp(xa, xb, u_); py = yy + math.sin(u_ * math.pi) * 40
                    pts.append((px, py))
            d.line(pts, C('4a2f20'), 3)
            for j in range(0, len(pts) - 1, 2):
                (px, py), (qx, qy) = pts[j], pts[j + 1]
                d.poly([(px, py), (qx, qy), ((px + qx) / 2, (py + qy) / 2 + 34)], cols[(j // 2 + row) % 5], INK, 2)
        # market stalls between doorways (away from the main doors)
        for hi in (0, 1, 7, 8, 9):
            if hi >= len(HOUSES) - 1: continue
            sx = HOUSES[hi]['x'] + HOUSES[hi]['w']
            d.poly([(sx - 110, GROUND + 10), (sx + 110, GROUND + 10), (sx + 110, GROUND - 90), (sx - 110, GROUND - 90)], C('8a5a34'), INK, 4)
            for k in range(6):
                d.poly([(sx - 120 + k * 40, GROUND - 210), (sx - 80 + k * 40, GROUND - 210), (sx - 80 + k * 40 + 6, GROUND - 160), (sx - 120 + k * 40 - 6, GROUND - 160)], C('d9453a') if k % 2 else C('f6f1e6'), INK, 3)
            d.line([(sx - 110, GROUND - 160), (sx - 110, GROUND - 90)], C('5e3820'), 6); d.line([(sx + 110, GROUND - 160), (sx + 110, GROUND - 90)], C('5e3820'), 6)
            for k in range(5): d.ell(sx - 80 + k * 40, GROUND - 100, 16, 14, C(('e0a83a', 'c9542f', '8aa03a', 'd9822f', 'b8543c')[k]), INK, 2)
        # hanging lanterns
        for h in HOUSES:
            lx = h['x'] + 12
            d.line([(lx, GROUND - 330), (lx + 40, GROUND - 330), (lx + 40, GROUND - 300)], C('3a2a22'), 4)
            d.poly([(lx + 28, GROUND - 300), (lx + 52, GROUND - 300), (lx + 56, GROUND - 260), (lx + 24, GROUND - 260)], C('f6d27a'), INK, 3)
        # cobbles
        gradient(img, int((MARG + GROUND) * S), bh, C('a89c8a'), C('c9bba4'))
        for row in range(42):
            y = GROUND + 8 + (row / 42) ** 1.4 * (H + MARG - GROUND)
            sz = 0.25 + (y - GROUND) / 650
            off = (row % 2) * 30 * sz
            x = XL + off
            while x < XR:
                cw = r.uniform(48, 64) * sz
                col = shade(C('b8ab95'), r.choice((0.86, 0.94, 1.02, 1.08)))
                d.ell(x, y, cw * 0.48, cw * 0.24, col, shade(C('8a7e6c'), 1.0), max(1.2, 2.5 * sz))
                x += cw
        d.line([(XL, GROUND + 4), (XR, GROUND + 4)], C('7a6e5c'), 8)
    elif kind == 'shrine':
        gradient(img, 0, int((MARG + 1300) * S), C('9cc7e6'), C('f6e2c0'))
        for i in range(8):
            cx = r.uniform(XL, XR); cy = r.uniform(100, 500)
            for j in range(4): d.ell(cx + j * 60 - 90, cy, 80, 40, C('ffffff'), None, 0)
        xs = np.linspace(XL, XR, 120)
        for layer, (col, base, amp) in enumerate(((C('9fb38a'), 860, 90), (C('7f9a5a'), 980, 60))):
            ys = base - amp * (0.5 + 0.5 * np.sin(xs / 260 + layer * 1.7)) - 20 * np.sin(xs / 90 + layer)
            d.poly(np.concatenate([np.stack([xs, ys], 1), [[XR, H + MARG], [XL, H + MARG]]]), col, None)
        # soft rolling hill with a chapel on top (no hard outline, layered shading)
        def hy(x_, h=520, s=560): return 1320 - h * math.exp(-((x_ - 640) / s) ** 2)
        xs_ = np.linspace(XL, XR, 200)
        for k, (col, dh) in enumerate(((C('6f9a4c'), 0), (C('7caa55'), -40), (C('89b75f'), -110), (C('96c268'), -220))):
            pts = [(x_, hy(x_, 520 + dh * 0.0, 560) + (k * 30 if k else 0) + (0 if k == 0 else 0)) for x_ in xs_]
            if k == 0:
                d.poly(pts + [(XR, H + MARG), (XL, H + MARG)], col, None)
            else:
                band = [(x_, max(y_, hy(x_) + k * 26)) for x_, y_ in pts]
                d.poly([(x_, hy(x_) + k * 30) for x_ in xs_ if hy(x_) + k * 30 < 1300] + [(x_, 1300) for x_ in xs_[::-1] if hy(x_) + k * 30 < 1300], col, None)
        d.line([(x_, hy(x_)) for x_ in xs_], shade(C('6f9a4c'), 0.85), 3)
        # bushes, rocks and flowers on the hill
        for i in range(26):
            x_ = r.uniform(200, 1080); y_ = hy(x_) + r.uniform(30, 420)
            if abs(x_ - 760) < 90 and y_ < 1250: continue
            s_ = 0.6 + (y_ - 800) / 900
            for j in range(3): d.ell(x_ + (j - 1) * 22 * s_, y_ - (j % 2) * 14 * s_, 26 * s_, 20 * s_, C('5f8a40') if j % 2 else C('6c9a48'), INK, 2)
        for i in range(10):
            x_ = r.uniform(250, 1050); y_ = hy(x_) + r.uniform(40, 400)
            d.ell(x_, y_, 18, 11, C('b8b0a0'), INK, 2)
        for i in range(140):
            x_ = r.uniform(150, 1150); y_ = hy(x_) + r.uniform(20, 480)
            d.dot(x_, y_, 3.5, C(r.choice(('fff1f0', 'f2d14a', 'e87a9a', 'ffffff'))))
        cx_, by = 640, 800
        stone = C('e6dcc6'); stone_d = shade(stone, 0.82)
        # bell tower
        d.poly([(cx_ - 230, by), (cx_ - 120, by), (cx_ - 120, by - 400), (cx_ - 230, by - 400)], stone, INK, 5)
        d.poly(list(bez((cx_ - 205, by - 300), (cx_ - 205, by - 370), (cx_ - 175, by - 370), 5)) + list(bez((cx_ - 175, by - 370), (cx_ - 145, by - 370), (cx_ - 145, by - 300), 5)), C('3a2a22'), INK, 4)
        d.ell(cx_ - 175, by - 322, 18, 20, C('e0b84a'), INK, 3)
        d.poly([(cx_ - 245, by - 400), (cx_ - 105, by - 400), (cx_ - 175, by - 560)], C('8f3b2a'), INK, 5)
        d.line([(cx_ - 175, by - 560), (cx_ - 175, by - 640)], C('e0b84a'), 8); d.line([(cx_ - 200, by - 612), (cx_ - 150, by - 612)], C('e0b84a'), 8)
        # nave
        d.poly([(cx_ - 120, by), (cx_ + 230, by), (cx_ + 230, by - 240), (cx_ - 120, by - 240)], stone, INK, 5)
        for k in range(1, 6): d.line([(cx_ - 118, by - k * 40), (cx_ + 228, by - k * 40)], stone_d, 2)
        d.poly([(cx_ - 140, by - 240), (cx_ + 250, by - 240), (cx_ + 55, by - 390)], C('8f3b2a'), INK, 5)
        for k in range(1, 4): yy = by - 240 - k * 37; hw_ = 195 * (1 - k * 37 / 150); d.line([(cx_ + 55 - hw_, yy), (cx_ + 55 + hw_, yy)], shade(C('8f3b2a'), 0.8), 3)
        d.ell(cx_ + 55, by - 300, 34, 34, C('4a6fb8'), INK, 4)
        for k in range(8):
            a_ = k * math.pi / 4; d.poly([(cx_ + 55, by - 300), (cx_ + 55 + 32 * math.cos(a_), by - 300 + 32 * math.sin(a_)), (cx_ + 55 + 32 * math.cos(a_ + 0.785), by - 300 + 32 * math.sin(a_ + 0.785))], C(('d9453a', 'f2b440', '4a6fb8', '5f8a4a')[k % 4]), None)
        d.dot(cx_ + 55, by - 300, 8, C('fff2c0'))
        d.poly(list(bez((cx_ + 15, by), (cx_ + 15, by - 150), (cx_ + 55, by - 150), 6)) + list(bez((cx_ + 55, by - 150), (cx_ + 95, by - 150), (cx_ + 95, by), 6)), C('7a4a2a'), INK, 5)
        for k in (-20, 0, 20): d.line([(cx_ + 55 + k, by - 4), (cx_ + 55 + k, by - 120)], C('5e3820'), 3)
        for wx_ in (cx_ - 70, cx_ + 175):
            d.poly(list(bez((wx_ - 18, by - 70), (wx_ - 18, by - 170), (wx_, by - 180), 5)) + list(bez((wx_, by - 180), (wx_ + 18, by - 170), (wx_ + 18, by - 70), 5)), C('f2b440'), INK, 4)
        for k in range(3):
            d.poly([(cx_ - 30 - k * 20, by + k * 22), (cx_ + 140 + k * 20, by + k * 22), (cx_ + 140 + k * 20, by + 22 + k * 22), (cx_ - 30 - k * 20, by + 22 + k * 22)], stone_d, INK, 3)
        for cx2 in (cx_ - 5, cx_ + 115):
            d.poly([(cx2 - 6, by - 6), (cx2 + 6, by - 6), (cx2 + 6, by - 40), (cx2 - 6, by - 40)], C('f6f1e6'), INK, 2)
            d.ell(cx2, by - 50, 6, 10, C('ffcf4a'), None, 0)
        # foreground meadow
        gradient(img, int((MARG + 1300) * S), bh, C('8aa05a'), C('9fb46a'))
        d.poly([(XL, 1300), (XR, 1300), (XR, H + MARG), (XL, H + MARG)], None, None, 0)
        for i in range(500):
            x = r.uniform(XL, XR); y = 1310 + r.random() ** 1.3 * (H + MARG - 1310); sz = 0.3 + (y - 1300) / 700
            d.line([(x, y), (x + r.uniform(-4, 4) * sz, y - 24 * sz)], shade(C('8aa05a'), r.choice((0.8, 1.15))), 3 * sz)
        for (tx, ty, s_) in ((-200, 1300, 1.2), (150, 1250, 0.9), (1100, 1280, 1.1), (1500, 1300, 1.3)):
            d.tube([(tx, ty), (tx + 4, ty - 220 * s_)], 22 * s_, C('6a4a30'), INK, 4)
            for j in range(5):
                d.ell(tx + r.uniform(-70, 70) * s_, ty - 260 * s_ + r.uniform(-50, 50) * s_, 80 * s_, 60 * s_, C(r.choice(('d9822f', 'c9542f', 'e0a83a'))), INK, 3)
        # winding dirt path up to the chapel door, edged with little stones
        pts_ = SHRINE_PATH_PTS
        w_ = [max(14, 70 * (0.25 + (y_ - 840) / 1120)) for _, y_ in pts_]
        for i in range(len(pts_) - 1):
            d.line([pts_[i], pts_[i + 1]], C('b39a6c'), w_[i] + 12)
        for i in range(len(pts_) - 1):
            d.line([pts_[i], pts_[i + 1]], C('dcc79c'), w_[i])
        for i in range(0, len(pts_), 3):
            x_, y_ = pts_[i]; s_ = w_[i] / 70
            d.ell(x_ - w_[i] / 2 - 6, y_, 8 * s_ + 2, 5 * s_ + 2, C('a8a090'), INK, 1.5); d.ell(x_ + w_[i] / 2 + 6, y_ + 3, 8 * s_ + 2, 5 * s_ + 2, C('a8a090'), INK, 1.5)
    elif kind == 'hall':
        gradient(img, 0, bh, C('8a5a34'), C('6e4426'))
        for i in range(-8, 30):
            x = i * 120; d.line([(x, -MARG), (x, 1500)], C('5e3a20'), 6)
        d.line([(XL, 700), (XR, 700)], C('5e3a20'), 12); d.line([(XL, 1100), (XR, 1100)], C('5e3a20'), 12)
        for bx in (160, 920):
            d.poly([(bx - 120, 220), (bx + 120, 220), (bx + 120, 760), (bx, 840), (bx - 120, 760)], C('b3262e'), INK, 6)
            d.poly([(bx - 70, 360), (bx + 70, 360), (bx + 70, 560), (bx, 640), (bx - 70, 560)], C('f2ead8'), INK, 5)
            d.poly([(bx - 70, 380), (bx - 50, 360), (bx + 70, 600), (bx + 50, 620)], C('b3262e'), None)
        d.poly([(XL, 1500), (XR, 1500), (XR, H + MARG), (XL, H + MARG)], C('6b4a2e'), INK, 5)
        for i in range(-10, 40): d.line([(i * 90, 1500), (i * 90 - 60, H + MARG)], C('5a3c24'), 4)
    _bg[kind] = img
    return img

def red_shoes_on(t):
    return True

TROF = dict(sc=1.7)
FOOT_ECU = (548, 1770)

def troffea(d, x, y, sc, t, energy=1.0, tired=0.0, face=None, mouth=None, shoes=None, flip=1, ph=0.0):
    dancer(d, x, y, sc, 'troffea', t, ph, 0, energy, tired, face, mouth, flip, shoes, style='star' if tired < 0.5 else 'bounce')

REDSHOE = C('d4232f')

FEM = ('peasant_w', 'peasant_w2', 'troffea')
def crowd(d, t, n, seed, x0, x1, y0, y1, energy=1.0, tired=0.0, scale=1.0, couples=True):
    r = rng(seed)
    outs = ['peasant_w', 'peasant_m', 'peasant_w2', 'peasant_m2', 'musician', 'peasant_w', 'peasant_m']
    items = []
    for _ in range(n):
        o = r.choice(outs)
        st = r.choice(('bounce', 'bounce', 'spin', 'kick', 'hold')) if o not in FEM else r.choice(('bounce', 'bounce', 'spin', 'hold'))
        items.append([r.uniform(y0, y1), r.uniform(x0, x1), r.uniform(0, 6.28), o, r.randint(0, 2), st, None])
    # pair up some neighbours into swinging couples
    if couples:
        items.sort(key=lambda it: it[1])
        for i in range(0, len(items) - 1, 5):
            a_, b_ = items[i], items[i + 1]
            cx = (a_[1] + b_[1]) / 2; cy = (a_[0] + b_[0]) / 2
            a_[6] = (cx, cy, 0.0); b_[6] = (cx, cy, math.pi)
    items.sort()
    for y, x, ph, o, v, st, cp in items:
        sc = scale * (0.55 + 0.6 * (y - y0) / max(1, y1 - y0))
        if cp is not None and energy > 0.3:
            cx, cy, off = cp
            ang = t * 2.6 + off + ph * 0.0
            x = cx + math.cos(ang) * 55 * sc; y = cy + math.sin(ang) * 14 * sc
            dancer(d, x, y, sc, o, t, ph, v, energy, tired, flip=1 if math.cos(ang) < 0 else -1, style='hold',
                   arms=((95, 85), (-60, 70)) if math.cos(ang) < 0 else ((60, 70), (-95, 85)))
        else:
            dancer(d, x, y, sc, o, t, ph, v, energy, tired, style=st)

def bg_crowd(d, t, x0, x1, y0, rows=3, energy=1.0, seed=5, gap=34):
    """dense far crowd: rows of bobbing heads with raised arms"""
    r = rng(seed)
    hats = [C('f6f1e6'), C('4f7a3a'), C('6a2e3e'), C('d8b84a'), C('2f6a3a'), None]
    bodies = [C('3f6fb8'), C('b8543c'), C('8a5a34'), C('5f8a4a'), C('4e6e8a'), C('d0453a')]
    for row in range(rows):
        y = y0 + row * 26; s_ = 0.42 + row * 0.08
        x = x0 + (row % 2) * gap * 0.5
        while x < x1:
            ph = r.uniform(0, 6.28); hc = r.choice(hats); bc = r.choice(bodies); sk = r.choice((C('f6d6ba'), C('f0c8a6'), C('dcae88')))
            b_ = abs(math.sin(t * 7.5 + ph)) * 10 * energy * s_
            hx, hy = x + math.sin(t * 3.7 + ph) * 4 * energy, y - b_
            arm = math.sin(t * 7.5 + ph) * 0.4 * energy
            d.line([(hx - 18 * s_, hy - 40 * s_), (hx - (34 + 10 * arm) * s_, hy - (110 + 20 * arm) * s_)], bc, 12 * s_)
            d.line([(hx + 18 * s_, hy - 40 * s_), (hx + (34 - 10 * arm) * s_, hy - (110 - 20 * arm) * s_)], bc, 12 * s_)
            d.ell(hx, hy - 20 * s_, 30 * s_, 40 * s_, bc, INK, 3 * s_)
            d.ell(hx, hy - 80 * s_, 26 * s_, 24 * s_, sk, INK, 3 * s_)
            if hc is not None: d.ell(hx, hy - 98 * s_, 27 * s_, 12 * s_, hc, INK, 3 * s_)
            x += gap * (0.8 + r.random() * 0.4)

# S1 hook 0-7.4: ECU on the tapping red shoe, pull back to a city dancing
@shot(0.0, 7.4, 'street')
def s1(t, lt):
    fx, fy = FOOT_ECU
    return [(0, fx, fy, 4.2, 0.04), (1.3, 540, 1420, 1.3, -0.02, 'o'), (5.2, 540, 1420, 1.25, 0.0), (5.5, 540, 1460, 1.42, 0.02, 'o'), (7.4, 540, 1470, 1.46, 0.02)], [5.3]
def s1_draw(d, t, lt):
    bg_crowd(d, t, -300, 1400, 1370, 3, 1.0, 5)
    crowd(d, t, 16, 3, -150, 1250, 1420, 1600, 1.0, 0, 0.95)
    e = 0.15 if lt < 1.0 else 1.0
    troffea(d, 520, 1800, TROF['sc'], t, energy=e, shoes=REDSHOE, face='closed' if lt < 1.0 else None, mouth='smile' if lt < 1.0 else None)
    crowd(d, t, 2, 8, -100, 260, 1880, 1950, 1.0, 0, 1.1); crowd(d, t, 2, 9, 820, 1180, 1880, 1950, 1.0, 0, 1.1)
def hud_s1(img, t, lt):
    a = 1.0 if lt < 6.9 else clamp((7.4 - lt) / 0.4)
    pul = 1 + 0.03 * math.sin(lt * 7)
    hud_text(img, '1518: A DANCING', 540, 250, 118, (255, 255, 255), pul, a)
    hud_text(img, 'PLAGUE?', 540, 400, 150, (255, 214, 64), pul, a)
SH[-1]['draw'] = s1_draw; SH[-1]['hud'] = hud_s1

# S2 one woman 7.4-10.45
@shot(7.4, 10.45, 'street')
def s2(t, lt):
    dx = DOOR_X[4]
    return [(0, dx, 1150, 1.6, 0.0), (3.05, dx, 1170, 1.75, 0.0)], []
def neighbours(d, t, idxs, look=(0, 0), face='open', mouth='flat', seed=0):
    outs = ['peasant_w', 'peasant_m', 'peasant_w2', 'peasant_m2']
    for k, i in enumerate(idxs):
        wx, wy = WINDOWS[i]
        human(d, wx, wy + 200, 0.62, outs[(k + seed) % 4], face=face, mouth=mouth, armL=(170, 60), armR=(-170, 60), shadow_on=False, look=look, var=k % 3,
              brow=1 if face == 'wide' else 0)
        d.poly([(wx - 36, wy + 48), (wx + 36, wy + 48), (wx + 36, wy + 66), (wx - 36, wy + 66)], C('7a5530'), INK, 3)
def s2_draw(d, t, lt):
    dx = DOOR_X[4]
    neighbours(d, t, near_windows(DOOR_X[4], 3, 1)[1:], look=(0, 4), face='half', mouth='flat')
    human(d, dx, 1360, 1.15, 'troffea', face='open', mouth='smile', armL=(30, 70), armR=(-30, 70), bob=math.sin(t * 3) * 2)
def hud_s2(img, t, lt):
    tag(img, 'STRASBOURG · JULY 1518', t, 7.5, 10.4)
SH[-1]['draw'] = s2_draw; SH[-1]['hud'] = hud_s2

# S3 steps out and starts dancing 10.45-13.5
@shot(10.45, 13.5, 'street')
def s3(t, lt):
    dx = DOOR_X[4]
    return [(0, dx, 1180, 1.6, 0.0), (1.5, dx, 1360, 1.5, 0.0), (3.05, dx, 1370, 1.58, 0.01)], [12.05 - 10.45]
def s3_draw(d, t, lt):
    dx = DOOR_X[4]
    neighbours(d, t, near_windows(DOOR_X[4], 3, 1)[1:], look=(0, 5), face='wide' if lt > 1.7 else 'half', mouth='o' if lt > 1.7 else 'flat')
    u = smooth(clamp((lt - 0.15) / 1.2))
    y = lerp(1360, 1640, u)
    if lt < 1.6:
        human(d, dx, y, lerp(1.15, 1.45, u), 'troffea', face='open', mouth='smile', step=lt * 9 if u < 1 else 0, armL=(30, 70), armR=(-30, 70))
    else:
        troffea(d, dx, 1640, 1.45, t, energy=min(1, (lt - 1.6) * 2 + 0.2))
SH[-1]['draw'] = s3_draw

# S4 no music no reason 13.5-15.85
@shot(13.5, 15.85, 'street')
def s4(t, lt):
    dx = DOOR_X[4]
    return [(0, dx, 1350, 2.0, 0.0), (2.35, dx, 1340, 2.15, 0.02)], []
def s4_draw(d, t, lt):
    dx = DOOR_X[4]
    troffea(d, dx, 1640, 1.45, t)
def hud_s4(img, t, lt):
    for (t0, txt, x, font) in ((13.67, 'note', 330, FDJ), (14.84, '?', 750, FX)):
        if t >= t0:
            p = pop(t, t0, 0.3)
            d = D(img, Aff(0, 0, S)).sub(Aff(x, 420, p))
            d.ell(0, 0, 120, 120, C('fff6e6'), INK, 8)
            if txt == 'note':
                d.ell(-22, 40, 30, 22, C('3c283c'), None, 0, ang=-0.4); d.line([(4, 32), (4, -60)], C('3c283c'), 10)
                d.poly([(4, -60), (44, -40), (44, -20), (4, -38)], C('3c283c'), None)
            else:
                hud_text(img, txt, x, 420, 150, (60, 40, 60), p, 1, 0, font)
            if t > t0 + 0.2:
                u = clamp((t - t0 - 0.2) / 0.15)
                d.line([(-90, -90), (lerp(-90, 90, u), lerp(-90, 90, u))], C('e23b3b'), 18)
                if u >= 1: d.line([(90, -90), (-90, 90)], C('e23b3b'), 18)
SH[-1]['draw'] = s4_draw; SH[-1]['hud'] = hud_s4; SH[-1]['blur'] = True

# S5 a week 15.85-18.35 (day/night cycle)
@shot(15.85, 18.35, 'street')
def s5(t, lt):
    dx = DOOR_X[4]
    return [(0, dx, 1300, 1.25, 0.0), (2.5, dx, 1300, 1.3, 0.0)], []
def s5_draw(d, t, lt):
    dx = DOOR_X[4]
    tired = clamp((lt - 0.8) / 1.4)
    troffea(d, dx, 1640, 1.45, t * (1 - 0.4 * tired), energy=1 - tired * 0.4, tired=tired * 0.6)
CURM = None
def daynight(img, t, lt):
    cyc = (lt / 2.5) * 6
    night = 0.5 - 0.5 * math.cos(cyc * 2 * math.pi)
    if night > 0.01:
        ov = np.empty_like(img); ov[:] = C('2a2350')
        img[:] = cv2.addWeighted(img, 1 - 0.55 * night, ov, 0.55 * night, 0)
    if night > 0.35:
        g = np.zeros_like(img); dd = D(g, CURM)
        for (wx, wy) in WINDOWS: dd.ell(wx, wy, 40, 52, C('ffb84a'), None, 0)
        for h in HOUSES: dd.ell(h['x'] + 52, GROUND - 280, 34, 34, C('ffd27a'), None, 0)
        k = max(3, int(40 * S) | 1)
        g = cv2.GaussianBlur(g, (k, k), 0)
        img[:] = cv2.add(img, (g.astype(np.float32) * (night - 0.35) * 1.4).astype(np.uint8))
def hud_s5(img, t, lt):
    day = min(6, 1 + int((lt / 2.5) * 6))
    tag(img, f'DAY {day}', t, 15.9, 18.3)
    d = D(img, Aff(0, 0, S)).sub(Aff(540, 520))
    a = (lt / 2.5) * 6 * 2 * math.pi
    d.ell(math.cos(a - math.pi / 2) * 300, math.sin(a - math.pi / 2) * 120, 50, 50, C('ffd34a'), INK, 5)
    d.ell(math.cos(a + math.pi / 2) * 300, math.sin(a + math.pi / 2) * 120, 44, 44, C('eef2ff'), INK, 5)
SH[-1]['draw'] = s5_draw; SH[-1]['hud'] = hud_s5; SH[-1]['post'] = daynight

# S6 neighbours join 18.35-22.95
@shot(18.35, 22.95, 'street')
def s6(t, lt):
    dx = DOOR_X[4]
    return [(0, dx, 1300, 1.25, 0.0), (2.2, dx, 1340, 1.1, 0.0), (3.3, dx - 20, 1340, 0.95, 0.0, 'o'), (4.6, dx - 20, 1340, 0.93, 0.0)], [21.69 - 18.35]
def s6_draw(d, t, lt):
    dx = DOOR_X[4]
    many = 21.69
    wins = near_windows(dx, 6, 1) + near_windows(dx, 6, 2)
    if t < many + 0.4:
        neighbours(d, t, wins, look=(0, 5), face='wide', mouth='o')
    if t > many:
        p = back((t - many) / 0.4, 1.8)
        bg_crowd(d, t, -400, 1500, 1360 + (1 - min(1, p)) * 200, 3, 1.0, 8)
        crowd(d, t, 26, 21, -250, 1350, 1430, 1580, 1.0, 0, 1.15 * p)
    # neighbours step out of their doors and gather round
    folk = [(2, 'peasant_m', -330, 1500, 18.5, 20.55), (3, 'peasant_w', -170, 1540, 18.6, 20.7), (5, 'peasant_w2', 190, 1520, 18.7, 20.85),
            (6, 'peasant_m2', 340, 1490, 18.8, 99), (1, 'peasant_w', -470, 1470, 18.9, 99), (7, 'peasant_m', 470, 1480, 19.0, 99)]
    for k, (di, o, ox, oy, t0, tj) in enumerate(folk):
        if t < t0: continue
        u = smooth(clamp((t - t0) / 1.3))
        sx = DOOR_X[di]; tx = dx + ox
        x = lerp(sx, tx, u); y = lerp(GROUND + 10, oy, u); sc = lerp(0.8, 1.05, u)
        if t >= tj or t >= many:
            dancer(d, x, y, sc, o, t, k * 0.9, k % 3, 1.0, 0, style=('bounce', 'spin', 'hold', 'kick', 'bounce', 'spin')[k])
        else:
            human(d, x, y, sc, o, face='wide', mouth='o', step=t * 9 if u < 1 else 0, armL=(30 + 120 * (u >= 1) * abs(math.sin(t * 6 + k)), 70), armR=(-30, 70), var=k % 3, brow=1)
    troffea(d, dx, 1640, 1.45, t)
    if t > many:
        p = back((t - many - 0.15) / 0.4, 1.8)
        crowd(d, t, 6, 22, -150, 1250, 1720, 1800, 1.0, 0, 1.15 * p)
def hud_s6(img, t, lt):
    pass
SH[-1]['draw'] = s6_draw

# S7 400 by August 22.95-27.45
@shot(22.95, 27.45, 'street')
def s7(t, lt):
    return [(0, 540, 1450, 1.1, 0.0), (4.5, 560, 1300, 0.86, 0.0)], []
def s7_draw(d, t, lt):
    bg_crowd(d, t, -700, 1900, 1360, 4, 1.0, 6, 30)
    crowd(d, t, 40, 31, -500, 1700, 1400, 1640, 1.0, 0.2, 0.9)
    troffea(d, DOOR_X[4], 1700, 1.3, t, tired=0.2)
    crowd(d, t, 12, 32, -300, 1500, 1760, 1900, 1.0, 0.2, 1.1)
def hud_s7(img, t, lt):
    tag(img, 'AUGUST 1518', t, 23.0, 27.4)
    counter(img, t, 23.9, 26.9, 0, 400, 'DANCERS', y=360)
SH[-1]['draw'] = s7_draw; SH[-1]['hud'] = hud_s7

# S8 doctor + hot blood 27.45-33.0
@shot(27.45, 33.0, 'street')
def s8(t, lt):
    return [(0, 560, 1420, 1.35, 0.0), (2.5, 560, 1420, 1.42, 0.0), (4.15, 600, 1400, 1.62, -0.02, 'o'), (5.55, 610, 1395, 1.66, -0.02)], [31.66 - 27.45]
def lens(B, hL, hR):
    hx, hy = hL
    B.line([(hx, hy), (hx + 30, hy - 40)], C('6a4a30'), 8)
    B.ell(hx + 48, hy - 66, 30, 30, C('d8eef7'), INK, 5)
def s8_draw(d, t, lt):
    crowd(d, t, 14, 41, -200, 1300, 1420, 1520, 1.0, 0.3, 0.85)
    th = 31.66 - 27.45
    hot = clamp((lt - th) / 0.3)
    # dancer being examined
    dancer(d, 720, 1720, 1.3, 'peasant_m2', t, 0.5, 2, 1.0, 0.3, face='wide' if hot > 0 else None, mouth='o' if hot > 0 else None)
    if hot > 0:
        q = d.tp([(720, 1720 - 1.3 * 262)])[0]
        for k in range(4):
            ph = (lt * 1.5 + k * 0.25) % 1.0
            d.ell(720 + (k - 1.5) * 40, 1720 - 1.3 * 340 - ph * 160, 20 + ph * 26, 16 + ph * 20, C('f4f4f4'), INK, 3)
    u = smooth(clamp((lt - 0.1) / 1.8))
    human(d, lerp(-150, 380, u), 1760, 1.35, 'doctor', face='half' if lt > 2.3 else 'open', mouth='flat', step=lt * 8 if u < 1 else 0,
          armL=(110, 80) if lt > 2.0 else (30, 70), armR=(-20, 70), prop=lens if lt > 2.0 else None, brow=-0.5, var=0)
def hud_s8(img, t, lt):
    if t > 31.66:
        p = pop(t, 31.66, 0.3)
        d = D(img, Aff(0, 0, S)).sub(Aff(540, 380, p, -0.06))
        d.poly([(-330, -110), (330, -110), (330, 110), (-330, 110)], C('f4e7c6'), INK, 8)
        hud_text(img, 'DIAGNOSIS:', 540, 330, 52, (90, 60, 40), p, 1, -0.06)
        hud_text(img, 'HOT BLOOD', 540, 420, 100, (226, 59, 59), p, 1, -0.06)
        u = eout((t - 31.66) / 0.9)
        g = D(img, Aff(0, 0, S)).sub(Aff(890, 820, p))
        g.poly([(-34, -230), (34, -230), (34, 150), (-34, 150)], C('f4e7c6'), INK, 6)
        g.ell(0, 190, 58, 58, C('e23b3b'), INK, 6)
        g.poly([(-16, 160), (16, 160), (16, 160 - 370 * u), (-16, 160 - 370 * u)], C('e23b3b'), None)
        for k in range(6): g.line([(-34, 120 - k * 64), (-14, 120 - k * 64)], INK, 4)
        hud_text(img, 'BLOOD HEAT', 890, 540, 40, (255, 255, 255), p)
SH[-1]['draw'] = s8_draw; SH[-1]['hud'] = hud_s8

# S9 cure: more dancing 33.0-35.6
@shot(33.0, 35.6, 'street')
def s9(t, lt):
    return [(0, 420, 1350, 1.7, 0.0), (1.1, 420, 1350, 1.75, 0.0), (1.2, 430, 1330, 1.9, 0.03, 'o'), (2.6, 430, 1325, 1.95, 0.03)], [34.13 - 33.0]
def s9_draw(d, t, lt):
    crowd(d, t, 10, 51, -100, 1200, 1420, 1520, 1.0, 0.2, 0.85)
    up = lt > 1.1
    human(d, 420, 1760, 1.45, 'doctor', face='happy' if up else 'open', mouth='grin' if up else 'smile',
          armL=(178, 95) if up else (60, 70), armR=(-20, 70), brow=0, tilt=0.06 if up else 0)
def hud_s9(img, t, lt):
    if t > 33.08:
        hud_text(img, 'CURE:', 540, 300, 64, (255, 255, 255), pop(t, 33.08, 0.25))
    if t > 34.13:
        hud_text(img, 'MORE DANCING!', 540, 420, 112, (255, 214, 64), pop(t, 34.13, 0.3) * (1 + 0.04 * math.sin(lt * 9)))
SH[-1]['draw'] = s9_draw; SH[-1]['hud'] = hud_s9; SH[-1]['blur'] = True

# S10 stage + musicians 35.6-38.6
@shot(35.6, 38.6, 'street')
def s10(t, lt):
    return [(0, 560, 1300, 1.12, 0.0), (3.0, 560, 1300, 1.2, 0.0)], [35.75 - 35.6, 36.2 - 35.6, 36.65 - 35.6]
def lute(B, hL, hR):
    hx, hy = hR
    B.ell(hx + 20, hy + 10, 40, 30, C('c98a4a'), INK, 4); B.dot(hx + 20, hy + 10, 9, C('3a2a22'))
    B.line([(hx + 50, hy - 10), (hx + 130, hy - 60)], C('8a5a30'), 10)
def drum(B, hL, hR):
    hx, hy = hL
    B.poly([(-40, -60), (40, -60), (40, 0), (-40, 0)], C('d9b88a'), INK, 4)
    B.ell(0, -60, 40, 12, C('f2e6c8'), INK, 4)
    B.line([(hx, hy), (hx - 20, hy - 30)], C('6a4a30'), 6)
def horn(B, hL, hR):
    hx, hy = hL
    B.poly([(hx, hy - 4), (hx + 110, hy - 30), (hx + 120, hy - 10), (hx, hy + 4)], C('e0b84a'), INK, 4)
    B.ell(hx + 118, hy - 20, 14, 24, C('f0cc5a'), INK, 4)
def stage(d, lt, tb):
    for i, t0 in enumerate(tb):
        if lt < t0: continue
        p = back((lt - t0) / 0.25, 2.0)
        if i == 0:
            d.poly([(200, 1520), (920, 1520), (920, 1520 - 120 * p), (200, 1520 - 120 * p)], C('a0703e'), INK, 5)
            for k in range(8): d.line([(200 + k * 90, 1520), (200 + k * 90, 1520 - 120 * p)], C('80562c'), 3)
        if i == 1:
            for x in (220, 900): d.poly([(x - 12, 1400), (x + 12, 1400), (x + 12, 1400 - 260 * p), (x - 12, 1400 - 260 * p)], C('80562c'), INK, 4)
        if i == 2:
            pts = [(208, 1140), (912, 1140)]
            for k in range(7):
                x0 = 208 + k * 100; d.poly([(x0, 1140), (x0 + 100, 1140), (x0 + 50, 1140 + 70 * p)], C('d94b3c') if k % 2 else C('f2d14a'), INK, 3)
def s10_draw(d, t, lt):
    crowd(d, t, 18, 61, -200, 1300, 1420, 1500, 1.0, 0.2, 0.8)
    stage(d, lt, (0.15, 0.6, 1.05))
    for (x, o, prop, t0) in ((330, 'musician', lute, 37.25), (560, 'musician', drum, 37.6), (790, 'musician', horn, 37.95)):
        if t < t0: continue
        p = back((t - t0) / 0.3, 2.0)
        human(d, x, 1400, 1.0 * p, o, face='happy', mouth='grin', armL=(70 + 20 * math.sin(t * 12), 70), armR=(60, 70), prop=prop, bob=abs(math.sin(t * 7.5)) * 8,
              var=(x // 100) % 3)
    crowd(d, t, 6, 62, -100, 1200, 1700, 1780, 1.0, 0.3, 1.1)
SH[-1]['draw'] = s10_draw

# S11 worse 38.6-41.5
@shot(38.6, 41.5, 'street')
def s11(t, lt):
    return [(0, 520, 1150, 2.3, 0.0), (0.9, 540, 1160, 2.2, 0.02), (1.25, 560, 1300, 1.05, 0.0, 'o'), (2.9, 540, 1320, 0.98, 0.02)], [39.3 - 38.6, 40.0 - 38.6, 40.7 - 38.6]
def s11_draw(d, t, lt):
    bg_crowd(d, t * 1.5, -500, 1600, 1365, 3, 1.3, 7)
    crowd(d, t * 1.5, 34, 71, -400, 1500, 1410, 1500, 1.0, 0.6, 0.8)
    stage(d, 99, (0, 0, 0))
    BEAT = 60 / 112
    bp = (t % BEAT) / BEAT
    hit = math.exp(-bp * 8)
    for (x, prop) in ((330, lute), (560, drum), (790, horn)):
        human(d, x, 1400, 1.0, 'musician', face='happy', mouth='grin' if hit > 0.3 else 'o', armL=(70 + 45 * hit, 70), armR=(60 - 20 * hit, 70), prop=prop, bob=hit * 14, var=(x // 100) % 3)
    if lt < 1.25:
        for k in range(3):
            ph_ = (lt * 1.3 + k * 0.33) % 1.0
            world_text(d, '♪', 380 + k * 160 + ph_ * 60, 1060 - ph_ * 160, 70, (60, 40, 60)) if False else None
            nx, ny = 400 + k * 150 + ph_ * 60, 1060 - ph_ * 170
            d.ell(nx, ny, 14, 10, C('3c283c'), None, 0, ang=-0.4); d.line([(nx + 12, ny - 2), (nx + 12, ny - 52)], C('3c283c'), 5)
    if lt > 1.2: crowd(d, t * 1.6, 16, 72, -300, 1400, 1640, 1820, 1.0, 0.7, 1.05)
    human(d, 860, 1960, 1.3, 'doctor', face='closed', mouth='frown', armL=(165, 60), armR=(-20, 70), brow=1)
SH[-1]['draw'] = s11_draw

# S12 council 41.5-46.4
@shot(41.5, 46.4, 'hall')
def s12(t, lt):
    return [(0, 540, 1250, 1.2, 0.0), (0.9, 540, 1250, 1.25, 0.0), (1.0, 540, 1240, 1.4, 0.03, 'o'), (4.9, 540, 1230, 1.45, 0.02)], [41.58 - 41.5 + 0.8, 43.95 - 41.5, 45.2 - 41.5]
def sign(B, hL, hR, txt_flip=0.0):
    pass
def gavel(B, hL, hR):
    hx, hy = hL
    B.line([(hx, hy), (hx + 10, hy - 60)], C('6a4528'), 9)
    B.poly([(hx - 20, hy - 60), (hx + 40, hy - 70), (hx + 44, hy - 46), (hx - 16, hy - 36)], C('7a5230'), INK, 4)
def s12_draw(d, t, lt):
    flipped = lt > 0.85
    bang = max(0, 1 - abs(lt - 0.75) / 0.12) if lt < 0.9 else max(0, 1 - abs(lt - 2.45) / 0.12)
    nod = math.sin(lt * 9) * 0.1 if lt > 0.9 else 0
    human(d, 820, 1560, 1.05, 'council', face='closed' if flipped else 'open', mouth='flat', var=2, tilt=nod, armL=(60, 70), armR=(-20, 70))
    human(d, 980, 1580, 1.05, 'council', face='half' if flipped else 'open', mouth='flat', var=1, tilt=-nod, armL=(lerp(60, 150, bang), 80), armR=(-20, 70), prop=gavel)
    human(d, 360, 1720, 1.45, 'council', face='half' if flipped else 'open', mouth='flat' if flipped else 'smile', brow=-1 if flipped else 0,
          armL=(150, 80), armR=(-30, 70), tilt=0.0, var=0)
    # sign held up, flips at 'flipped'
    ang = clamp((lt - 0.7) / 0.3) * math.pi
    sx = abs(math.cos(ang))
    L = d.sub(Aff(560, 1170, 1)).sub(Aff(0, 0, 1, 0, 1, 1)).sub(np.array([[sx, 0, 0], [0, 1, 0], [0, 0, 1]], float))
    L.poly([(-180, -110), (180, -110), (180, 110), (-180, 110)], C('f4e7c6'), INK, 7)
    d.line([(560, 1280), (560, 1430)], C('6a4a30'), 10)
    world_text(d, 'DANCE!' if ang < math.pi / 2 else 'NO DANCE', 560, 1170, 80 * max(0.05, sx), (40, 120, 60) if ang < math.pi / 2 else (200, 40, 40))
    # decree on table
    d.poly([(640, 1600), (1000, 1600), (1000, 1640), (640, 1640)], C('7a5230'), INK, 5)
    d.poly([(660, 1800), (690, 1800), (690, 1640), (660, 1640)], C('6a4528'), INK, 4); d.poly([(950, 1800), (980, 1800), (980, 1640), (950, 1640)], C('6a4528'), INK, 4)
def stamp(img, txt, x, y, t, t0, rot=0.1, size=76):
    if t <= t0: return
    u = (t - t0) / 0.16
    sc = 2.2 - 1.2 * clamp(u) if u < 1 else 1.0
    spr = text_sprite(txt, int(size * S), (226, 59, 59), 0.06, None, (255, 240, 235))
    hw = spr.shape[1] / S / 2 + 44; hh = spr.shape[0] / S / 2 + 26
    d = D(img, Aff(0, 0, S)).sub(Aff(x, y, sc, -rot))
    d.poly([(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)], C('fbefe6'), C('e23b3b'), 12)
    d.poly([(-hw + 14, -hh + 14), (hw - 14, -hh + 14), (hw - 14, hh - 14), (-hw + 14, hh - 14)], None, C('e23b3b'), 4)
    blit(img, spr, x * S, y * S, sc, 1, rot)
def hud_s12(img, t, lt):
    stamp(img, 'MUSIC BANNED', 540, 290, t, 43.95, 0.08)
    stamp(img, 'DANCING BANNED', 540, 480, t, 45.2, -0.06)
SH[-1]['draw'] = s12_draw; SH[-1]['hud'] = hud_s12

# S13a procession up the hill 46.4-49.0
@shot(46.4, 49.0, 'shrine')
def s13(t, lt):
    return [(0, 840, 1380, 1.05, 0.0), (2.6, 760, 1150, 1.12, 0.0)], []
def cross_staff(B, hL, hR):
    hx, hy = hL
    B.line([(hx, hy + 40), (hx, hy - 170)], C('7a5230'), 8)
    B.line([(hx - 30, hy - 140), (hx + 30, hy - 140)], C('e0b84a'), 8); B.line([(hx, hy - 170), (hx, hy - 110)], C('e0b84a'), 8)
PROC = [('priest', 'walk'), ('troffea', 'tired'), ('peasant_m', 'spin'), ('peasant_w', 'tired'), ('peasant_w2', 'bounce'), ('peasant_m2', 'walk'),
        ('peasant_w', 'spin'), ('peasant_m', 'tired'), ('peasant_w2', 'walk'), ('peasant_m2', 'bounce'), ('peasant_w', 'tired'), ('peasant_m', 'walk')]
def s13_draw(d, t, lt):
    items = []
    for i, (o, mode) in enumerate(PROC):
        u = 0.62 + lt * 0.07 - i * 0.055
        if u < -0.02: continue
        x, y, fl = path_at(u)
        sc = 0.28 + (y - 840) / 1120 * 0.95
        items.append((y, x, i, o, mode, fl, sc))
    items.sort()
    for y, x, i, o, mode, fl, sc in items:
        ox = 18 * sc * (1 if i % 2 else -1)
        if mode in ('spin', 'bounce'):
            dancer(d, x + ox, y, sc, o, t, i, i % 3, 1.0, 0.0, style=mode, flip=fl)
        elif mode == 'tired':
            dancer(d, x + ox, y, sc, o, t * 0.7, i, i % 3, 0.6, 0.7, flip=fl)
        else:
            human(d, x + ox, y, sc, o, face='closed' if o == 'priest' else 'open', mouth='o' if o == 'priest' else 'smile', flip=fl, step=t * 8, armL=(150, 80) if o == 'priest' else (20, 70), armR=(-20, 70),
                  prop=cross_staff if o == 'priest' else None, var=i % 3, bob=abs(math.sin(t * 8)) * 6)
SH[-1]['draw'] = s13_draw
def hud_s13(img, t, lt):
    tag(img, 'SHRINE OF SAINT VITUS', t, 46.45, 48.95, y=1620)
SH[-1]['hud'] = hud_s13

# S13b red shoes at the chapel door 49.0-52.45
DOOR_Y = 850
@shot(49.0, 52.45, 'shrine')
def s13b(t, lt):
    return [(0, 690, 700, 2.15, 0.0), (3.45, 690, 690, 2.3, 0.01)], []
def s13b_draw(d, t, lt):
    for k, (mx_, my_) in enumerate(((560, 830), (830, 830))):
        human(d, mx_, my_, 0.48, 'priest', face='closed', mouth='o', armL=(150, 60), armR=(-150, 60), var=k, tilt=math.sin(t * 2 + k) * 0.05)
        for j in range(2):
            ph_ = (t * 0.8 + j * 0.5 + k * 0.25) % 1.0
            nx, ny = mx_ + 20 + ph_ * 30, my_ - 170 - ph_ * 80
            d.ell(nx, ny, 6, 4.5, C('3c283c'), None, 0, ang=-0.4); d.line([(nx + 5, ny - 1), (nx + 5, ny - 22)], C('3c283c'), 2.5)
    human(d, 610, 875, 0.6, 'priest', face='happy', mouth='smile', armL=(100, 80), armR=(-20, 70))
    human(d, 780, 875, 0.58, 'troffea', face='wide' if t > 51.2 else 'closed', mouth='o' if t > 51.2 else 'frown', flip=-1, armL=(40, 70), armR=(-30, 70), sweat=t < 51.0)
    g = clamp((t - 50.9) / 0.4)
    cx, cy = 695, 770
    if g > 0:
        for k in range(8):
            a = k * math.pi / 4 + t
            d.line([(cx + math.cos(a) * 30 * g, cy + math.sin(a) * 30 * g), (cx + math.cos(a) * 56 * g, cy + math.sin(a) * 56 * g)], C('ffe27a'), 4)
    for sx_ in (-15, 15):
        d.poly([(cx + sx_ - 14, cy + 4), (cx + sx_ + 16, cy + 7), (cx + sx_ + 17, cy + 13), (cx + sx_ - 15, cy + 13)], REDSHOE, INK, 2.5)
        d.ell(cx + sx_ + 1, cy + 7, 5, 1.8, C('ff8a8a'), None, 0)
SH[-1]['draw'] = s13b_draw
def glow13(img, t, lt):
    if CURM is None: return
    g = np.zeros_like(img); dd = D(g, CURM)
    dd.ell(695, 760, 160, 140, C('ffcf6a'), None, 0)
    k = max(3, int(120 * S) | 1)
    g = cv2.GaussianBlur(g, (k, k), 0)
    img[:] = cv2.add(img, (g.astype(np.float32) * (0.12 + 0.16 * clamp((t - 50.8) / 0.5))).astype(np.uint8))
SH[-1]['post'] = glow13

# S14 September 52.45-55.2
@shot(52.45, 55.2, 'street_eve')
def s14(t, lt):
    return [(0, 540, 1380, 1.12, 0.0), (2.75, 540, 1400, 1.22, 0.0)], []
def s14_draw(d, t, lt):
    r = rng(81)
    for i in range(9):
        x = r.uniform(-50, 1150); y = r.uniform(1450, 1560)
        human(d, x, y, 0.75, ('peasant_w', 'peasant_m', 'peasant_w2', 'peasant_m2')[i % 4], face='closed', mouth='frown' if i % 2 else 'o',
              armL=(10, 60), armR=(-10, 60), tilt=0.2 * (1 if i % 2 else -1), bob=-10, var=i % 3)
    human(d, DOOR_X[4], 1700, 1.35, 'troffea', face='closed', mouth='smile', armL=(15, 70), armR=(-15, 70), shoes=REDSHOE, tilt=0.06)
    for i in range(10):
        rx = rng(i + 3)
        x = rx.uniform(0, 1080) + math.sin(t * 2 + i) * 40; y = 600 + ((t * 120 + rx.uniform(0, 900)) % 1100)
        L = d.sub(Aff(x, y, 1, t * 2 + i)); L.ell(0, 0, 18, 9, C('d9822f') if i % 2 else C('c9542f'), INK, 2)
def hud_s14(img, t, lt):
    tag(img, 'SEPTEMBER 1518', t, 52.5, 55.15)
SH[-1]['draw'] = s14_draw; SH[-1]['hud'] = hud_s14

# S15 nobody knows why 55.2-57.5
@shot(55.2, 57.5, 'street_eve')
def s15(t, lt):
    return [(0, DOOR_X[4], 1330, 2.0, 0.0), (2.3, DOOR_X[4], 1320, 2.2, -0.02)], []
def s15_draw(d, t, lt):
    shrug = clamp((lt - 0.2) / 0.3)
    human(d, DOOR_X[4], 1700, 1.35, 'troffea', face='half', mouth='flat', armL=(lerp(15, 120, shrug), 70), armR=(lerp(-15, -120, shrug), 70), shoes=REDSHOE, brow=1, tilt=0.08 * shrug)
def hud_s15(img, t, lt):
    for k in range(5):
        t0 = 55.3 + k * 0.18
        if t > t0:
            x = 180 + k * 180; y = 360 + (k % 2) * 160 + math.sin(t * 3 + k) * 20
            hud_text(img, '?', x, y, 120 + (k % 3) * 30, (255, 214, 64) if k % 2 else (255, 255, 255), pop(t, t0, 0.3))
SH[-1]['draw'] = s15_draw; SH[-1]['hud'] = hud_s15; SH[-1]['blur'] = True
def darken(img, t, lt):
    img[:] = (img.astype(np.float32) * 0.78).astype(np.uint8)
SH[-1]['post'] = darken

# S16 longest party, loop to the shoe 57.5-59.95
@shot(57.5, 59.95, 'street')
def s16(t, lt):
    fx, fy = FOOT_ECU
    return [(0, 540, 1420, 1.3, 0.0), (1.2, 540, 1440, 1.4, 0.0), (2.2, fx, fy, 4.2, 0.04, 'i'), (2.45, fx, fy, 4.2, 0.04)], []
def s16_draw(d, t, lt):
    go = lt > 1.1
    bg_crowd(d, t, -300, 1400, 1370, 3, 1.0 if go else 0.0, 5)
    crowd(d, t, 16, 3, -150, 1250, 1420, 1600, 1.0 if go else 0.0, 0, 0.95)
    tapping = 0.8 < lt
    troffea(d, 520, 1800, TROF['sc'], t, energy=0.15 if tapping else 0.0, shoes=REDSHOE, face='half' if lt < 1.6 else 'closed', mouth='smirk' if lt < 1.6 else 'smile')
    crowd(d, t, 2, 8, -100, 260, 1880, 1950, 1.0, 0, 1.1); crowd(d, t, 2, 9, 820, 1180, 1880, 1950, 1.0, 0, 1.1)
def hud_s16(img, t, lt):
    if 58.6 < t < 59.6:
        hud_text(img, 'LONGEST PARTY EVER', 540, 300, 92, (255, 214, 64), pop(t, 58.6, 0.3), clamp((59.6 - t) / 0.3))
        hud_text(img, '~2 MONTHS', 540, 420, 80, (255, 255, 255), pop(t, 58.8, 0.3), clamp((59.6 - t) / 0.3))
SH[-1]['draw'] = s16_draw; SH[-1]['hud'] = hud_s16
# assign the fn as camera
for s_ in SH: s_['cam'] = s_['fn']

# ---------------- captions ----------------
TIM = json.load(open(os.path.join(os.path.dirname(__file__), 'work/timing.json')))
import re
def syl(w):
    w = re.sub(r'[^a-z]', '', w.lower())
    if not w: return 1
    n = len(re.findall(r'[aeiouy]+', w))
    if w.endswith('e') and n > 1 and not w.endswith('le'): n -= 1
    return max(1, n)
KEY = {'fifteen', 'eighteen', 'disease', 'dancing', 'one', 'woman', 'week', 'dozens', 'four', 'hundred', 'august', 'doctors', 'hot', 'blood', 'more', 'stage', 'worse', 'flipped', 'banned', 'red', 'shoes', 'september', 'why', 'longest', 'party',
       'fifty', 'bounced', 'month', 'gone', 'single', 'tanks', 'won', 'still', 'nineteen', 'thirty-two'}
CH = []
for a, b, txt in TIM:
    ws = txt.replace('...', '…').split()
    ss = [syl(w) for w in ws]; tot = sum(ss); tt = a
    wt = []
    for w, s_ in zip(ws, ss):
        d_ = (b - a) * s_ / tot; wt.append((tt, w)); tt += d_
    # chunks of 1-2 words, break after punctuation
    i = 0
    while i < len(wt):
        n = 1
        if i + 1 < len(wt) and not re.search(r'[,.?!…]$', wt[i][1]) and len(wt[i][1]) + len(wt[i + 1][1]) < 14: n = 2
        words = [w for _, w in wt[i:i + n]]
        CH.append([wt[i][0], ' '.join(words)])
        i += n
    CH[-1].append(b + 0.25)
for i in range(len(CH)):
    if len(CH[i]) == 2: CH[i].append(CH[i + 1][0])
    CH[i][2] = min(CH[i][2], CH[i + 1][0] if i + 1 < len(CH) else 99)

def pill(img, cx, cy, w, h, a=0.45):
    x0, y0, x1, y1 = int(cx - w / 2), int(cy - h / 2), int(cx + w / 2), int(cy + h / 2)
    x0, y0 = max(0, x0), max(0, y0); x1, y1 = min(OW, x1), min(OH, y1)
    if x0 >= x1 or y0 >= y1: return
    m = np.zeros((y1 - y0, x1 - x0), np.uint8)
    rr = int(h / 2)
    cv2.rectangle(m, (rr, 0), (x1 - x0 - rr, y1 - y0), 255, -1)
    cv2.circle(m, (rr, rr), rr, 255, -1); cv2.circle(m, (x1 - x0 - rr, rr), rr, 255, -1)
    m = (m.astype(np.float32) / 255 * a)[..., None]
    roi = img[y0:y1, x0:x1].astype(np.float32)
    img[y0:y1, x0:x1] = (roi * (1 - m) + np.array([40, 20, 30], np.float32) * m).astype(np.uint8)

def cap_text(img, txt, x, y, size, rgb, sc):
    spr = text_sprite(txt, int(size * S), rgb, 0.17)
    sh = spr.copy(); sh[..., :3] = 0
    k = max(3, int(14 * S) | 1)
    sh[..., 3] = cv2.GaussianBlur(sh[..., 3], (k, k), 0)
    blit(img, sh, x * S + 4 * S, y * S + 7 * S, sc, 0.7)
    blit(img, spr, x * S, y * S, sc)

def caption(img, t):
    for t0, txt, t1 in CH:
        if t0 - 0.03 <= t < t1:
            disp_ = txt.upper().replace('…', '...').rstrip(',.')
            spr = text_sprite(disp_, int(96 * S), (255, 255, 255), 0.14, None)
            break
    for t0, txt, t1 in CH:
        if t0 - 0.03 <= t < t1:
            clean = re.sub(r'[^\w\-:]', '', txt.lower().split()[-1]) if txt else ''
            words = [re.sub(r'[^\w\-]', '', w.lower()) for w in txt.split()]
            key = any(w in KEY for w in words)
            disp = txt.upper().replace('…', '...').rstrip(',.')
            if disp.endswith('...'): pass
            if key:
                u = (t - t0) / 0.22
                sc = 0.6 + 0.6 * back(u, 2.6) if u < 1 else 1.2
                col = (255, 255, 255) if u < 0.4 else (255, 160, 40) if u < 0.7 else (255, 214, 64)
                cap_text(img, disp, 540, 1325, 100, col, sc)
            else:
                sc = 0.7 + 0.3 * back((t - t0) / 0.15, 2.0)
                cap_text(img, disp, 540, 1325, 100, (255, 255, 255), sc)
            return

FLASH = [(7.4, 6), (52.45, 6)]
FIELD = ('day', 'gold', 'dusk')
HZ = 900

def wind_waves(img, M, t):
    gh, gw = OH // 8 + 1, OW // 8 + 1
    ys, xs = np.mgrid[0:gh, 0:gw].astype(np.float32) * 8
    Mi = np.linalg.inv(M)
    wx = Mi[0, 0] * xs + Mi[0, 1] * ys + Mi[0, 2]
    wy = Mi[1, 0] * xs + Mi[1, 1] * ys + Mi[1, 2]
    g = 1 + (0.055 * np.sin(wx * 0.0045 + wy * 0.0016 - t * 2.1) + 0.03 * np.sin(wx * 0.011 - wy * 0.003 - t * 3.3))
    g = np.where(wy > HZ + 30, g, 1.0) * np.clip((wy - HZ - 30) / 120, 0, 1) + (1 - np.clip((wy - HZ - 30) / 120, 0, 1))
    g = cv2.resize(g.astype(np.float32), (OW, OH), interpolation=cv2.INTER_LINEAR)
    img[:] = np.clip(img.astype(np.float32) * g[..., None], 0, 255).astype(np.uint8)

def sky_life(d, t, kind):
    col = C('ffffff') if kind == 'day' else C('ffe9c8')
    for i, (bx, by, s_) in enumerate(((-600, 300, 1.0), (500, 200, 0.8), (1700, 420, 1.2), (2900, 260, 0.9), (3900, 380, 1.0))):
        x = (bx + t * 22 + 900) % 5600 - 900
        for j in range(5):
            d.ell(x + (j - 2) * 70 * s_, by + (0 if j % 2 else -26) * s_, 85 * s_, 48 * s_, col, None, 0)
    for i in range(4):
        x = (200 + i * 260 + t * 90) % 2400 - 400; y = 360 + i * 45 + math.sin(t * 1.3 + i) * 20
        f = math.sin(t * 14 + i * 2) * 10
        d.line([(x - 18, y - f), (x, y), (x + 18, y - f)], C('3a2f2a'), 4)

WHIP = [s_['t0'] for s_ in SH if s_['t0'] not in (0.0, 7.4, 52.45, 55.2)]
def whip(img, f):
    for b in WHIP:
        df = f - int(round(b * FPS))
        if -4 <= df <= 3:
            if df < 0: p = (df + 5) / 5.0; sh = -p * p * OW * 0.3
            else: p = (4 - df) / 4.0; sh = p * p * OW * 0.3
            M2 = np.float32([[1, 0, sh], [0, 1, 0]])
            out = cv2.warpAffine(img, M2, (OW, OH), borderMode=cv2.BORDER_REPLICATE)
            k = max(1, int(abs(sh) * 0.35)) | 1
            img[:] = cv2.blur(out, (k, 1))
            return


def render(f):
    t = f / FPS
    sh = next((s for s in SH if s['t0'] <= t < s['t1']), SH[-1])
    lt = t - sh['t0']
    keys, kicks = sh['cam'](t, lt)
    cx, cy, z, rot = cam_keys(keys, lt)
    if sh.get('pan'): cx += sh['pan'](t, lt)
    # creep
    cx += math.sin(t * 0.9) * 6; cy += math.cos(t * 0.7) * 5
    sx, sy = shake_at(lt, kicks)
    M = camM(cx, cy, z, rot, (sx, sy))
    img = np.zeros((OH, OW, 3), np.uint8)
    if sh['bg']:
        bg = bgimg(sh['bg'] + ('_blur' if sh.get('blur') else ''))
        ox, oy = BGOFF[sh['bg'] + ('_blur' if sh.get('blur') else '')]
        Mb = M @ np.array([[1 / S, 0, -ox], [0, 1 / S, -oy], [0, 0, 1]])
        cv2.warpAffine(bg, Mb[:2], (OW, OH), dst=img, flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    global CURM
    CURM = M
    d = D(img, M)
    if sh['bg'] in FIELD:
        wind_waves(img, M, t)
        if not sh.get('blur'): sky_life(d, t, sh['bg'])
    sh['draw'](d, t, lt)
    if sh.get('post'): sh['post'](img, t, lt)
    if sh.get('desat'):
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        u = clamp((lt - 0.12) / 0.15)
        img[:] = cv2.addWeighted(img, 1 - 0.75 * u, cv2.cvtColor(g, cv2.COLOR_GRAY2BGR), 0.75 * u, 0)
    img[:] = (img.astype(np.float32) * vignette()).astype(np.uint8)
    if os.environ.get('NOTEXT'):
        return img
    if sh.get('hud'): sh['hud'](img, t, lt)
    whip(img, f)
    caption(img, t)
    for ft, n in FLASH:
        df = f - int(ft * FPS)
        if -3 <= df < n:
            a = 1 - abs(df) / (n if df >= 0 else 3)
            img[:] = cv2.addWeighted(img, 1 - a, np.full_like(img, 255), a, 0)
    return img

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'stills':
        out = sys.argv[2]; os.makedirs(out, exist_ok=True)
        for tt in sys.argv[3].split(','):
            f = int(float(tt) * FPS); cv2.imwrite(f'{out}/s_{float(tt):05.2f}.jpg', render(f))
    else:
        out = sys.argv[2]; a, b = map(int, sys.argv[3].split('-')); os.makedirs(out, exist_ok=True)
        for f in range(a, b + 1):
            cv2.imwrite(f'{out}/f{f:05d}.jpg', render(f), [cv2.IMWRITE_JPEG_QUALITY, 92])
