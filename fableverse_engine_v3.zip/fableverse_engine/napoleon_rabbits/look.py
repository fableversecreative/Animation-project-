"""Premium 2.5D look layer: painterly textures, colour grade, bloom, god rays,
floating dust motes, depth-of-field foreground, film grain, cast shadows."""
import numpy as np, cv2, math

# ---------- texture for painted backgrounds ----------
def paint_texture(img, seed=1, amt=0.06, streak=0.03):
    h, w = img.shape[:2]
    r = np.random.default_rng(seed)
    big = cv2.resize(r.standard_normal((max(2, h // 90), max(2, w // 90))).astype(np.float32), (w, h), interpolation=cv2.INTER_CUBIC)
    mid = cv2.resize(r.standard_normal((max(2, h // 22), max(2, w // 22))).astype(np.float32), (w, h), interpolation=cv2.INTER_CUBIC)
    fine = r.standard_normal((h, w)).astype(np.float32)
    k = max(3, (w // 300) | 1)
    fine = cv2.GaussianBlur(fine, (k, k), 0)
    st = cv2.blur(r.standard_normal((h, w)).astype(np.float32), (max(3, w // 60), 1))   # horizontal brush streaks
    g = 1 + amt * (0.55 * big + 0.35 * mid + 0.25 * fine) + streak * st
    img[:] = np.clip(img.astype(np.float32) * g[..., None], 0, 255).astype(np.uint8)

def haze(img, y0, y1, col, a0, a1):
    """atmospheric perspective: blend rows y0..y1 toward col with alpha a0->a1"""
    h = img.shape[0]
    y0, y1 = max(0, int(y0)), min(h, int(y1))
    if y1 <= y0: return
    a = np.linspace(a0, a1, y1 - y0, dtype=np.float32)[:, None, None]
    img[y0:y1] = (img[y0:y1].astype(np.float32) * (1 - a) + np.array(col, np.float32) * a).astype(np.uint8)

# ---------- colour grade ----------
_LUT = {}
def grade_lut(kind='warm'):
    if kind in _LUT: return _LUT[kind]
    x = np.arange(256, dtype=np.float32) / 255
    s = x + 0.10 * np.sin(2 * math.pi * x) * -0.5 * 0 + 0.0
    curve = 0.5 + (x - 0.5) * 1.06 + 0.05 * np.sin((x - 0.5) * math.pi)   # gentle S
    curve = np.clip(curve, 0, 1)
    if kind == 'warm':
        b = np.clip(curve * 0.95 + 0.025 * (1 - x), 0, 1)        # shadows a touch cool, highlights warmer
        g = np.clip(curve * 0.99 + 0.006, 0, 1)
        r_ = np.clip(curve * 1.03 + 0.01 * x, 0, 1)
    elif kind == 'night':
        b = np.clip(curve * 1.05 + 0.04, 0, 1); g = np.clip(curve * 0.95, 0, 1); r_ = np.clip(curve * 0.88, 0, 1)
    else:
        b = g = r_ = curve
    lut = np.stack([b, g, r_], 1)[None] * 255
    _LUT[kind] = lut.astype(np.uint8)
    return _LUT[kind]

def grade(img, kind='warm', sat=1.12):
    img[:] = cv2.LUT(img, grade_lut(kind))
    if abs(sat - 1) > 0.01:
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        hsv[..., 1] = cv2.convertScaleAbs(hsv[..., 1], alpha=sat)
        img[:] = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

def bloom(img, thr=205, amt=0.35, tint=(1.0, 0.95, 0.85)):
    h, w = img.shape[:2]
    sm = cv2.resize(img, (w // 4, h // 4), interpolation=cv2.INTER_AREA).astype(np.float32)
    lum = sm.max(2, keepdims=True)
    m = np.clip((lum - thr) / (255 - thr), 0, 1)
    b = sm * m
    k = max(3, (w // 40) | 1)
    b = cv2.GaussianBlur(b, (k, k), 0)
    b = cv2.resize(b, (w, h), interpolation=cv2.INTER_LINEAR) * np.array(tint, np.float32)
    img[:] = np.clip(img.astype(np.float32) + b * amt, 0, 255).astype(np.uint8)

def god_rays(img, sx, sy, t, strength=0.22, col=(150, 220, 255), n=11, spread=1.25, down=math.pi / 2, length=2.2, seed=3):
    """additive light beams fanning from screen point (sx, sy)"""
    h, w = img.shape[:2]
    sc = 4
    lay = np.zeros((h // sc, w // sc), np.float32)
    r = np.random.default_rng(seed)
    L = max(h, w) * length / sc
    for i in range(n):
        a = down - spread / 2 + spread * (i + 0.5) / n + 0.05 * math.sin(t * 0.4 + i * 1.7)
        wdt = 0.035 + 0.03 * r.random()
        inten = (0.45 + 0.55 * r.random()) * (0.75 + 0.25 * math.sin(t * 0.9 + i * 2.3))
        p = np.array([[sx / sc, sy / sc], [sx / sc + math.cos(a - wdt) * L, sy / sc + math.sin(a - wdt) * L], [sx / sc + math.cos(a + wdt) * L, sy / sc + math.sin(a + wdt) * L]], np.float32)
        cv2.fillPoly(lay, [(p * 16).astype(np.int32)], float(inten), cv2.LINE_AA, shift=4)
    k = max(3, (w // sc // 25) | 1)
    lay = cv2.GaussianBlur(lay, (k, k), 0)
    yy, xx = np.mgrid[0:h // sc, 0:w // sc].astype(np.float32)
    dist = np.sqrt((xx - sx / sc) ** 2 + (yy - sy / sc) ** 2) / (max(h, w) / sc)
    lay *= np.clip(1.15 - dist * 0.9, 0, 1)
    lay = cv2.resize(lay, (w, h), interpolation=cv2.INTER_LINEAR)
    add = lay[..., None] * np.array(col, np.float32) * strength
    img[:] = np.clip(img.astype(np.float32) + add, 0, 255).astype(np.uint8)

def sun_glow(img, sx, sy, rad, col=(170, 230, 255), amt=0.6):
    h, w = img.shape[:2]
    sc = 4
    lay = np.zeros((h // sc, w // sc), np.float32)
    cv2.circle(lay, (int(sx / sc), int(sy / sc)), max(1, int(rad / sc)), 1.0, -1, cv2.LINE_AA)
    k = max(3, int(rad / sc * 3) | 1)
    lay = cv2.GaussianBlur(lay, (k, k), 0)
    lay = cv2.resize(lay, (w, h))
    img[:] = np.clip(img.astype(np.float32) + lay[..., None] * np.array(col, np.float32) * amt, 0, 255).astype(np.uint8)

class Motes:
    """floating dust / pollen particles in screen space, with depth parallax"""
    def __init__(s, n=70, seed=5):
        r = np.random.default_rng(seed)
        s.p = r.random((n, 2)); s.z = r.uniform(0.3, 1.0, n); s.ph = r.uniform(0, 6.28, n)
    def draw(s, img, t, cam_dx=0.0, cam_dy=0.0, col=(190, 235, 255), amt=1.0, region=(0, 1)):
        h, w = img.shape[:2]
        lay = np.zeros((h, w), np.float32)
        for (px, py), z, ph in zip(s.p, s.z, s.ph):
            x = ((px + 0.012 * t * z + 0.02 * math.sin(t * 0.7 + ph) - cam_dx * z) % 1.0) * w
            y = ((py - 0.008 * t * z + 0.015 * math.cos(t * 0.5 + ph) - cam_dy * z) % 1.0)
            y = (region[0] + (region[1] - region[0]) * y) * h
            rr = max(1.0, w / 540 * (1.2 + 2.6 * z))
            tw = 0.5 + 0.5 * math.sin(t * 2.3 + ph * 3)
            cv2.circle(lay, (int(x * 4), int(y * 4)), int(rr * 4), float(0.5 + 0.5 * tw) * z, -1, cv2.LINE_AA, shift=2)
        k = max(3, (w // 300) | 1)
        lay = cv2.GaussianBlur(lay, (k, k), 0)
        img[:] = np.clip(img.astype(np.float32) + lay[..., None] * np.array(col, np.float32) * 0.85 * amt, 0, 255).astype(np.uint8)

_GR = {}
def grain(img, f, amt=7):
    h, w = img.shape[:2]
    key = (h, w)
    if key not in _GR:
        r = np.random.default_rng(11)
        _GR[key] = [(r.standard_normal((h, w)) * amt).astype(np.int16) for _ in range(4)]
    g = _GR[key][f % 4]
    img[:] = np.clip(img.astype(np.int16) + g[..., None], 0, 255).astype(np.uint8)

def chroma(img, px=1):
    if px < 1: return
    b, g, r = cv2.split(img)
    h, w = img.shape[:2]
    M1 = np.float32([[1 + px / w, 0, -px / 2], [0, 1 + px / h, -px / 2]])
    r = cv2.warpAffine(r, M1, (w, h), borderMode=cv2.BORDER_REPLICATE)
    img[:] = cv2.merge([b, g, r])

def dof_layer(img, draw_fn, blur_px):
    """draw something on top and blur only it (out-of-focus foreground)"""
    before = img.copy()
    draw_fn()
    diff = cv2.absdiff(img, before).max(2)
    m = (diff > 2).astype(np.float32)
    k = max(3, int(blur_px) | 1)
    m = cv2.GaussianBlur(m, (k, k), 0)
    fb = cv2.GaussianBlur(img, (k, k), 0)
    img[:] = (before.astype(np.float32) * (1 - m[..., None]) + fb.astype(np.float32) * m[..., None]).astype(np.uint8)

def blur_all(img, px):
    k = max(3, int(px) | 1)
    img[:] = cv2.GaussianBlur(img, (k, k), 0)

def cast_shadow(d, x, y, rx, ry, dx=60, k=0.62):
    """long soft directional shadow + contact shadow"""
    from rig import shadow, Aff
    shadow(d, x + dx, y + 4, rx * 1.35, ry * 1.1, 0.78)
    shadow(d, x, y + 2, rx, ry, k)

_KL = {}
def key_light(img, ang=-0.6, strength=0.55, warm=(0.94, 1.0, 1.1), cool=(1.08, 0.99, 0.9), lift=0.75):
    """directional key light: bright warm side, darker cool shadow side (cinematic contrast)"""
    h, w = img.shape[:2]
    key = (h, w, round(ang, 3), strength)
    if key not in _KL:
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        u = ((xx / w - 0.5) * math.cos(ang) + (yy / h - 0.5) * math.sin(ang) * (h / w)) * 1.6
        l = np.clip(0.5 + u, 0, 1)
        m = (lift + (1 - lift) * l) * (1 - strength) + l * strength + 0.12
        tint = (l[..., None] * np.array(warm, np.float32) + (1 - l[..., None]) * np.array(cool, np.float32))
        _KL[key] = (m[..., None] * tint).astype(np.float32)
    img[:] = np.clip(img.astype(np.float32) * _KL[key], 0, 255).astype(np.uint8)

def contrast(img, amt=1.15, pivot=118):
    img[:] = np.clip((img.astype(np.float32) - pivot) * amt + pivot, 0, 255).astype(np.uint8)
