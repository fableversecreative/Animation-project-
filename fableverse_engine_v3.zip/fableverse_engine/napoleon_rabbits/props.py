import numpy as np, math, cv2
from rig import *

# ---------------- RABBIT ----------------
RAB = [
    dict(fur=C('f5f2ec'), dark=C('d9d3ca'), ear=C('f2b8b4')),   # white
    dict(fur=C('bf9166'), dark=C('9a714c'), ear=C('f0b4a8'), belly=C('efe2cc')),  # brown
    dict(fur=C('a9a39c'), dark=C('857f78'), ear=C('eeb2ae'), belly=C('e9e5df')),  # grey
    dict(fur=C('ead6b6'), dark=C('cbb28c'), ear=C('f2b8b0')),   # cream
    dict(fur=C('f5f2ec'), dark=C('d9d3ca'), ear=C('f2b8b4'), spots=C('5e4a3c')),  # spotted
    dict(fur=C('6e5a4c'), dark=C('54443a'), ear=C('e0a49c'), belly=C('cdbba6')),  # dark brown
]
NOSE = C('ee8f98')

def rab_eye(R, x, y, s, face, look=(0, 0)):
    lx, ly = look
    if face in ('open', 'wide', 'sparkle'):
        ry = 13 if face == 'wide' else 11
        R.ell(x, y, 9.5 * s, ry * s, C('2a1e22'), None, 0)
        R.ell(x + (lx * 2) * s, y + (ly * 2) * s, 9.5 * s, ry * s, C('2a1e22'), None, 0)
        R.dot(x + 3 * s + lx * 2 * s, y - 4 * s, 3.4 * s, (255, 255, 255))
        R.dot(x - 3 * s + lx * 2 * s, y + 4 * s, 1.6 * s, (255, 255, 255))
        if face == 'sparkle':
            R.dot(x - 2 * s, y - 1 * s, 2.2 * s, (255, 255, 255))
    elif face == 'happy':
        R.line(bez((x - 9 * s, y + 3 * s), (x, y - 8 * s), (x + 9 * s, y + 3 * s), 8), INK, 4)
    elif face == 'closed':
        R.line(bez((x - 9 * s, y), (x, y + 5 * s), (x + 9 * s, y), 8), INK, 4)
    elif face == 'heart':
        hp = []
        for a in np.linspace(0, 2 * math.pi, 30):
            hx_ = 16 * math.sin(a) ** 3; hy_ = -(13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a))
            hp.append((x + hx_ * 0.75 * s, y + hy_ * 0.75 * s))
        R.poly(hp, C('e23a5a'), INK, 2.5)
        R.dot(x - 4 * s, y - 4 * s, 2.5 * s, (255, 220, 230))

def rabbit(d, x, y, sc=1.0, flip=1, col=0, pose='sit', hop=0.0, face='open', ear=0.0, tilt=0.0, look=(0, 0), shadow_on=True, chew=0.0, blink=False):
    """pose: sit | hop | front | stand. hop: 0..1 phase (pose hop). ear: -1 droop .. 1 perk"""
    P = RAB[col % len(RAB)]
    fur, dk = P['fur'], P['dark']
    if pose == 'front':
        return rabbit_front(d, x, y, sc, col, hop, face, ear, tilt, shadow_on, blink)
    lift = 0.0; stretch = 1.0; bodyrot = 0.0; earback = 0.0
    if pose == 'hop':
        u = hop % 1.0
        lift = math.sin(math.pi * u) * 70
        stretch = 1.0 + 0.32 * math.sin(math.pi * u)
        bodyrot = -0.25 * math.cos(math.pi * u)
        earback = 0.5 + 0.4 * math.sin(math.pi * u)
    if shadow_on:
        k = 1 - 0.5 * lift / 70
        shadow(d.sub(Aff(x, y, sc)), 6, 2, 72 * k, 13 * k, 0.5)
    R = d.sub(Aff(x, y - lift * sc, sc, tilt + bodyrot * flip, flip))
    # hind foot
    R.ell(-6 - 10 * (stretch - 1) * 3, -8, 40 * (1.0 if pose != 'hop' else 0.9), 12, dk, INK, 4, ang=0.15 if pose == 'hop' else 0)
    # body
    bx = 6 * stretch
    R.ell(-6, -50, 60 * stretch, 46 / (0.5 + 0.5 * stretch), dk, INK, 5)
    R.ell(-10, -56, 52 * stretch, 38 / (0.5 + 0.5 * stretch), fur, None, 0)
    if P.get('belly'):
        R.ell(28 * stretch, -40, 22, 26, P['belly'], None, 0)
    if P.get('spots'):
        R.ell(-24, -64, 18, 13, P['spots'], None, 0); R.ell(6, -38, 10, 8, P['spots'], None, 0)
    # haunch line
    R.line(bez((-44, -30), (-26, -76), (6, -50), 10), dk, 3.5)
    # tail
    R.ell(-64 * stretch, -54, 17, 16, (250, 250, 250), INK, 4)
    # front paws
    pf = 14 if pose == 'hop' else 0
    R.ell(40 * stretch + pf, -10 - pf * 0.5, 13, 9, fur, INK, 3.5)
    R.ell(28 * stretch + pf * 0.6, -8 - pf * 0.3, 13, 9, fur, INK, 3.5)
    # head
    H = R.sub(Aff(46 * stretch, -104, 1, -0.15 * earback * 0.3))
    ea = ear
    for k, (exo, eang) in enumerate(((-8, -0.35), (12, -0.05))):
        a = eang - 0.9 * earback - 0.25 * (1 - ea) * (1 if ea < 0 else 0.3) - (0.9 if ea < -0.5 else 0)
        E = H.sub(Aff(exo, -26, 1, a))
        E.ell(0, -48, 15, 48, fur, INK, 4.5)
        E.ell(1, -44, 8, 36, P['ear'], None, 0)
    H.ell(0, 0, 44, 39, fur, INK, 5)
    H.ell(-6, -6, 36, 30, shade(fur, 1.03), None, 0)
    H.ell(20, 14, 16, 12, shade(fur, 1.06), None, 0)
    H.ell(-14, 16, 9, 6, C('f5b6b0'), None, 0)
    if blink and face in ('open', 'wide'): rab_eye(H, 12, -6, 1.0, 'closed', look)
    else: rab_eye(H, 12, -6, 1.0, face, look)
    # nose + mouth
    H.poly([(36, 8), (46, 8), (41, 15)], NOSE, INK, 2.5)
    my = 20 + chew * 3
    H.line(bez((41, 15), (38, my + 4), (32, my), 5), INK, 2.5)
    H.line(bez((41, 15), (44, my + 4), (48, my), 5), INK, 2.5)
    for k in (-1, 0, 1):
        H.line([(48, 12 + k * 5), (72, 6 + k * 9)], C('6a5a5a'), 1.6)

def rabbit_front(d, x, y, sc, col, hop, face, ear, tilt, shadow_on, blink):
    P = RAB[col % len(RAB)]
    fur, dk = P['fur'], P['dark']
    u = hop % 1.0
    lift = math.sin(math.pi * u) * 60 if hop else 0
    sq = 1 - 0.12 * math.cos(math.pi * 2 * u) if hop else 1
    if shadow_on: shadow(d.sub(Aff(x, y, sc)), 0, 2, 60 * (1 - lift / 120), 12, 0.5)
    R = d.sub(Aff(x, y - lift * sc, sc, tilt)).sub(np.array([[1 / sq, 0, 0], [0, sq, 0], [0, 0, 1]], float))
    R.ell(-26, -8, 18, 11, dk, INK, 4); R.ell(26, -8, 18, 11, dk, INK, 4)
    R.ell(0, -50, 52, 48, dk, INK, 5); R.ell(0, -56, 44, 40, fur, None, 0)
    if P.get('belly'): R.ell(0, -44, 26, 28, P['belly'], None, 0)
    R.ell(-16, -16, 12, 9, fur, INK, 3.5); R.ell(16, -16, 12, 9, fur, INK, 3.5)
    H = R.sub(Aff(0, -112, 1))
    eb = 0.7 * (1 - ear) if ear < 0 else 0
    for sd in (-1, 1):
        E = H.sub(Aff(sd * 18, -26, 1, sd * (0.22 + eb + 0.1 * math.sin(u * 6.28))))
        E.ell(0, -46, 15, 46, fur, INK, 4.5); E.ell(0, -42, 8, 34, P['ear'], None, 0)
    H.ell(0, 0, 46, 40, fur, INK, 5)
    H.ell(0, -6, 38, 30, shade(fur, 1.03), None, 0)
    for sd in (-1, 1): H.ell(sd * 28, 14, 8, 5, C('f5b6b0'), None, 0)
    f = 'closed' if blink and face in ('open', 'wide') else face
    rab_eye(H, -17, -6, 1.0, f); rab_eye(H, 17, -6, 1.0, f)
    H.poly([(-6, 10), (6, 10), (0, 17)], NOSE, INK, 2.5)
    H.line(bez((0, 17), (-3, 24), (-9, 22), 5), INK, 2.5); H.line(bez((0, 17), (3, 24), (9, 22), 5), INK, 2.5)
    for sd in (-1, 1):
        for k in (-1, 1): H.line([(sd * 16, 16 + k * 3), (sd * 46, 12 + k * 8)], C('6a5a5a'), 1.6)

# ---------------- PROPS ----------------
WOOD = C('a87444'); WOODD = C('7a4e2a'); WOODL = C('c99566')

def musket(B, h, ang=-0.2, ln=300, flip=1):
    x, y = h
    G = B.sub(Aff(x, y, 1, ang))
    G.poly([(-80, -8), (40, -10), (60, 14), (-70, 12)], WOODD, INK, 4)
    G.poly([(-80, -8), (-120, 4), (-118, 26), (-70, 12)], WOODD, INK, 4)
    G.poly([(40, -8), (ln - 80, -6), (ln - 80, 2), (40, 4)], C('6a6e78'), INK, 3)
    G.line([(0, -10), (14, -24)], C('4a4e58'), 4)

def whip(B, h, t, ang=0.0, crack=0.0):
    x, y = h
    G = B.sub(Aff(x, y, 1, ang))
    G.line([(0, 0), (0, -50)], WOODD, 9)
    pts = [(0, -50)]
    for k in range(1, 12):
        u = k / 11
        pts.append((math.sin(u * 3 + t * 9) * 60 * u * (1 - crack) + 160 * u * crack, -50 - 170 * u * (1 - crack * 0.6) + math.sin(u * 6) * 20))
    G.line(pts, C('3a2a1e'), 4)

def stick(B, h, ang=0.0):
    x, y = h
    G = B.sub(Aff(x, y, 1, ang))
    G.line([(0, 20), (0, -170)], WOODD, 11); G.line([(0, -90), (24, -120)], WOODD, 7)

def scroll(B, h, open_=1.0):
    x, y = h
    G = B.sub(Aff(x, y - 30, 1))
    w = 30 + 60 * open_
    G.poly([(-w, -40), (w, -40), (w, 40), (-w, 40)], C('f3e8c8'), INK, 3)
    for k in range(4): G.line([(-w + 14, -24 + k * 14), (w - 14, -24 + k * 14)], C('b8a888'), 2)
    G.ell(-w, 0, 9, 42, C('e2d2a6'), INK, 3); G.ell(w, 0, 9, 42, C('e2d2a6'), INK, 3)
    G.dot(w - 30, 26, 9, C('c8323a'))

def carrot(d, x, y, sc=1.0, rot=0.0):
    G = d.sub(Aff(x, y, sc, rot))
    G.poly([(-16, -10), (16, -10), (0, 70)], C('ef8a2a'), INK, 4)
    for k in range(3): G.line([(-10 + k * 3, 6 + k * 16), (2 + k * 2, 8 + k * 16)], C('c86a1e'), 2.5)
    for a in (-0.5, 0, 0.5):
        G.sub(Aff(0, -10, 1, a)).ell(0, -22, 7, 22, C('5aa83a'), INK, 3)

def cage(d, x, y, sc=1.0, open_u=0.0, inside=None, t=0.0):
    """wooden hutch crate with barred front; front door flips down with open_u"""
    G = d.sub(Aff(x, y, sc))
    G.poly([(-120, 0), (120, 0), (120, -150), (-120, -150)], WOODD, INK, 5)
    G.poly([(-104, -14), (104, -14), (104, -136), (-104, -136)], C('4a3424'), None)
    if inside is not None:
        for k, (ix, col) in enumerate(inside):
            rabbit(G, ix, -16, 0.55, 1 if k % 2 == 0 else -1, col, 'sit', face='open', shadow_on=False, look=(0, 0), blink=((t * 1.7 + k * 0.37) % 3) < 0.1)
    # door: rotate about bottom edge (y=0) toward camera: shrink vertically
    c = math.cos(open_u * math.pi * 0.5)
    Dd = G.sub(np.array([[1, 0, 0], [0, c if c > 0.02 else 0.02, 0], [0, 0, 1]], float))
    if open_u < 0.98:
        Dd.poly([(-108, 0), (108, 0), (108, -146), (-108, -146)], None, WOOD, 10)
        for k in range(7): Dd.line([(-90 + k * 30, -4), (-90 + k * 30, -142)], C('8f8a80'), 5)
        Dd.line([(-108, -73), (108, -73)], WOOD, 8)
    else:
        G.poly([(-108, 0), (108, 0), (108, 16), (-108, 16)], WOOD, INK, 4)
        for k in range(7): G.line([(-90 + k * 30, 2), (-90 + k * 30, 14)], C('8f8a80'), 4)
    G.poly([(-128, -150), (128, -150), (128, -168), (-128, -168)], WOODL, INK, 4)
    G.poly([(-128, 0), (-112, 0), (-112, -168), (-128, -168)], WOOD, INK, 4)
    G.poly([(128, 0), (112, 0), (112, -168), (128, -168)], WOOD, INK, 4)

def coach(d, x, y, sc=1.0, door=0.0, bounce=0.0, wheel_rot=0.0, window_heads=None, t=0.0, flip=1):
    """imperial coach facing right (flip=1). window_heads: list of draw callbacks drawn inside window"""
    shadow(d.sub(Aff(x, y, sc)), 0, 2, 300, 30, 0.45)
    G = d.sub(Aff(x, y, sc, 0, flip))
    for wx, r in ((-190, 110), (190, 90)):
        draw_wheel_c(G, wx, -r, r, wheel_rot)
    B = G.sub(Aff(0, -bounce, 1))
    B.poly([(-270, -150), (250, -150), (230, -230), (-250, -230)], C('1f3a2c'), INK, 5)
    body = [(-240, -230), (230, -230), (250, -380), (200, -480), (-210, -480), (-260, -380)]
    B.poly(body, C('2c513c'), INK, 6)
    B.poly([(-220, -250), (210, -250), (228, -380), (184, -460), (-190, -460), (-236, -380)], C('35614a'), None)
    B.line([(-246, -380), (238, -380)], GOLD, 7)
    B.line([(-230, -248), (222, -248)], GOLD, 7)
    # roof
    B.poly([(-226, -480), (216, -480), (190, -520), (-196, -520)], C('1d1a20'), INK, 5)
    for k in (-150, -50, 50, 150): B.dot(k, -500, 8, GOLD)
    # window (door in middle)
    B.poly([(-70, -440), (70, -440), (70, -330), (-70, -330)], C('f2d79a'), INK, 5)
    if window_heads:
        for fn in window_heads: fn(B)
    B.line([(0, -440), (0, -330)], INK, 4)
    # door panel with N crest
    c = math.cos(door * math.pi * 0.5)
    Dd = B.sub(Aff(-80, 0)).sub(np.array([[max(0.05, c), 0, 0], [0, 1, 0], [0, 0, 1]], float)).sub(Aff(80, 0))
    if door > 0.02:
        B.poly([(-80, -470), (80, -470), (80, -160), (-80, -160)], C('1a1418'), INK, 4)
        if window_heads:
            for fn in window_heads: fn(B)
    Dd.poly([(-80, -470), (80, -470), (80, -160), (-80, -160)], C('2c513c'), INK, 5)
    Dd.poly([(-70, -440), (70, -440), (70, -330), (-70, -330)], C('f2d79a') if door < 0.02 else C('d9b878'), INK, 5)
    if door < 0.02 and window_heads:
        for fn in window_heads: fn(B)
        B.poly([(-70, -440), (70, -440), (70, -330), (-70, -330)], None, INK, 6)
    Dd.ell(0, -250, 42, 42, GOLD, INK, 4); Dd.ell(0, -250, 32, 32, C('2b3f80'), None, 0)
    world_N(Dd, 0, -250)
    # lantern
    B.line([(236, -380), (270, -400)], INK, 5)
    B.poly([(262, -440), (290, -440), (292, -390), (260, -390)], C('ffd27a'), INK, 4)

def world_N(G, x, y):
    G.poly([(x - 16, y + 18), (x - 16, y - 18), (x - 8, y - 18), (x + 8, y + 6), (x + 8, y - 18), (x + 16, y - 18), (x + 16, y + 18), (x + 8, y + 18), (x - 8, y - 6), (x - 8, y + 18)], GOLD, None)

def draw_wheel_c(G, x, y, r, rot):
    W_ = G.sub(Aff(x, y, 1, rot))
    W_.ell(0, 0, r, r, C('2a2320'), INK, 5)
    W_.ell(0, 0, r - 14, r - 14, C('b8902e'), INK, 3)
    W_.ell(0, 0, r - 20, r - 20, C('6a4a2a'), None, 0)
    for i in range(12):
        a = i * 2 * math.pi / 12
        W_.line([(0, 0), (math.cos(a) * (r - 18), math.sin(a) * (r - 18))], C('d0a83a'), 6)
    W_.ell(0, 0, r * 0.18, r * 0.18, GOLD, INK, 3)

def raft(d, x, y, sc=1.0, t=0.0):
    G = d.sub(Aff(x, y + math.sin(t * 1.6) * 4, sc))
    for k in range(-6, 7):
        G.poly([(k * 50 - 24, 0), (k * 50 + 24, 0), (k * 50 + 24, 40), (k * 50 - 24, 40)], C('8a5a32') if k % 2 else C('9a6a3e'), INK, 4)
    G.poly([(-330, -6), (330, -6), (330, 8), (-330, 8)], C('b07a48'), INK, 4)

def pavilion(d, x, y, sc=1.0, t=0.0):
    G = d.sub(Aff(x, y + math.sin(t * 1.6) * 4, sc))
    G.poly([(-250, 0), (250, 0), (250, -420), (-250, -420)], C('f4efe4'), INK, 5)
    for k in range(-4, 5): G.line([(k * 55, -10), (k * 55, -410)], C('ddd4c2'), 3)
    G.poly([(-280, -420), (280, -420), (0, -620)], C('f4efe4'), INK, 5)
    G.poly([(-280, -420), (280, -420), (270, -390), (-270, -390)], C('2b4aa8'), INK, 4)
    for k in range(-5, 6): G.ell(k * 50, -386, 22, 14, C('2b4aa8'), INK, 3)
    # eagle-ish gold finial
    G.line([(0, -620), (0, -680)], GOLD, 7); G.ell(0, -690, 22, 16, GOLD, INK, 3)
    G.poly([(-20, -692), (-60, -720), (-30, -688)], GOLD, INK, 3); G.poly([(20, -692), (60, -720), (30, -688)], GOLD, INK, 3)
    G.ell(0, -250, 70, 70, GOLD, INK, 4); G.ell(0, -250, 56, 56, C('2b4aa8'), None, 0); world_N(G.sub(Aff(0, 0, 1)), 0, -250)
    G.sub(Aff(0, -250, 2.4)).poly([(-16, 18), (-16, -18), (-8, -18), (8, 6), (8, -18), (16, -18), (16, 18), (8, 18), (-8, -6), (-8, 18)], GOLD, None)

def flag(d, x, y, sc, t, cols=(C('2b4aa8'), C('f4f1ea'), C('d9323a'))):
    G = d.sub(Aff(x, y, sc))
    G.line([(0, 0), (0, -420)], C('5a3a20'), 10)
    G.ell(0, -428, 12, 12, GOLD, INK, 3)
    for k, c in enumerate(cols):
        pts = []
        for j in range(9):
            u = j / 8; xx = 6 + u * 230
            wav = math.sin(u * 5 - t * 7) * 18 * u
            pts.append((xx + k * 0, -410 + wav))
        top = [(6 + (k / 3) * 230 + 0, 0)]
        xa = 6 + k * 230 / 3; xb = 6 + (k + 1) * 230 / 3
        poly = []
        for j in range(7):
            u = j / 6; xx = lerp(xa, xb, u); uu = (xx - 6) / 230
            poly.append((xx, -410 + math.sin(uu * 5 - t * 7) * 18 * uu))
        for j in range(7):
            u = 1 - j / 6; xx = lerp(xa, xb, u); uu = (xx - 6) / 230
            poly.append((xx, -260 + math.sin(uu * 5 - t * 7) * 18 * uu))
        G.poly(poly, c, INK, 4)

def rock(d, x, y, sc=1.0):
    G = d.sub(Aff(x, y, sc))
    G.poly([(-300, 0), (-260, -120), (-140, -200), (60, -210), (220, -150), (300, 0)], C('7a6a62'), INK, 6)
    G.poly([(-250, -20), (-220, -110), (-120, -180), (40, -190), (180, -140), (250, -20)], C('8f7f74'), None)
    G.line([(-120, -180), (-60, -60), (-90, 0)], C('5e524c'), 4); G.line([(60, -200), (90, -100)], C('5e524c'), 4)

def dinner_bell(d, x, y, sc, swing):
    G = d.sub(Aff(x, y, sc, swing))
    G.line([(0, -60), (0, -100)], WOODD, 10)
    G.poly(list(bez((-50, 40), (-46, -60), (0, -66), 10)) + list(bez((0, -66), (46, -60), (50, 40), 10)), GOLD, INK, 5)
    G.ell(0, 40, 54, 12, shade(GOLD, 0.85), INK, 4); G.ell(0, 52, 12, 12, C('8a6a2a'), INK, 3)

def rabbit_back(d, x, y, sc=1.0, col=0, hop=0.0, ear=0.0):
    P = RAB[col % len(RAB)]
    fur, dk = P['fur'], P['dark']
    lift = math.sin(math.pi * (hop % 1.0)) * 40 if hop else 0
    R = d.sub(Aff(x, y - lift * sc, sc))
    R.ell(0, -50, 56, 50, dk, INK, 5); R.ell(0, -54, 48, 42, fur, None, 0)
    R.ell(0, -30, 16, 15, (250, 250, 250), INK, 4)
    H = R.sub(Aff(0, -112, 1))
    for sd in (-1, 1):
        E = H.sub(Aff(sd * 18, -26, 1, sd * (0.18 + 0.1 * ear)))
        E.ell(0, -46, 15, 46, fur, INK, 4.5); E.ell(0, -44, 6, 30, shade(fur, 0.9), None, 0)
    H.ell(0, 0, 46, 40, fur, INK, 5); H.ell(-6, -8, 36, 28, shade(fur, 1.04), None, 0)
