import numpy as np, cv2, math, json, sys, os, random, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from props import *
import look as LK

W, H, FPS = 1080, 1920, 30
DUR = 45.0
NF = int(round(DUR * FPS))
S = float(os.environ.get('S', '0.3333333'))
OW, OH = int(round(W * S)), int(round(H * S))
MARG = 420
def rng(seed): return random.Random(seed)

# ======================= BACKGROUNDS (painted, textured, hazed) =======================
_bg = {}; BGOFF = {}
def gradient(img, y0, y1, c0, c1):
    for y in range(max(0, y0), min(img.shape[0], y1)):
        u = (y - y0) / max(1, y1 - y0)
        img[y, :] = [int(lerp(c0[i], c1[i], u)) for i in range(3)]

def hills(d, XL, XR, base, amp, col, f1, f2, ph, ol=None):
    xs = np.linspace(XL, XR, 220)
    ys = base - amp * (0.5 + 0.5 * np.sin(xs / f1 + ph)) - amp * 0.35 * np.sin(xs / f2 + ph * 2)
    pts = np.concatenate([np.stack([xs, ys], 1), [[XR, base + 2400], [XL, base + 2400]]])
    d.poly(pts, col, ol, 4 if ol else 0)

def tree(d, x, y, sc, col, dark, trunk=C('6a4a2e'), ol=INK):
    G = d.sub(Aff(x, y, sc))
    G.poly([(-12, 0), (12, 0), (9, -110), (-9, -110)], trunk, ol, 4)
    for (bx, by, r) in ((0, -190, 95), (-60, -140, 70), (60, -140, 70), (-30, -250, 60), (35, -245, 62)):
        G.ell(bx, by, r, r * 0.9, dark, ol, 4)
    for (bx, by, r) in ((-10, -200, 70), (-55, -150, 45), (48, -150, 48), (-28, -250, 40), (30, -248, 42)):
        G.ell(bx - 8, by - 8, r, r * 0.85, col, None, 0)

def tent(d, x, y, sc, col=C('f2ece0')):
    G = d.sub(Aff(x, y, sc))
    G.poly([(-90, 0), (90, 0), (0, -150)], col, INK, 4)
    G.poly([(-10, 0), (10, 0), (0, -150)], shade(col, 0.8), None)
    G.line([(0, -150), (0, -200)], C('5a3a20'), 4)
    G.poly([(0, -200), (40, -190), (0, -178)], C('d9323a'), None)

def soldiers_row(d, XL, XR, y, sc, col, gap=34, seed=1):
    r = rng(seed)
    x = XL
    while x < XR:
        G = d.sub(Aff(x, y, sc))
        G.poly([(-9, 0), (9, 0), (8, -40), (-8, -40)], col, None)
        G.ell(0, -48, 8, 8, col, None, 0)
        G.poly([(-13, -52), (13, -52), (0, -62)], col, None)
        G.line([(10, -30), (14, -86)], col, 2)
        x += gap * (0.8 + 0.4 * r.random())

def grass_strokes(d, XL, XR, y0, y1, n, col_a, col_b, seed=3, h=26):
    r = rng(seed)
    for i in range(n):
        x = r.uniform(XL, XR); y = r.uniform(y0, y1)
        k = (y - y0) / max(1, y1 - y0)
        hh = h * (0.5 + k)
        c = col_a if r.random() < 0.5 else col_b
        d.line([(x, y), (x + r.uniform(-8, 8), y - hh)], c, 2 + 2 * k)

def flowers(d, XL, XR, y0, y1, n, seed=4):
    r = rng(seed)
    cols = [C('fff6e8'), C('ffd84a'), C('f28aa0'), C('b9a0f0')]
    for i in range(n):
        x = r.uniform(XL, XR); y = r.uniform(y0, y1); k = (y - y0) / max(1, y1 - y0)
        rr = 3 + 6 * k
        d.dot(x, y, rr, cols[i % 4]); d.dot(x, y, rr * 0.4, C('f2b03a'))

HZ = 1060
def bgimg(kind):
    if kind in _bg: return _bg[kind]
    if kind.endswith('_blur'):
        b = bgimg(kind[:-5]); k = int(30 * S) | 1
        BGOFF[kind] = BGOFF[kind[:-5]]
        _bg[kind] = cv2.GaussianBlur(b, (k, k), 0); return _bg[kind]
    mxl, mxr = {'meadow': (1500, 3600), 'sunset': (600, 600), 'river': (700, 700), 'barn': (600, 600), 'burrow': (600, 600)}[kind]
    BGOFF[kind] = (mxl, MARG)
    bw, bh = int((W + mxl + mxr) * S), int((H + 2 * MARG) * S)
    img = np.zeros((bh, bw, 3), np.uint8)
    d = D(img, Aff(mxl * S, MARG * S, S))
    XL, XR = -mxl, W + mxr
    Y = lambda y: int((MARG + y) * S)
    r = rng(hash(kind) % 997)
    if kind == 'meadow':
        gradient(img, 0, Y(600), C('4f98da'), C('9cc8ea')); gradient(img, Y(600), Y(HZ), C('9cc8ea'), C('f4d9ae'))
        for i in range(22):
            cx = r.uniform(XL, XR); cy = r.uniform(80, 640); s_ = r.uniform(0.7, 1.4)
            for j in range(5): d.ell(cx + (j - 2) * 64 * s_, cy + (0 if j % 2 else -26) * s_, 84 * s_, 44 * s_, C('fffaf0'), None, 0)
            d.ell(cx, cy + 22 * s_, 150 * s_, 20 * s_, C('eef0f6'), None, 0)
        LK.blur_all(img, 3 * S * 3)
        hills(d, XL, XR, HZ - 40, 130, C('9cb7c8'), 260, 97, 0.3)            # far blue range
        LK.haze(img, 0, Y(HZ), C('f6e2c0'), 0.0, 0.25)
        for i in range(60):
            x = XL + i * (XR - XL) / 60 + r.uniform(-20, 20)
            tree(d, x, HZ - 10 + r.uniform(-10, 10), r.uniform(0.28, 0.4), C('86a87a'), C('6f9070'), C('6a5a4e'), None)
        # far camp: tents + tiny flags (left)
        for i in range(14): tent(d, -1300 + i * 95 + r.uniform(-20, 20), HZ + 10 + (i % 3) * 8, 0.32 + 0.04 * (i % 3), C('eee4d4'))
        LK.blur_all(img, 2 * S * 3)
        hills(d, XL, XR, HZ + 40, 70, C('9cbf62'), 330, 120, 1.7, C('5a7a34'))       # mid hill
        gradient_sub = None
        g0 = Y(HZ - 80)
        gm = np.zeros_like(img); gradient(gm, g0, bh, C('a8c866'), C('5f8f38'))
        m = np.zeros(img.shape[:2], np.uint8)
        xs = np.linspace(XL, XR, 220); ys = HZ + 40 - 70 * (0.5 + 0.5 * np.sin(xs / 330 + 1.7)) - 70 * 0.35 * np.sin(xs / 120 + 3.4)
        pts = d.tp(np.concatenate([np.stack([xs, ys], 1), [[XR, HZ + 2400], [XL, HZ + 2400]]]))
        cv2.fillPoly(m, [(pts * 16).astype(np.int32)], 255, cv2.LINE_AA, shift=4)
        mf = (m.astype(np.float32) / 255)[..., None]
        img[:] = (img * (1 - mf) + gm * mf).astype(np.uint8)
        for i in range(26):
            x = XL + r.uniform(0, XR - XL); y = HZ + 20 + r.uniform(0, 40)
            tree(d, x, y, r.uniform(0.55, 0.8), C('6fa64a'), C('4f8238'))
        grass_strokes(d, XL, XR, HZ + 80, H + MARG, 5200, C('7aa848'), C('4f7f30'), 3, 30)
        flowers(d, XL, XR, HZ + 120, H + MARG, 700)
        for i in range(90):
            x = r.uniform(XL, XR); y = r.uniform(HZ + 100, H + MARG); k = (y - HZ) / (H + MARG - HZ)
            ov = img.copy(); D(ov, d.M).ell(x, y, 160 + 400 * k, 40 + 90 * k, C('4f7f2e') if i % 2 else C('b8d878'), None, 0)
            img[:] = cv2.addWeighted(ov, 0.18, img, 0.82, 0)
        for i in range(40):
            x = r.uniform(XL, XR); y = r.uniform(HZ + 120, H + MARG); k = (y - HZ) / (H + MARG - HZ); s_ = 0.3 + 0.9 * k
            if i % 3 == 0:
                d.ell(x, y - 10 * s_, 50 * s_, 26 * s_, C('9a9088'), INK, 3); d.ell(x - 10 * s_, y - 18 * s_, 30 * s_, 12 * s_, C('b4aaa0'), None, 0)
            else:
                for j in range(4): d.ell(x + (j - 1.5) * 34 * s_, y - (30 + (j % 2) * 18) * s_, 46 * s_, 40 * s_, C('4f8a36'), INK, 3)
                for j in range(4): d.ell(x + (j - 1.5) * 34 * s_ - 6 * s_, y - (36 + (j % 2) * 18) * s_, 32 * s_, 26 * s_, C('6aa448'), None, 0)
        LK.paint_texture(img, 2, 0.07, 0.025)
    elif kind == 'sunset':
        gradient(img, 0, Y(700), C('3b2d63'), C('c4587a'))
        gradient(img, Y(700), Y(1180), C('c4587a'), C('ffb35a'))
        sx, sy = 690, 1060
        for rr_, a in ((420, 0.10), (280, 0.18), (190, 0.28)):
            ov = img.copy(); D(ov, d.M).ell(sx, sy, rr_, rr_, C('ffd98a'), None, 0); img[:] = cv2.addWeighted(ov, a, img, 1 - a, 0)
        d.ell(sx, sy, 130, 130, C('fff0c0'), None, 0)
        for i in range(10):
            cx = r.uniform(XL, XR); cy = r.uniform(200, 800); s_ = r.uniform(0.8, 1.6)
            d.ell(cx, cy, 220 * s_, 26 * s_, C('e88a7a') if cy > 500 else C('8a5a8a'), None, 0)
        hills(d, XL, XR, 1150, 140, C('8a4a6a'), 210, 80, 0.4)
        LK.haze(img, Y(900), Y(1180), C('ffb070'), 0.0, 0.35)
        hills(d, XL, XR, 1230, 60, C('5e3352'), 300, 110, 2.2)
        for row, (yy, sc_, col) in enumerate(((1225, 0.5, C('4a2846')), (1290, 0.65, C('3e2140')), (1370, 0.85, C('321a36')))):
            soldiers_row(d, XL, XR, yy, sc_, col, 30 + row * 10, row + 3)
        d.poly([(XL, 1380), (XR, 1380), (XR, H + MARG), (XL, H + MARG)], C('2e1a30'), None)
        LK.paint_texture(img, 5, 0.06, 0.02)
    elif kind == 'river':
        gradient(img, 0, Y(980), C('7cb8e8'), C('fde3b8'))
        for i in range(14):
            cx = r.uniform(XL, XR); cy = r.uniform(120, 700); s_ = r.uniform(0.7, 1.3)
            for j in range(5): d.ell(cx + (j - 2) * 64 * s_, cy + (0 if j % 2 else -24) * s_, 84 * s_, 42 * s_, C('fffaf0'), None, 0)
        LK.blur_all(img, 3)
        hills(d, XL, XR, 960, 60, C('a3bccb'), 240, 90, 1.0)
        LK.haze(img, 0, Y(980), C('f6e2c0'), 0.0, 0.2)
        d.poly([(XL, 980), (XR, 980), (XR, 1040), (XL, 1040)], C('8fb35a'), None)
        for i in range(26): tent(d, XL + i * 110 + r.uniform(-20, 20), 1000, 0.28, C('f2ece0'))
        soldiers_row(d, XL, XR, 1036, 0.42, C('3a3a5a'), 18, 7)
        gradient(img, Y(1040), bh, C('6fa8c8'), C('2f6a8a'))
        for i in range(500):
            x = r.uniform(XL, XR); y = r.uniform(1050, H + MARG); k = (y - 1040) / (H + MARG - 1040)
            ln = 20 + 90 * k
            d.line([(x, y), (x + ln, y)], C('a8d6ea') if i % 3 else C('2a5a78'), 2 + 3 * k)
        LK.paint_texture(img, 7, 0.05, 0.03)
    elif kind == 'barn':
        gradient(img, 0, bh, C('8a5a34'), C('5a3a22'))
        for i in range(-20, 30):
            x = i * 90
            d.line([(x, -MARG), (x, H + MARG)], C('4a2e1a'), 5)
            for k in range(6):
                d.dot(x + 45, -200 + k * 420 + (i % 3) * 60, 4, C('3a2414'))
        d.poly([(560, 300), (900, 300), (900, 640), (560, 640)], C('ffe9b0'), INK, 8)
        d.line([(730, 300), (730, 640)], C('6a4428'), 10); d.line([(560, 470), (900, 470)], C('6a4428'), 10)
        d.poly([(XL, 1380), (XR, 1380), (XR, H + MARG), (XL, H + MARG)], C('d8b25a'), None)
        grass_strokes(d, XL, XR, 1380, H + MARG, 2500, C('e8c86a'), C('b88e3a'), 5, 26)
        LK.paint_texture(img, 9, 0.07, 0.03)
    elif kind == 'burrow':
        gradient(img, 0, Y(HZ), C('5a6aa8'), C('f2a86a'))
        hills(d, XL, XR, HZ, 120, C('6a6a8a'), 240, 90, 0.3)
        for i in range(30):
            tree(d, XL + i * 85 + r.uniform(-20, 20), HZ + 30, r.uniform(0.5, 0.8), C('5a7a4a'), C('3e5e36'))
        d.poly([(XL, HZ + 60), (XR, HZ + 60), (XR, H + MARG), (XL, H + MARG)], C('6a8a3a'), None)
        grass_strokes(d, XL, XR, HZ + 60, H + MARG, 3000, C('7a9a48'), C('4a6a28'), 6, 34)
        LK.paint_texture(img, 11, 0.07, 0.03)
    _bg[kind] = img
    return img

VIG = None
def vignette():
    global VIG
    if VIG is None:
        y, x = np.mgrid[0:OH, 0:OW]
        rr = np.sqrt(((x - OW / 2) / (OW / 2)) ** 2 + ((y - OH / 2) / (OH / 2)) ** 2)
        VIG = (1 - 0.34 * np.clip(rr - 0.45, 0, 1) ** 1.4)[..., None].astype(np.float32)
    return VIG

# ======================= CAMERA =======================
def cam_keys(keys, t):
    if t <= keys[0][0]: return keys[0][1:5]
    for a, b in zip(keys, keys[1:]):
        if t <= b[0]:
            u = (t - a[0]) / max(1e-6, b[0] - a[0])
            e = b[5] if len(b) > 5 else 's'
            u = smooth(u) if e == 's' else eout(u) if e == 'o' else u
            return tuple(lerp(a[i], b[i], u) for i in range(1, 5))
    return keys[-1][1:5]

def camM(cx, cy, z, rot, shake=(0, 0)):
    return Aff(0, 0, S) @ Aff(W / 2 + shake[0], H / 2 + shake[1]) @ Aff(0, 0, z, rot) @ Aff(-cx, -cy)

def shake_at(t, kicks, amp=16):
    sx = sy = 0
    for k in kicks:
        a0 = amp
        if isinstance(k, tuple): k, a0 = k
        dt = t - k
        if 0 <= dt < 0.3:
            a = a0 * (1 - dt / 0.3)
            sx += a * math.sin(dt * 90); sy += a * math.cos(dt * 70)
    return sx, sy

# ======================= HUD =======================
def hud_text(img, txt, x, y, size, rgb=(255, 255, 255), scale=1.0, alpha=1.0, rot=0.0, font=None):
    spr = text_sprite(txt, int(size * S), rgb, 0.14, font)
    blit(img, spr, x * S, y * S, scale, alpha, rot)

def pop(t, t0, dur=0.25):
    if t < t0: return 0.0
    return back((t - t0) / dur, 2.2)

def tag(img, txt, t, t0, t1, y=190, col=(255, 214, 64), size=50):
    if t < t0 or t > t1: return
    a = clamp((t - t0) / 0.15) * clamp((t1 - t) / 0.2)
    sc = 0.6 + 0.4 * pop(t, t0, 0.3)
    w = len(txt) * size * 0.56 + 70
    ov = img.copy(); D(ov, Aff(0, 0, S)).poly([(540 - w / 2 * sc, y - 40 * sc), (540 + w / 2 * sc, y - 40 * sc), (540 + w / 2 * sc, y + 40 * sc), (540 - w / 2 * sc, y + 40 * sc)], C('2a1a2a'), None)
    img[:] = cv2.addWeighted(ov, 0.6 * a, img, 1 - 0.6 * a, 0)
    hud_text(img, txt, 540, y, size, col, sc, a)

def stamp(img, txt, x, y, t, t0, rot=-0.12, size=96, col=C('e23b3b')):
    if t < t0: return
    u = clamp((t - t0) / 0.18)
    sc = lerp(2.2, 1.0, eout(u))
    spr = text_sprite(txt, int(size * S), col[::-1], 0.10, None, (255, 255, 255))
    blit(img, spr, x * S, y * S, sc, clamp(u * 2), rot)

def bubble(img, x, y, r, t, t0, inner=None):
    if t < t0: return
    p = pop(t, t0, 0.35)
    hd = D(img, Aff(0, 0, S))
    for k, (dx, dy, rr) in enumerate(((-r * 0.9, r * 1.05, 18), (-r * 0.65, r * 0.82, 28))):
        if p > 0.3 + k * 0.2: hd.ell(x + dx, y + dy, rr, rr, C('fffaf2'), INK, 5)
    G = hd.sub(Aff(x, y, p))
    pts = [(math.cos(a) * r * (1 + 0.06 * math.sin(a * 9)), math.sin(a) * r * 0.82 * (1 + 0.06 * math.sin(a * 9))) for a in np.linspace(0, 2 * math.pi, 60, endpoint=False)]
    G.poly(pts, C('fffaf2'), INK, 6)
    if inner and p > 0.5: inner(G)

def cross_out(img, x, y, sz, t, t0, col=C('e23b3b')):
    if t < t0: return
    d = D(img, Aff(0, 0, S)).sub(Aff(x, y))
    u = clamp((t - t0) / 0.15); d.line([(-sz, -sz), (lerp(-sz, sz, u), lerp(-sz, sz, u))], col, 22)
    if u >= 1:
        v = clamp((t - t0 - 0.15) / 0.15); d.line([(sz, -sz), (lerp(sz, -sz, v), lerp(-sz, sz, v))], col, 22)

def check(img, x, y, sz, t, t0, col=C('3bbf5a')):
    if t < t0: return
    d = D(img, Aff(0, 0, S)).sub(Aff(x, y, pop(t, t0, 0.3)))
    d.line([(-sz, 0), (-sz * 0.3, sz * 0.7), (sz, -sz * 0.8)], C('ffffff'), 34)
    d.line([(-sz, 0), (-sz * 0.3, sz * 0.7), (sz, -sz * 0.8)], col, 22)

def clip_draw(img, M, poly_world, fn):
    before = img.copy(); fn()
    p = (np.asarray(poly_world, float) @ M[:2, :2].T + M[:2, 2])
    m = np.zeros(img.shape[:2], np.uint8)
    cv2.fillPoly(m, [(p * 16).astype(np.int32)], 255, cv2.LINE_AA, shift=4)
    mf = (m.astype(np.float32) / 255)[..., None]
    img[:] = (before * (1 - mf) + img * mf).astype(np.uint8)

# ======================= HELPERS =======================
def nap(d, x, y, sc, **kw):
    kw.setdefault('face', 'open'); kw.setdefault('mouth', 'smirk')
    return human(d, x, y, sc, 'napoleon', **kw)

def blinkat(t, times): return any(0 <= t - k < 0.12 for k in times)
def blink_auto(t, ph=0.0): return ((t + ph) % 3.1) < 0.11

def rab_field(d, t, n, seed, x0, x1, y0, y1, base=0.6, pose='sit', face='open', look=(0, 0), hopping=False, flip=None, ear=0.0, skip=()):
    r = rng(seed); items = []
    for i in range(n):
        items.append((r.uniform(y0, y1), r.uniform(x0, x1), r.uniform(0, 1), i, r.choice([1, -1]) if flip is None else flip, r.randrange(6)))
    items.sort()
    for y, x, ph, i, fl, col in items:
        if i in skip: continue
        k = (y - y0) / max(1, y1 - y0)
        sc = base * (0.55 + 0.45 * k)
        if hopping:
            rabbit(d, x, y, sc, fl, col, 'hop', hop=(t * 2.2 + ph) % 1.0, face=face, ear=ear)
        else:
            rabbit(d, x, y, sc, fl, col, pose, face=face, look=look, ear=ear, blink=blink_auto(t, ph * 3), chew=(math.sin(t * 18 + i) > 0.6) * 1.0)
    return items

def fg_grass(d, t, XL, XR, y, h, n=40, seed=8, col=C('4f7f30'), col2=C('6f9f40')):
    r = rng(seed)
    for i in range(n):
        x = r.uniform(XL, XR); hh = h * r.uniform(0.6, 1.25); w = r.uniform(5, 9) * (h / 70) ** 0.5
        sw = math.sin(t * 1.8 + i) * 0.12 * hh + r.uniform(-0.25, 0.25) * hh
        c = col if i % 2 else col2
        tip = (x + sw, y - hh)
        pts = list(bez((x - w, y), (x - w * 0.5 + sw * 0.3, y - hh * 0.6), tip, 8)) + list(bez(tip, (x + w * 0.5 + sw * 0.3, y - hh * 0.6), (x + w, y), 8))
        d.poly(pts, c, None)

# ======================= SHOTS =======================
SH = []
def shot(t0, t1, bg=None, **kw):
    def deco(fn):
        SH.append(dict(t0=t0, t1=t1, cam=fn, bg=bg, **kw)); return fn
    return deco
def reg(**kw): SH[-1].update(kw)

SUN_MEADOW = (260, 330)

# ---- A hero 0 - 2.92
@shot(0.0, 2.92, 'sunset', sun=(690, 1060), rays=0.30, raycol=(110, 190, 255), spread=2.4, motes=0.9, motecol=(150, 210, 255))
def cA(t, lt): return [(0, 540, 1170, 1.16, 0.0), (2.92, 540, 1120, 1.34, 0.0)], [(0.02, 10)]
def dA(d, t, lt):
    rock(d, 540, 1990, 1.75)
    flag(d, 790, 1650, 1.5, t)
    shadow(d, 560, 1612, 120, 18, 0.45)
    nap(d, 540, 1610, 1.95, armR=(54, 52), armL=(22, 70), brow=0.0, look=(-2, 0), mouth='smirk', bob=math.sin(t * 2) * 2, tilt=0.03)
def hA(img, t, lt):
    a = 1.0 if lt < 2.55 else clamp((2.92 - lt) / 0.35)
    pul = 1 + 0.025 * math.sin(lt * 6)
    hud_text(img, 'NAPOLEON', 540, 250, 130, (255, 255, 255), pul * (0.7 + 0.3 * pop(t, 0.0, 0.35)), a)
    hud_text(img, 'VS. BUNNIES', 540, 400, 118, (255, 214, 64), pul * pop(t, 0.35, 0.35), a)
reg(draw=dA, hud=hA)

# ---- B one bunny / bunnies pop 2.92 - 6.64
POPB = [(-120, 1470, 0), (60, 1440, 1), (230, 1490, 2), (400, 1450, 3), (760, 1460, 4), (930, 1440, 5), (1120, 1480, 1), (150, 1560, 3),
        (880, 1570, 2), (-40, 1600, 4), (1060, 1610, 0), (320, 1580, 5), (700, 1590, 1), (520, 1430, 2)]
@shot(2.92, 6.64, 'meadow', blur=True, sun=SUN_MEADOW, rays=0.16, motes=1.0)
def cB(t, lt): return [(0, 540, 1585, 2.25, 0.0), (1.85, 540, 1590, 2.4, 0.0), (2.55, 540, 1330, 1.4, 0.0, 'o'), (3.72, 540, 1335, 1.36, 0.0)], [(1.9, 8)]
def dB(d, t, lt):
    for i, (x, y, col) in enumerate(sorted(POPB, key=lambda q: q[1])):
        t0 = 4.92 + (i * 0.061) % 0.9
        if t < t0: continue
        p = back(clamp((t - t0) / 0.28), 2.4)
        rabbit(d, x, y + (1 - p) * 120, 0.62 * max(0.05, p), 1, col, 'front', face='wide' if i % 3 else 'open', blink=blink_auto(t, i), shadow_on=p > 0.9)
    fg_grass(d, t, -300, 1400, 1500, 60, 160, 2)
    fg_grass(d, t, -300, 1400, 1620, 70, 160, 3)
    hop = clamp((t - 4.80) / 0.42) if 4.80 <= t < 5.22 else 0.0
    rabbit(d, 540, 1720, 1.05, 1, 0, 'front', hop=hop, face='open' if t < 4.8 else 'wide', ear=1.0 if t > 4.8 else 0.2, blink=blinkat(t, (3.6, 5.9)))
    fg_grass(d, t, 300, 800, 1760, 50, 40, 4)
def pB(img, t, lt, M):
    def fg():
        dd = D(img, M); fg_grass(dd, t, -200, 1300, 1990, 330, 30, 9, C('3e6a26'), C('4f7f30'))
    LK.dof_layer(img, fg, 40 * S * 3)
reg(draw=dB, post=pB)

# ---- C Tilsit raft 6.64 - 10.03
@shot(6.64, 10.03, 'river', sun=(880, 260), rays=0.16, motes=0.6)
def cC(t, lt): return [(0, 540, 1130, 1.15, 0.0), (3.39, 540, 1145, 1.3, 0.0)], []
def dC(d, t, lt):
    raft(d, 540, 1440, 1.2, t)
    pavilion(d, 540, 1425, 0.78, t)
    bob = math.sin(t * 1.6) * 4
    shake = math.sin(t * 13) * 6 if 8.0 < t < 9.3 else 0
    reach = smooth(clamp((t - 7.6) / 0.4))
    nap(d, 400, 1430 + bob, 0.98, armL=(lerp(25, 98, reach) + shake, lerp(70, 78, reach)), armR=(54, 52), mouth='smile', look=(3, 0), flip=1)
    human(d, 680, 1430 + bob, 0.98, 'tsar', face='open', mouth='smile', armR=(lerp(-25, -98, reach) - shake, lerp(70, 78, reach)), armL=(20, 70), look=(-3, 0))
def hC(img, t, lt):
    tag(img, 'TILSIT · JULY 1807', t, 6.7, 9.95)
    if t >= 8.5:
        p = pop(t, 8.5, 0.35)
        dd = D(img, Aff(0, 0, S)).sub(Aff(540, 420, p * 1.9))
        scroll(dd, (0, 30), 1.6)
        hud_text(img, 'PEACE', 540, 372, 90, (90, 50, 30), p)
        if t > 8.85: stamp(img, 'SIGNED', 660, 470, t, 8.85, -0.2, 70)
reg(draw=dC, hud=hC)

# ---- D Napoleon wants a hunt 10.03 - 12.90
@shot(10.03, 12.90, 'meadow', blur=True, sun=SUN_MEADOW, rays=0.18, motes=1.0)
def cD(t, lt): return [(0, 540, 1270, 1.85, 0.0), (2.87, 540, 1262, 2.02, 0.0)], [(1.35, 6)]
def dD(d, t, lt):
    rub = math.sin(t * 16) * 9 if t > 11.2 else 0
    happy = t > 11.25
    tent(d, 120, 1460, 1.4); tent(d, 1000, 1470, 1.2)
    nap(d, 540, 1580, 1.5, armL=(150 + rub, 60) if happy else (25, 70), armR=(-150 + rub, 60) if happy else (54, 52),
        face='happy' if happy else 'open', mouth='grin' if happy else 'smile', brow=1 if happy else 0, bob=abs(math.sin(t * 8)) * 6 if happy else 0,
        look=(4, -3) if not happy else (0, 0))
def hD(img, t, lt):
    def inner(G):
        rabbit(G, 10, 90, 0.95, 1, 1, 'sit', face='open')
        G.ell(30, 10, 120, 120, None, C('e23b3b'), 8); G.line([(-110, 10), (170, 10)], C('e23b3b'), 5); G.line([(30, -120), (30, 140)], C('e23b3b'), 5)
    bubble(img, 790, 330, 190, t, 11.15, inner)
reg(draw=dD, hud=hD)

# ---- E Berthier + cages 12.90 - 16.60
def cage_rows(d, t, x0, x1, y, sc, seed, open_t=None):
    r = rng(seed); x = x0; k = 0
    while x < x1:
        ins = [(-50, r.randrange(6)), (40, r.randrange(6))]
        ou = smooth(clamp((t - open_t - k * 0.04) / 0.25)) if open_t is not None else 0.0
        cage(d, x, y, sc, ou, ins, t + k)
        x += 270 * sc; k += 1
@shot(12.90, 16.60, 'meadow', sun=SUN_MEADOW, rays=0.16, motes=0.9)
def cE(t, lt): return [(0, 560, 1317, 1.25, 0.0), (1.7, 600, 1317, 1.25, 0.0), (3.3, 1620, 1290, 0.82, 0.0), (3.7, 1660, 1290, 0.8, 0.0)], []
def dE(d, t, lt):
    cage_rows(d, t, 1150, 3000, 1420, 0.5, 31)
    cage_rows(d, t, 1050, 3000, 1500, 0.62, 32)
    cage_rows(d, t, 980, 3000, 1600, 0.78, 33)
    cage_rows(d, t, 1250, 3100, 1730, 0.95, 34)
    cage_rows(d, t, 1150, 3200, 1880, 1.12, 35)
    for (x, y) in ((660, 1680), (920, 1680)): cage(d, x, y, 0.95, 0, [(-50, 1), (45, 3)] if x < 800 else [(-50, 0), (45, 4)], t + x)
    cage(d, 790, 1680 - 168 * 0.95, 0.95, 0, [(-45, 2), (45, 5)], t + 3)
    LK.cast_shadow(d, 330, 1700, 70 * 1.35, 16 * 1.35, 70)
    human(d, 330, 1700, 1.35, 'berthier', face='open', mouth='smile', brow=1, armL=(100, 76), armR=(-22, 70), look=(4, 0))
def hE(img, t, lt):
    tag(img, 'MARSHAL BERTHIER', t, 12.95, 14.6)
    tag(img, 'CHIEF OF STAFF', t, 13.1, 14.6, 290, (255, 255, 255), 40)
reg(draw=dE, hud=hE, post=lambda img, t, lt, M: fg_dof(img, t, M, 15, None, 220))

# ---- F cages open 16.60 - 17.89
@shot(16.60, 17.89, 'meadow', blur=True, sun=SUN_MEADOW, rays=0.16, motes=0.8)
def cF(t, lt): return [(0, 540, 1500, 1.65, 0.0), (1.29, 540, 1510, 1.82, 0.0)], [(0.18, 9), (0.38, 9)]
def dF(d, t, lt):
    cage(d, 400, 1660, 1.0, smooth(clamp((t - 16.74) / 0.22)), [(-50, 1), (45, 3)], t)
    cage(d, 690, 1660, 1.0, smooth(clamp((t - 16.96) / 0.22)), [(-50, 0), (45, 4)], t + 1)
reg(draw=dF)

# ---- G hunters raise guns 17.89 - 19.98
HUNT = [(150, 1680, 'hunter2', 1.0), (350, 1700, 'hunter', 1.08), (790, 1700, 'hunter2', 1.08), (960, 1680, 'hunter', 1.0)]
@shot(17.89, 19.98, 'meadow', sun=SUN_MEADOW, rays=0.18, motes=0.8)
def cG(t, lt): return [(0, 570, 1383, 1.02, 0.0), (2.09, 570, 1387, 1.14, 0.0)], [(0.62, 5)]
def gun_pose(u):
    return (lerp(30, 125, u), 74), (lerp(-30, 95, u), lerp(70, 50, u)), lerp(-1.45, -0.55, u)
def dG(d, t, lt):
    for i, (x, y, o, sc) in enumerate(HUNT):
        u = smooth(clamp((t - 18.25 - i * 0.07) / 0.45))
        aL, aR, ga = gun_pose(u)
        LK.cast_shadow(d, x, y, 70 * sc, 16 * sc, 60)
        human(d, x, y, sc, o, face='squint' if u > 0.8 else 'open', mouth='flat', armL=aL, armR=aR, var=i % 3,
              prop=(lambda B, hL, hR, ga=ga: musket(B, hL, ga, 300)))
    u = smooth(clamp((t - 18.3) / 0.45))
    aL, aR, ga = gun_pose(u)
    LK.cast_shadow(d, 570, 1760, 70 * 1.3, 16 * 1.3, 60)
    nap(d, 570, 1760, 1.3, face='squint' if u > 0.8 else 'open', mouth='smirk', armL=aL, armR=aR, prop=(lambda B, hL, hR: musket(B, hL, ga, 300)))
def fg_dof(img, t, M, seed=9, y=None, h=300):
    def fg():
        dd = D(img, M)
        q = np.linalg.inv(M) @ np.array([0, OH, 1.0]); yb = q[1] + 20 if y is None else y
        fg_grass(dd, t, q[0] - 200, q[0] + 1400 / max(0.5, M[0, 0] / S), yb, h, 22, seed, C('3e6a26'), C('4f7f30'))
    LK.dof_layer(img, fg, 36 * S * 3)
reg(draw=dG, post=lambda img, t, lt, M: fg_dof(img, t, M, 9))

# ---- H rabbits don't run 19.98 - 22.00
@shot(19.98, 22.00, 'meadow', sun=SUN_MEADOW, rays=0.14, motes=0.7)
def cH(t, lt): return [(0, 540, 1300, 0.98, 0.0), (2.02, 540, 1380, 1.24, 0.0)], [(1.0, 5)]
def dH(d, t, lt):
    for k in range(5): cage(d, 120 + k * 210, 1370, 0.5, 1.0, None, t)
    turned = t > 20.95
    r = rng(44); items = []
    for i in range(26):
        items.append((r.uniform(1420, 1830), r.uniform(-60, 1140), r.choice([1, -1]), r.randrange(6), r.uniform(0, 0.25)))
    items.sort()
    for y, x, fl, col, dl in items:
        sc = 0.5 + 0.35 * (y - 1420) / 410
        if turned and t > 20.95 + dl:
            p = pop(t, 20.95 + dl, 0.2)
            rabbit(d, x, y - 10 * (1 - p), sc, 1, col, 'front', face='wide', ear=1.0, blink=False)
        else:
            rabbit(d, x, y, sc, fl, col, 'sit', face='open', blink=blink_auto(t, x), chew=1.0 * (math.sin(t * 20 + x) > 0.5))
reg(draw=dH, post=lambda img, t, lt, M: fg_dof(img, t, M, 13, None, 240))

# ---- I stampede 22.00 - 24.00
STAMP = [(rng(70 + i).uniform(-200, 1280), rng(90 + i).uniform(0, 1), rng(110 + i).randrange(6)) for i in range(34)]
@shot(22.00, 24.00, 'meadow', sun=SUN_MEADOW, rays=0.14, motes=0.6)
def cI(t, lt): return [(0, 540, 1530, 0.95, 0.0), (0.5, 540, 1560, 1.12, 0.0, 'o'), (2.0, 540, 1560, 1.16, 0.0)], [(k * 0.24, 7) for k in range(9)]
def dI(d, t, lt):
    items = []
    for x, off, col in STAMP:
        p = (lt * 0.62 + off) % 1.0
        y = lerp(1250, 2050, p ** 1.4)
        xx = lerp(x, 540 + (x - 540) * 1.6, p)
        items.append((y, xx, col, off))
    items.sort()
    drawn_nap = False
    for y, x, col, off in items:
        if y > 2040 and not drawn_nap:
            pass
        sc = lerp(0.25, 1.15, (y - 1250) / 800)
        rabbit(d, x, y, sc, 1, col, 'front', hop=(lt * 3.2 + off * 5) % 1.0, face='open', ear=1.0)
    scared = t > 22.25
    nap(d, 540, 2090, 1.75, face='wide' if scared else 'open', mouth='o' if scared else 'smirk', armL=(165, 70) if scared else (25, 70), armR=(-165, 70) if scared else (54, 52),
        brow=1, sweat=scared, tilt=-0.08 if scared else 0, look=(0, -2))
reg(draw=dI)

# ---- J swarm 24.00 - 27.22
NX, NY, NS = 540, 1760, 1.45
CLIMB = [(24.3, -24, -30, -95, 1, 0), (24.5, 26, -30, -100, -1, 1), (24.9, -12, -70, -150, 1, 3), (25.3, 30, -110, -185, -1, 2),
         (25.7, -40, -150, -205, 1, 4), (26.05, 44, -150, -215, -1, 5)]
def nap_swarmed(d, t, flail=1.0, face='wide', mouth='grit', hat_rabbit=True, climbers=True, ground=True, gx=0):
    if ground:
        r = rng(55); g = []
        for i in range(18):
            a = r.uniform(0, 2 * math.pi); rr_ = r.uniform(120, 300)
            g.append((NY + math.sin(a) * 60 + r.uniform(-10, 30), NX + math.cos(a) * rr_ + gx, r.choice([1, -1]), r.randrange(6), r.uniform(0, 1)))
        g.sort()
        back_ = [q for q in g if q[0] < NY]; front_ = [q for q in g if q[0] >= NY]
        for y, x, fl, col, ph in back_: rabbit(d, x, y, 0.55, fl, col, 'hop', hop=(t * 2.4 + ph) % 1.0, face='happy')
    LK.cast_shadow(d, NX, NY, 70 * NS, 16 * NS, 50)
    nap(d, NX, NY, NS, face=face, mouth=mouth, armL=(120 + 40 * math.sin(t * 14) * flail, 70), armR=(-120 - 40 * math.sin(t * 13 + 1) * flail, 70),
        tilt=0.08 * math.sin(t * 9) * flail, brow=1, sweat=True, lean=0.04 * math.sin(t * 7) * flail, shadow_on=False)
    if climbers:
        for ta, lx, ly0, ly1, fl, col in CLIMB:
            if t < ta: continue
            ly = lerp(ly0, ly1, eout(clamp((t - ta) / 1.2)))
            rabbit(d, NX + lx * NS, NY + ly * NS, 0.5, fl, col, 'sit', face='happy', tilt=-1.25 * fl if fl > 0 else 1.25, shadow_on=False)
    if hat_rabbit and t >= 26.35:
        p = pop(t, 26.35, 0.3)
        rabbit(d, NX + 6 * NS, NY - 375 * NS - (1 - p) * 60, 0.5, 1, 0, 'sit', face='happy', shadow_on=False, chew=1.0 * (math.sin(t * 20) > 0))
    if ground:
        for y, x, fl, col, ph in front_: rabbit(d, x, y, 0.62, fl, col, 'hop', hop=(t * 2.4 + ph) % 1.0, face='happy')
JUMPERS = [(24.05, -160, 1, 2), (24.22, 170, -1, 4), (24.4, -60, 1, 1), (24.55, 120, -1, 5), (24.7, -190, 1, 3)]
DRAMA = dict(key=(-2.2, 0.32), contrast=1.08, bloom=0.26, rays=0.3, raycol=(120, 200, 255), spread=1.6, motes=1.3, mb=True)
# J1: tight on the face, rabbits leap up into frame
@shot(24.00, 25.00, 'meadow', blur=True, sun=(980, 1000), **DRAMA)
def cJ1(t, lt): return [(0, 560, 1430, 3.1, -0.03), (1.0, 545, 1425, 3.35, 0.02)], [(0.05, 10), (0.4, 8), (0.7, 8)]
def dJ1(d, t, lt):
    nap_swarmed(d, t, 1.4, ground=False)
    for ta, dx, fl, col in JUMPERS:
        u = (t - ta) / 0.55
        if 0 <= u <= 1.4:
            uu = min(u, 1.0)
            x = NX + dx * (1 - 0.6 * uu); y = NY - 120 - math.sin(math.pi * min(uu, 0.85) / 0.85 * 0.5) * 340 * NS
            rabbit(d, x, y, 0.62, fl, col, 'hop', hop=0.5, face='happy', ear=1.0, shadow_on=False, tilt=-0.5 * fl)
reg(draw=dJ1)
# J2: ground level at the boots, swarm rushing past camera
@shot(25.00, 26.05, 'meadow', blur=True, sun=(980, 1000), **DRAMA)
def cJ2(t, lt): return [(0, 470, 1545, 2.25, 0.04), (1.05, 610, 1555, 2.45, -0.02)], [(0.1, 7), (0.5, 7), (0.85, 7)]
def dJ2(d, t, lt):
    r = rng(77); items = []
    for i in range(30):
        items.append((r.uniform(1640, 1830), r.uniform(-200, 1300), r.uniform(0, 1), r.randrange(6), r.choice([1, -1])))
    items.sort()
    back_ = [q for q in items if q[0] < NY]; front_ = [q for q in items if q[0] >= NY]
    for y, x, ph, col, fl in back_:
        xx = x + fl * ((t * 260 + ph * 900) % 1500) - fl * 700
        rabbit(d, xx, y, 0.62, fl, col, 'hop', hop=(t * 3.4 + ph) % 1.0, face='happy', ear=1.0)
    nap_swarmed(d, t, 1.0, ground=False)
    for y, x, ph, col, fl in front_:
        xx = x + fl * ((t * 300 + ph * 900) % 1500) - fl * 700
        rabbit(d, xx, y, 0.72, fl, col, 'hop', hop=(t * 3.4 + ph) % 1.0, face='open', ear=1.0)
def pJ2(img, t, lt, M):
    def fg():
        dd = D(img, M)
        for k in range(3):
            x = (300 + k * 420 - ((t * 420) % 1300)); rabbit(dd, x, 1905 + k * 10, 1.1, 1, k + 1, 'hop', hop=(t * 3 + k * 0.3) % 1.0, face='happy', ear=1.0)
        fg_grass(dd, t, 0, 1100, 1900, 140, 30, 21, C('2e5a1c'), C('3e6a26'))
    LK.dof_layer(img, fg, 30 * S * 3)
reg(draw=dJ2, post=pJ2)
# J3: low hero angle pulling out, rabbits climbing all over him, one lands on the hat
@shot(26.05, 27.22, 'meadow', blur=True, sun=(980, 1000), **DRAMA)
def cJ3(t, lt): return [(0, 540, 1430, 1.95, 0.05), (1.17, 540, 1440, 1.5, -0.01, 'o')], [(0.32, 12)]
def dJ3(d, t, lt): nap_swarmed(d, t, 1.2)
def pJ3(img, t, lt, M): fg_dof(img, t, M, 23, None, 260)
reg(draw=dJ3, post=pJ3)

# ---- K whips & sticks 27.22 - 29.38
@shot(27.22, 29.38, 'meadow', sun=SUN_MEADOW, rays=0.14, motes=0.7)
def cK(t, lt): return [(0, 540, 1343, 1.0, 0.0), (2.16, 540, 1346, 1.08, 0.0)], [(0.3, 7), (0.9, 7), (1.5, 7)]
def dK(d, t, lt):
    nap_swarmed(d, t, 0.6)
    sw = math.sin(t * 11)
    LK.cast_shadow(d, 160, 1740, 75, 17, 50)
    human(d, 160, 1740, 1.1, 'hunter', face='squint', mouth='grit', armL=(120 + 50 * sw, 75), armR=(-30, 70),
          prop=lambda B, hL, hR: whip(B, hL, t, 0.4 * sw, max(0, sw)))
    LK.cast_shadow(d, 930, 1740, 75, 17, 50)
    human(d, 930, 1740, 1.1, 'hunter2', face='squint', mouth='grit', armR=(-120 - 50 * math.sin(t * 10 + 1), 75), armL=(30, 70),
          prop=lambda B, hL, hR: stick(B, hR, -0.6 * math.sin(t * 10 + 1)))
    # dodging rabbits leaping
    for i in range(6):
        u = (t * 1.6 + i * 0.17) % 1.0
        x = 300 + i * 90 + math.sin(i) * 40; y = 1820 + (i % 2) * 40
        rabbit(d, x, y, 0.6, 1 if i % 2 else -1, i, 'hop', hop=u, face='happy')
reg(draw=dK)

# ---- L nothing worked 29.38 - 30.74
@shot(29.38, 30.74, 'meadow', blur=True, sun=SUN_MEADOW, rays=0.12, motes=0.6)
def cL(t, lt): return [(0, 540, 1410, 1.95, 0.0), (1.36, 540, 1412, 2.1, 0.0)], []
def dL(d, t, lt): nap_swarmed(d, 29.38 + 0.5 * lt * 0.2, 0.0, face='half', mouth='flat')
reg(draw=dL, desat=0.35)

# ---- M chase to the carriage 30.74 - 35.89
COX, COY, COS = 2480, 1730, 1.1
WIN = (COX, COY - 385 * COS)
def nap_x(t): return lerp(250, 2320, smooth(clamp((t - 30.8) / 2.1)))
def coach_bounce(t):
    b = 0.0
    for i in range(10):
        tl = 33.85 + i * 0.16 + 0.45
        if t > tl: b += 10 * math.exp(-(t - tl) * 8) * math.cos((t - tl) * 30)
    if 32.92 < t: b += 14 * math.exp(-(t - 32.92) * 7) * math.cos((t - 32.92) * 28)
    return b
def win_scene(d, t, B_local=False):
    pass
@shot(30.74, 35.89, 'meadow', sun=SUN_MEADOW, rays=0.14, motes=0.7)
def cM(t, lt):
    ks = []
    for k in range(0, 21):
        tt_ = k * 0.26
        nx = nap_x(30.74 + tt_)
        ks.append((tt_, min(nx + 140, 2330), 1417, 0.92, 0.0, 'l'))
    ks[0] = (0, 380, 1417, 0.92, 0.0)
    return ks, [(2.19, 14)]
def dM(d, t, lt):
    door = smooth(clamp((t - 32.45) / 0.2)) * (1 - smooth(clamp((t - 32.86) / 0.08)))
    bnc = coach_bounce(t)
    coach(d, COX, COY, COS, door, bnc, 0.0)
    # window content: rabbits inside after they jump in
    nx = nap_x(t)
    # chasing rabbits
    for i in range(16):
        jt = 33.85 + i * 0.16
        if t < jt:
            x = min(nx - 180 - i * 75 - 40 * math.sin(i), 2200 - i * 20)
            y = 1660 + (i % 4) * 45
            rabbit(d, x, y, 0.55 + 0.05 * (i % 4), 1, i, 'hop', hop=(t * 2.6 + i * 0.3) % 1.0, face='open', ear=1.0)
        elif t < jt + 0.45:
            u = (t - jt) / 0.45
            x0 = min(nap_x(jt) - 180 - i * 75 - 40 * math.sin(i), 2200 - i * 20); y0 = 1660 + (i % 4) * 45
            x = lerp(x0, WIN[0] - 20, u); y = lerp(y0, WIN[1] + 40, u) - math.sin(math.pi * u) * 260
            rabbit(d, x, y, lerp(0.55, 0.42, u), 1, i, 'hop', hop=0.45, face='open', ear=1.0, shadow_on=False)
    if t < 32.9:
        cast = t < 32.4
        nap(d, nx, 1720, 1.0, face='wide', mouth='o', step=t * 17, lean=0.18, armL=(60 + 50 * math.sin(t * 17), 70), armR=(-60 + 50 * math.sin(t * 17), 70),
            brow=1, sweat=True, flip=1)
        rabbit(d, nx + 6, 1720 - 375 - 8 * abs(math.sin(t * 17)), 0.34, 1, 0, 'sit', face='happy', shadow_on=False)
    # dust behind runner
    if 30.8 < t < 32.9:
        for k in range(6):
            u = ((t * 3 + k / 6) % 1.0)
            if u < 0.7: d.ell(nx - 50 - u * 140, 1712 - u * 30, 10 + u * 22, 7 + u * 14, C('d8cfa8'), None, 0)
def pM(img, t, lt, M):
    if t > 33.9:
        def inner():
            dd = D(img, M)
            for k, (ox, col, fc) in enumerate(((-40, 1, 'happy'), (35, 4, 'open'), (0, 2, 'happy'))):
                if t > 33.85 + k * 0.32 + 0.45:
                    jig = math.sin(t * 9 + k) * 6
                    rabbit(dd, WIN[0] + ox * COS, WIN[1] + 70 + jig - coach_bounce(t) * COS, 0.42, 1 if k % 2 else -1, col, 'front', face=fc, shadow_on=False)
        poly = [(WIN[0] - 70 * COS, WIN[1] - 55 * COS - coach_bounce(t) * COS), (WIN[0] + 70 * COS, WIN[1] - 55 * COS - coach_bounce(t) * COS),
                (WIN[0] + 70 * COS, WIN[1] + 55 * COS - coach_bounce(t) * COS), (WIN[0] - 70 * COS, WIN[1] + 55 * COS - coach_bounce(t) * COS)]
        clip_draw(img, M, poly, inner)
reg(draw=dM, post=pM)

# ---- N why? 35.89 - 36.72
@shot(35.89, 36.72, 'meadow', blur=True, sun=SUN_MEADOW, rays=0.12, motes=0.5)
def cN(t, lt): return [(0, COX, WIN[1] + 40, 2.2, 0.0), (0.83, COX, WIN[1] + 40, 2.35, 0.0)], []
def dN(d, t, lt): coach(d, COX, COY, COS, 0.0, math.sin(t * 20) * 3, 0.0)
def pN(img, t, lt, M):
    def inner():
        dd = D(img, M)
        nap(dd, WIN[0], WIN[1] + 175, 0.62, face='half', mouth='flat', look=(0, 0), shadow_on=False)
        for k, (ox, oy, col) in enumerate(((-58, 62, 1), (60, 66, 4))):
            rabbit(dd, WIN[0] + ox, WIN[1] + oy, 0.3, 1, col, 'front', face='happy', shadow_on=False)
    bb = math.sin(t * 20) * 3
    poly = [(WIN[0] - 70 * COS, WIN[1] - 55 * COS - bb), (WIN[0] + 70 * COS, WIN[1] - 55 * COS - bb), (WIN[0] + 70 * COS, WIN[1] + 55 * COS - bb), (WIN[0] - 70 * COS, WIN[1] + 55 * COS - bb)]
    clip_draw(img, M, poly, inner)
def hN(img, t, lt):
    p = pop(t, 35.92, 0.3)
    hud_text(img, '?', 540, 430, 320, (255, 214, 64), p * (1 + 0.04 * math.sin(t * 9)), 1.0, 0.12 * math.sin(t * 6))
reg(draw=dN, post=pN, hud=hN)

# ---- O1 wild 36.72 - 38.25
@shot(36.72, 38.25, 'burrow', sun=(540, 1000), rays=0.14, raycol=(120, 180, 255), motes=0.5, grade='warm')
def cO1(t, lt): return [(0, 540, 1451, 1.45, 0.0), (1.53, 540, 1460, 1.55, 0.0)], []
def dO1(d, t, lt):
    d.ell(780, 1700, 120, 46, C('2a1e16'), INK, 5); d.ell(780, 1690, 96, 30, C('140c08'), None, 0)
    if t < 37.3:
        rabbit(d, 430, 1720, 1.1, 1, 5, 'sit', face='wide', ear=1.0, look=(-1, 0))
    elif t < 37.62:
        u = (t - 37.3) / 0.32
        rabbit(d, lerp(430, 780, u), 1720 - 0 * u, lerp(1.1, 0.8, u), 1, 5, 'hop', hop=u * 0.9, face='wide', ear=1.0)
    for k in range(4):
        if t > 37.62 + k * 0.05: d.ell(760 + k * 30 - 40, 1660 - k * 12, 16 + k * 4, 12, C('a08a60'), None, 0)
    fg_grass(d, t, -200, 1300, 1830, 120, 40, 12, C('3e5a20'), C('4f6a28'))
def hO1(img, t, lt):
    hud_text(img, 'WILD', 540, 300, 130, (255, 255, 255), pop(t, 36.75, 0.3))
    cross_out(img, 540, 300, 150, t, 37.55)
reg(draw=dO1, hud=hO1)

# ---- O2 tame 38.25 - 40.25
@shot(38.25, 40.25, 'barn', sun=(730, 470), rays=0.17, raycol=(110, 200, 255), spread=0.9, motes=1.2)
def cO2(t, lt): return [(0, 560, 1388, 1.18, 0.0), (2.0, 520, 1400, 1.28, 0.0)], []
def dO2(d, t, lt):
    LK.cast_shadow(d, 260, 1760, 90, 20, 40)
    human(d, 260, 1760, 1.3, 'farmer', face='happy', mouth='smile', armL=(70 + 8 * math.sin(t * 6), 78), armR=(-20, 70), var=0,
          prop=lambda B, hL, hR: carrot(B, hL[0] + 10, hL[1] - 10, 1.0, -1.3))
    for i, (x, y, col) in enumerate(((520, 1700, 0), (660, 1760, 3), (800, 1690, 1), (930, 1780, 4), (580, 1850, 2))):
        hp = (t * 1.4 + i * 0.3) % 1.0 if i % 2 else 0
        rabbit(d, x, y, 0.75, -1, col, 'hop' if i % 2 else 'sit', hop=hp, face='happy' if i % 2 else 'sparkle', ear=0.3, chew=1.0 * (math.sin(t * 22 + i) > 0.3))
def hO2(img, t, lt):
    hud_text(img, 'TAME', 540, 300, 130, (255, 255, 255), pop(t, 38.3, 0.3))
    check(img, 780, 300, 70, t, 38.6)
reg(draw=dO2, hud=hO2)

# ---- P rabbit POV 40.25 - 42.70
@shot(40.25, 42.70, 'meadow', blur=True, sun=SUN_MEADOW, rays=0.22, motes=1.2)
def cP(t, lt): return [(0, 540, 1234, 1.0, 0.0), (2.45, 540, 1280, 1.08, 0.0)], []
def dP(d, t, lt):
    u = clamp(lt / 2.45)
    y = lerp(1560, 1720, u); sc = lerp(1.1, 1.55, u)
    LK.cast_shadow(d, 540, y, 70 * sc, 16 * sc, 40)
    nap(d, 540, y, sc, face='open', mouth='smile', step=t * 7, armL=(20 + 15 * math.sin(t * 7), 70), armR=(-20 + 15 * math.sin(t * 7), 70), look=(0, 2))
def pP(img, t, lt, M):
    def fg():
        dd = D(img, M)
        for x, col, s_ in ((170, 1, 1.9), (890, 3, 2.1), (540, 0, 1.4)):
            if x == 540: continue
            rabbit_back(dd, x, 2010, s_, col, 0, 0.2 * math.sin(t * 3 + x))
    LK.dof_layer(img, fg, 26 * S * 3)
reg(draw=dP, post=pP)

# ---- Q dinner time 42.70 - 45.00
@shot(42.70, 45.0, 'meadow', sun=SUN_MEADOW, rays=0.2, motes=1.1)
def cQ(t, lt): return [(0, 540, 1372, 1.08, 0.0), (2.3, 540, 1380, 1.16, 0.0)], [(0.08, 8)]
def dQ(d, t, lt):
    late = t > 43.9
    LK.cast_shadow(d, 540, 1760, 70 * 1.35, 16 * 1.35, 50)
    nap(d, 540, 1760, 1.35, face='wide' if not late else 'half', mouth='grit' if not late else 'flat', armL=(40, 70), armR=(-40, 70), brow=1 if not late else 0, sweat=not late)
    ring = [(150, 1800, 1), (300, 1880, 2), (430, 1930, 4), (650, 1930, 0), (790, 1880, 3), (930, 1800, 5), (240, 1720, 0), (840, 1720, 1)]
    for i, (x, y, col) in enumerate(sorted(ring, key=lambda q: q[1])):
        pull = smooth(clamp((t - 44.25 - i * 0.03) / 0.35))
        xx = lerp(x, 540 + (x - 540) * 0.45, pull); yy = lerp(y, 1790 + (y - 1800) * 0.3, pull)
        rabbit(d, xx, yy, 0.72, 1, col, 'front', hop=((t * 2 + i * 0.2) % 1.0) if pull > 0 and pull < 1 else 0, face='heart', ear=1.0)
def hQ(img, t, lt):
    def inner(G):
        carrot(G, 0, -70, 3.0, 0.0)
        for sx_ in (-14, 14): G.ell(sx_, -10, 7, 9, C('2a1e22'), None, 0); G.dot(sx_ + 2, -13, 2.5, (255, 255, 255))
        G.line(bez((-12, 16), (2, 22), (14, 10), 6), INK, 4)
        Hh = G.sub(Aff(0, -66, 0.62))
        pts = list(bez((-118, -40), (-70, -150), (0, -126), 14)) + list(bez((0, -126), (70, -150), (118, -40), 14)) + list(bez((118, -40), (0, -70), (-118, -40), 16))
        Hh.poly(pts, C('1f1d24'), INK, 5)
        Hh.ell(70, -84, 15, 15, C('2b4aa8'), INK, 3); Hh.ell(70, -84, 10, 10, C('f4f1ea'), None, 0); Hh.ell(70, -84, 5, 5, C('d9323a'), None, 0)
    bubble(img, 600, 460, 240, t, 43.05, inner)
    if t > 42.72:
        sw = math.sin((t - 42.72) * 18) * 0.5 * math.exp(-(t - 42.72) * 1.5)
        dinner_bell(D(img, Aff(0, 0, S)), 180, 280, 1.2 * pop(t, 42.72, 0.25), sw)
        if t < 43.6: hud_text(img, 'DING!', 200, 470, 70, (255, 214, 64), pop(t, 42.75, 0.25), 1.0, -0.15)
reg(draw=dQ, hud=hQ)

# ======================= CAPTIONS =======================
TIM = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'work/timing.json')))
def syl(w):
    if re.search(r'\d', w): return 4
    w = re.sub(r'[^a-z]', '', w.lower())
    if not w: return 1
    n = len(re.findall(r'[aeiouy]+', w))
    if w.endswith('e') and n > 1 and not w.endswith('le'): n -= 1
    return max(1, n)
KEY = {'napoleon', 'europe', 'bunnies', '1807', 'peace', 'rabbit', 'hunt', 'hundreds', 'cages', 'guns', "didn't", 'straight', 'swarmed', 'legs', 'whips', 'sticks',
       'nothing', 'carriage', 'why', 'wild', 'tame', 'farm', 'dinner', 'emperor', 'battle', 'there', 'too'}
CH = []
for a, b, txt in TIM:
    ws = txt.replace('...', '…').split()
    ss = [syl(w) for w in ws]; tot = sum(ss); tt = a; wt = []
    for w, s_ in zip(ws, ss):
        wt.append((tt, w)); tt += (b - a) * s_ / tot
    i = 0
    while i < len(wt):
        n = 1
        if i + 1 < len(wt) and not re.search(r'[,.?!…]$', wt[i][1]) and len(wt[i][1]) + len(wt[i + 1][1]) < 14: n = 2
        CH.append([wt[i][0], ' '.join(w for _, w in wt[i:i + n])]); i += n
    CH[-1].append(b + 0.25)
for i in range(len(CH)):
    if len(CH[i]) == 2: CH[i].append(CH[i + 1][0])
    CH[i][2] = min(CH[i][2], CH[i + 1][0] if i + 1 < len(CH) else 99)

def cap_text(img, txt, x, y, size, rgb, sc):
    spr = text_sprite(txt, int(size * S), rgb, 0.17)
    sh = spr.copy(); sh[..., :3] = 0
    k = max(3, int(14 * S) | 1)
    sh[..., 3] = cv2.GaussianBlur(sh[..., 3], (k, k), 0)
    blit(img, sh, x * S + 4 * S, y * S + 7 * S, sc, 0.7)
    blit(img, spr, x * S, y * S, sc)

def caption(img, t):
    for t0, txt, t1 in CH:
        if t0 - 0.03 <= t < t1:
            words = [re.sub(r"[^\w']", '', w.lower()) for w in txt.split()]
            key = any(w in KEY for w in words)
            disp = txt.upper().replace('…', '...').rstrip(',.')
            if key:
                u = (t - t0) / 0.22
                sc = 0.6 + 0.6 * back(u, 2.6) if u < 1 else 1.2
                col = (255, 255, 255) if u < 0.4 else (255, 160, 40) if u < 0.7 else (255, 214, 64)
                cap_text(img, disp, 540, 1325, 100, col, sc)
            else:
                cap_text(img, disp, 540, 1325, 100, (255, 255, 255), 0.7 + 0.3 * back((t - t0) / 0.15, 2.0))
            return

# ======================= TRANSITIONS =======================
WHIP = [2.92, 10.03, 12.90, 17.89, 27.22, 30.74, 40.25]
FLASH = [(6.64, 5), (22.0, 4), (36.72, 4), (42.70, 4)]
CUTS = [s_['t0'] for s_ in SH]
def whip_tr(img, f):
    for b in WHIP:
        df = f - int(round(b * FPS))
        if -4 <= df <= 3:
            if df < 0: p = (df + 5) / 5.0; sh = -p * p * OW * 0.3
            else: p = (4 - df) / 4.0; sh = p * p * OW * 0.3
            out = cv2.warpAffine(img, np.float32([[1, 0, sh], [0, 1, 0]]), (OW, OH), borderMode=cv2.BORDER_REPLICATE)
            k = max(1, int(abs(sh) * 0.35)) | 1
            img[:] = cv2.blur(out, (k, 1)); return

MOTES = LK.Motes(80, 5)

def core(t, f, sh):
    lt = t - sh['t0']
    keys, kicks = sh['cam'](t, lt)
    cx, cy, z, rot = cam_keys(keys, lt)
    cx += math.sin(t * 0.9) * 5; cy += math.cos(t * 0.7) * 4
    sx, sy = shake_at(lt, kicks)
    M = camM(cx, cy, z, rot, (sx, sy))
    img = np.zeros((OH, OW, 3), np.uint8)
    if sh['bg']:
        kind = sh['bg'] + ('_blur' if sh.get('blur') else '')
        bg = bgimg(kind); ox, oy = BGOFF[kind]
        Mb = M @ np.array([[1 / S, 0, -ox], [0, 1 / S, -oy], [0, 0, 1]])
        cv2.warpAffine(bg, Mb[:2], (OW, OH), dst=img, flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    d = D(img, M)
    sh['draw'](d, t, lt)
    if sh.get('post'): sh['post'](img, t, lt, M)
    return img, M, (cx, cy, z)

def render(f):
    t = f / FPS
    sh = next((s for s in SH if s['t0'] <= t < s['t1']), SH[-1])
    lt = t - sh['t0']
    if sh.get('mb'):
        acc = None; n = 5
        for k in range(n):
            tk = max(sh['t0'], t - k / (FPS * n) * 0.5)
            im_, M, cam = core(tk, f, sh)
            acc = im_.astype(np.float32) if acc is None else acc + im_
        img = (acc / n).astype(np.uint8)
        _, M, cam = None, M, cam
    else:
        img, M, cam = core(t, f, sh)
    cx, cy, z = cam
    # ---- premium look stack ----
    if sh.get('key'): LK.key_light(img, sh['key'][0], sh['key'][1])
    if sh.get('sun') and sh.get('rays', 0) > 0:
        q = M[:2, :2] @ np.array(sh['sun'], float) + M[:2, 2]
        ang = math.atan2(OH * 0.75 - q[1], OW * 0.5 - q[0])
        LK.god_rays(img, q[0], q[1], t, sh['rays'], sh.get('raycol', (150, 215, 255)), 12, sh.get('spread', 1.3), ang)
        if sh['bg'] in ('sunset',) or sh.get('key'): LK.sun_glow(img, q[0], q[1], 160 * S * z, (120, 200, 255), 0.5)
    if sh.get('motes', 0) > 0:
        MOTES.draw(img, t, cx / 4000.0, cy / 6000.0, sh.get('motecol', (180, 230, 255)), sh['motes'])
    LK.grade(img, sh.get('grade', 'warm'), 1.1)
    if sh.get('contrast'): LK.contrast(img, sh['contrast'])
    if sh.get('desat'):
        g = cv2.cvtColor(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.COLOR_GRAY2BGR)
        img[:] = cv2.addWeighted(img, 1 - sh['desat'], g, sh['desat'], 0)
    LK.bloom(img, 228, sh.get('bloom', 0.28))
    img[:] = (img.astype(np.float32) * vignette()).astype(np.uint8)
    LK.chroma(img, int(round(2 * S * 3)) if S > 0.5 else 0)
    LK.grain(img, f, 5 if S > 0.5 else 4)
    if os.environ.get('NOTEXT'): return img
    if sh.get('hud'): sh['hud'](img, t, lt)
    whip_tr(img, f)
    caption(img, t)
    for ft, n in FLASH:
        df = f - int(ft * FPS)
        if -2 <= df < n:
            a = (1 - abs(df) / (n if df >= 0 else 2)) * 0.85
            img[:] = cv2.addWeighted(img, 1 - a, np.full_like(img, 255), a, 0)
    return img

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'stills':
        out = sys.argv[2]; os.makedirs(out, exist_ok=True)
        for tt in sys.argv[3].split(','):
            f = int(round(float(tt) * FPS)); cv2.imwrite(f'{out}/s_{float(tt):05.2f}.jpg', render(f))
    else:
        out = sys.argv[2]; a, b = map(int, sys.argv[3].split('-')); os.makedirs(out, exist_ok=True)
        for f in range(a, min(b, NF - 1) + 1):
            cv2.imwrite(f'{out}/f{f:05d}.jpg', render(f), [cv2.IMWRITE_JPEG_QUALITY, 92])
