import numpy as np, wave, math
SR = 44100; DUR = 45.0; N = int(SR * DUR)
rnd = np.random.default_rng(7)
def tt(d): return np.arange(int(SR * d)) / SR
def lp(x, k):
    k = max(1, int(k)); return np.convolve(x, np.ones(k) / k, 'same')
def place(buf, x, t, g=1.0, pan=0.0):
    i = int(t * SR)
    if i >= len(buf) or i < 0: return
    x = x[:len(buf) - i]
    l = g * math.cos((pan + 1) * math.pi / 4); r = g * math.sin((pan + 1) * math.pi / 4)
    buf[i:i + len(x), 0] += x * l * 1.41; buf[i:i + len(x), 1] += x * r * 1.41
P = place
noise = lambda d: rnd.standard_normal(int(SR * d))
def fade(x, a=0.01, r=0.05):
    n = len(x); e = np.ones(n); na = max(1, int(a * SR)); nr = max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] *= np.linspace(1, 0, nr); return x * e

# ---------------- SFX palette ----------------
def whoosh(d=0.45):
    n = noise(d); t = tt(d); e = np.sin(np.pi * t / d) ** 2
    return (lp(n, 3) * 0.5 + lp(n, 9) * 0.3 + lp(n, 30) * 0.2) * e * 0.6
def impact(d=0.9, f=55):
    t = tt(d); sub = np.sin(2 * np.pi * (f * np.exp(-t * 3)) * t * 2) * np.exp(-t * 5)
    return sub + noise(d) * np.exp(-t * 80) * 0.6 + lp(noise(d), 3) * np.exp(-t * 14) * 0.4
def pop(f=600):
    t = tt(0.12); return np.sin(2 * np.pi * f * t * (1 + 3 * np.exp(-t * 40))) * np.exp(-t * 35)
def boing():
    t = tt(0.5); return np.sin(2 * np.pi * np.cumsum(180 + 140 * np.sin(2 * np.pi * 9 * t) * np.exp(-t * 3)) / SR) * np.exp(-t * 6) * 0.8
def squeak(f0=1800, f1=2700, d=0.09):
    t = tt(d); f = np.linspace(f0, f1, len(t)) + 120 * np.sin(2 * np.pi * 40 * t)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / d) * 0.35
def ting(f=1800):
    t = tt(1.0); x = sum(np.sin(2 * np.pi * f * m * t) * a for m, a in ((1, 1), (2.01, 0.4), (3.03, 0.2)))
    return x * np.exp(-t * 5) * 0.5
def click(): t = tt(0.06); return noise(0.06) * np.exp(-t * 140) + np.sin(2 * np.pi * 3200 * t) * np.exp(-t * 90) * 0.5
def thunk(): t = tt(0.25); return (np.sin(2 * np.pi * 110 * t) * np.exp(-t * 25) + lp(noise(0.25), 6) * np.exp(-t * 30) * 0.6)
def knock(): t = tt(0.15); return lp(np.sin(2 * np.pi * 200 * t) * np.exp(-t * 40) + lp(noise(0.15), 6) * np.exp(-t * 50) * 0.6, 3)
def creak(d=0.35):
    t = tt(d); f = 260 + 120 * np.sin(2 * np.pi * 2.5 * t)
    saw = ((np.cumsum(f) / SR) % 1.0) * 2 - 1
    return lp(saw * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 34 * t))), 4) * np.sin(np.pi * t / d) * 0.35
def rustle(d=0.3): t = tt(d); return lp(noise(d), 2) * np.sin(np.pi * t / d) * 0.4
def paper(): return rustle(0.35) * 0.8
def stamp_hit():
    t = tt(0.5); return lp(np.sin(2 * np.pi * (60 + 40 * np.exp(-t * 30)) * t) * np.exp(-t * 9) + lp(noise(0.5), 8) * np.exp(-t * 25) * 0.5, 3)
def whipcrack():
    t = tt(0.25); return (noise(0.25) * np.exp(-t * 60) * 1.1 + lp(noise(0.25), 3) * np.exp(-t * 20) * 0.3) * (t > 0.0)
def crickets(d):
    t = tt(d); x = np.sin(2 * np.pi * 4300 * t) * (np.sin(2 * np.pi * 28 * t) > 0.3) * (np.sin(2 * np.pi * 2.2 * t) > 0)
    return lp(x, 2) * 0.12
def bird(f=3200):
    t = tt(0.25); fr = f + 900 * np.sin(2 * np.pi * 12 * t) * np.exp(-t * 6)
    return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.sin(np.pi * t / 0.25) ** 2 * 0.25
def water(d):
    return lp(noise(d), 40) * 1.4 * np.minimum(1, np.minimum(tt(d) / 0.4, (d - tt(d)) / 0.4)) + lp(noise(d), 8) * 0.08
def flapping(d):
    t = tt(d); return lp(noise(d), 6) * (0.5 + 0.5 * np.sin(2 * np.pi * 6 * t)) * 0.35 * np.minimum(1, np.minimum(t / 0.3, (d - t) / 0.3))
def patter(d, rate=22, g=1.0):
    t = tt(d); x = np.zeros_like(t)
    k = 0.0
    while k < d - 0.05:
        i = int(k * SR); seg = lp(noise(0.04), 5) * np.exp(-np.arange(int(0.04 * SR)) / SR * 90) * rnd.uniform(0.4, 1.0)
        x[i:i + len(seg)] += seg[:len(x[i:i + len(seg)])]
        k += 1 / rate * rnd.uniform(0.6, 1.4)
    return x * g * np.minimum(1, np.minimum(t / 0.2, (d - t) / 0.3))
def rumble(d): t = tt(d); return lp(noise(d), 80) * 3 * np.minimum(1, np.minimum(t / 0.3, (d - t) / 0.4))
def step(): t = tt(0.1); return lp(noise(0.1), 6) * np.exp(-t * 45) * 0.9 + np.sin(2 * np.pi * 90 * t) * np.exp(-t * 40) * 0.5
def riser(d=1.5):
    t = tt(d); return (lp(noise(d), 4) * 0.3 + 0.2 * np.sin(2 * np.pi * np.cumsum(200 + 700 * (t / d) ** 2) / SR)) * (t / d) ** 2
def buzzer(): t = tt(0.45); x = np.sign(np.sin(2 * np.pi * 110 * t)) * 0.3 + np.sign(np.sin(2 * np.pi * 116 * t)) * 0.3; return lp(x, 6) * fade(np.ones_like(t), 0.01, 0.05)
def ding(): return ting(1568) * 0.8 + ting(2093) * 0.5
def chomp(): t = tt(0.12); return lp(noise(0.12), 3) * np.exp(-t * 35) * np.sin(np.pi * t / 0.12) * 0.9
def bell_ring(d=1.2):
    t = tt(d); x = sum(np.sin(2 * np.pi * f * t) * a for f, a in ((1180, 1), (2950, 0.5), (4120, 0.3)))
    am = 0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 9 * t))
    return x * am * np.exp(-t * 2.5) * 0.35
def clap(): t = tt(0.08); return lp(noise(0.08), 2) * np.exp(-t * 70)

# ---------------- instruments ----------------
def pizz(f, d=0.28, g=1.0):
    t = tt(d); x = sum(np.sin(2 * np.pi * f * m * t) * a * np.exp(-t * (14 + 6 * m)) for m, a in ((1, 1), (2, 0.5), (3, 0.25), (4, 0.12)))
    return x * g * 0.6
def brass(f, d, bright=1.0, vib=0.0):
    t = tt(d); fr = f * (1 + vib * 0.012 * np.sin(2 * np.pi * 5.5 * t))
    ph = np.cumsum(fr) / SR
    env = np.minimum(1, t / 0.04) * np.minimum(1, (d - t) / 0.06)
    x = sum(np.sin(2 * np.pi * m * ph) / m ** (1.6 - 0.5 * bright) for m in range(1, 9))
    return x * env * 0.32
def bassoon(f, d):
    t = tt(d); ph = f * t
    x = np.sin(2 * np.pi * ph) + 0.6 * np.sin(4 * np.pi * ph) + 0.35 * np.sin(6 * np.pi * ph)
    return x * np.minimum(1, t / 0.02) * np.exp(-t * 5) * 0.45
def snare(): t = tt(0.16); return (lp(noise(0.16), 2) * np.exp(-t * 28) * 0.6 + np.sin(2 * np.pi * 190 * t) * np.exp(-t * 40) * 0.4)
def kick(): t = tt(0.25); return np.sin(2 * np.pi * (50 + 80 * np.exp(-t * 30)) * t) * np.exp(-t * 12)
def timp_roll(d):
    t = tt(d); x = np.zeros_like(t)
    for k in np.arange(0, d, 0.05): P_ = int(k * SR); seg = np.sin(2 * np.pi * 73 * tt(0.2)) * np.exp(-tt(0.2) * 18); x[P_:P_ + len(seg)] += seg[:len(x[P_:P_ + len(seg)])]
    return x * (t / d) ** 1.5 * 0.5
def celesta(f, d=0.9):
    t = tt(d); return (np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 8)) * np.exp(-t * 4) * 0.35
def cymbal(d=1.2): t = tt(d); return lp(noise(d), 1) * np.exp(-t * 3) * 0.25

NOTE = lambda n: 440 * 2 ** ((n - 69) / 12)

sfx = np.zeros((N, 2)); mus = np.zeros((N, 2)); amb = np.zeros((N, 2))

# ===== A hero
P(mus, timp_roll(0.5), 0.0, 0.5)
for f in (NOTE(53), NOTE(57), NOTE(60), NOTE(65)): P(mus, brass(f, 1.1, 1.0), 0.05, 0.45)
P(mus, cymbal(1.6), 0.05, 0.6); P(mus, kick(), 0.05, 0.9)
for k, (n, d) in enumerate(((65, 0.25), (69, 0.25), (72, 0.5), (77, 1.1))):
    for f in (NOTE(n), NOTE(n - 12)): P(mus, brass(f, d + 0.05, 1.0, 0.5), 1.1 + sum(x[1] for x in ((65, 0.25), (69, 0.25), (72, 0.5), (77, 1.1))[:k]), 0.35)
P(amb, flapping(2.9), 0.0, 0.7, 0.3)
# ===== B bunny
P(sfx, whoosh(0.45), 2.75, 0.5)
for k in (3.1, 3.7, 4.2, 5.4, 6.0): P(amb, bird(rnd.uniform(2600, 3600)), k, 0.5, rnd.uniform(-0.7, 0.7))
for k in (3.55, 3.62): P(sfx, lp(noise(0.05), 8) * 0.5, k, 0.5)
P(sfx, boing(), 4.80, 0.8); P(sfx, squeak(), 4.85, 0.6)
for i in range(14):
    P(sfx, pop(rnd.uniform(500, 1100)), 4.92 + (i * 0.061) % 0.9, 0.45, rnd.uniform(-0.6, 0.6))
for k, n in enumerate((72, 76, 79, 84)): P(mus, pizz(NOTE(n), 0.3), 4.80 + k * 0.08, 0.6)
# ===== C Tilsit
P(sfx, whoosh(0.4), 6.5, 0.5)
P(amb, water(3.5), 6.6, 0.5)
P(sfx, clap(), 7.95, 0.5); P(sfx, clap(), 8.25, 0.4)
P(sfx, paper(), 8.5, 0.6); P(sfx, stamp_hit(), 8.88, 0.7)
P(amb, lp(noise(1.2), 3) * np.sin(np.pi * tt(1.2) / 1.2) * 0.12, 9.0, 0.6)
# ===== D wants a hunt
P(sfx, whoosh(0.45), 9.85, 0.5)
for k, (n, d) in enumerate(((67, 0.18), (67, 0.18), (72, 0.18), (76, 0.5))):
    P(sfx, brass(NOTE(n), d, 1.0), 10.35 + k * 0.2, 0.45, 0.2)
P(sfx, pop(700), 11.15, 0.5)
for k in (11.3, 11.5, 11.7, 11.9): P(sfx, rustle(0.15), k, 0.35)
# ===== E Berthier + cages
P(sfx, whoosh(0.45), 12.72, 0.5)
for k in (13.05, 13.35, 13.6): P(sfx, knock(), k, 0.5, 0.3)
for k in (13.9, 14.4, 15.2, 15.6, 16.0): P(sfx, squeak(2200, 3000, 0.07), k, 0.3, rnd.uniform(-0.5, 0.5))
P(sfx, whoosh(0.6), 14.6, 0.4)
# ===== F cages open
for k in (16.70, 16.92):
    P(sfx, creak(0.25), k, 0.5); P(sfx, knock(), k + 0.22, 0.8)
# ===== G guns
P(sfx, whoosh(0.4), 17.72, 0.5)
for k in range(5): P(sfx, click(), 18.45 + k * 0.08, 0.5, -0.6 + k * 0.3); P(sfx, click(), 18.52 + k * 0.08, 0.35, -0.6 + k * 0.3)
P(sfx, riser(1.3), 18.6, 0.5)
# ===== H don't run
P(amb, crickets(2.0), 19.98, 0.9)
P(sfx, ting(2400), 20.95, 0.35); P(sfx, ting(3000), 21.02, 0.25)
for f in (NOTE(38), NOTE(50)): P(mus, brass(f, 0.5, 0.3), 21.1, 0.4); P(mus, brass(f * 1.06, 0.7, 0.3), 21.6, 0.4)
# ===== I/J stampede + swarm
P(sfx, impact(), 22.0, 0.7)
P(sfx, patter(7.2, 30, 1.0), 22.0, 0.7); P(amb, rumble(7.2), 22.0, 0.5)
for k in np.arange(22.2, 29.3, 0.33): P(sfx, squeak(rnd.uniform(1700, 2400), rnd.uniform(2400, 3200), 0.08), k + rnd.uniform(0, 0.15), 0.25, rnd.uniform(-0.6, 0.6))
for ta in (24.3, 24.5, 24.9, 25.3, 25.7, 26.05): P(sfx, rustle(0.2), ta, 0.5); P(sfx, pop(500), ta, 0.25)
P(sfx, boing(), 26.35, 0.6)
# ===== K whips + sticks
for k in range(40):
    tc = (math.pi / 2 + 2 * math.pi * k) / 11
    if 27.25 < tc < 29.35: P(sfx, whipcrack(), tc, 0.55, -0.5)
    ts = (math.pi / 2 - 1 + 2 * math.pi * k) / 10
    if 27.25 < ts < 29.35: P(sfx, whoosh(0.25), ts - 0.12, 0.55, 0.5)
P(sfx, whoosh(0.4), 27.05, 0.4)
# ===== L sad trombone
for k, (n, d) in enumerate(((58, 0.3), (57, 0.3), (56, 0.3), (55, 0.9))):
    P(mus, brass(NOTE(n), d, 0.6, 1.5 if k == 3 else 0.2), 29.42 + k * 0.32, 0.55)
# ===== M chase
P(sfx, whoosh(0.4), 30.6, 0.5)
for k in np.arange(30.8, 32.85, 0.118): P(sfx, step(), k, 0.45, -0.2)
P(sfx, patter(3.0, 24, 0.8), 30.8, 0.5)
P(sfx, creak(0.3), 32.42, 0.5); P(sfx, impact(0.6, 70), 32.92, 0.7); P(sfx, knock(), 32.92, 0.9)
for i in range(16):
    P(sfx, squeak(2000, 2900, 0.07), 33.85 + i * 0.16, 0.2, 0.3)
    P(sfx, thunk(), 33.85 + i * 0.16 + 0.45, 0.45, 0.3)
# ===== N why
P(mus, pizz(NOTE(67), 0.4), 35.92, 0.7); P(mus, pizz(NOTE(74), 0.5), 36.08, 0.7)
# ===== O wild / tame
P(sfx, whoosh(0.35), 36.6, 0.4)
P(amb, crickets(1.5), 36.72, 0.5)
P(sfx, rustle(0.3), 37.3, 0.6); P(sfx, buzzer(), 37.55, 0.5)
P(sfx, whoosh(0.35), 38.1, 0.4)
P(sfx, ding(), 38.6, 0.6)
for k in np.arange(38.8, 40.1, 0.18): P(sfx, chomp(), k, 0.4, rnd.uniform(-0.4, 0.4))
# ===== P walk
for k in np.arange(40.4, 42.6, 0.45): P(sfx, step(), k, 0.3)
for k in (40.6, 41.4, 42.1): P(amb, bird(rnd.uniform(2800, 3500)), k, 0.3, rnd.uniform(-0.6, 0.6))
# ===== Q dinner
P(sfx, bell_ring(1.4), 42.72, 0.7); P(sfx, pop(650), 43.05, 0.5)
for k in np.arange(43.1, 44.2, 0.25): P(sfx, squeak(2300, 3100, 0.06), k, 0.2, rnd.uniform(-0.5, 0.5))
for i in range(8): P(sfx, pop(rnd.uniform(500, 900)), 44.25 + i * 0.03, 0.3, rnd.uniform(-0.6, 0.6))

# ---------------- music beds ----------------
def march(a, b, bpm=116, g=1.0):
    beat = 60 / bpm; k = 0; t = a
    prog = [(53, 65), (60, 64), (58, 62), (60, 64)]   # F, C, Bb, C roots
    mel = [72, 74, 76, 77, 79, 77, 76, 74, 72, 76, 79, 84, 82, 79, 76, 74]
    while t < b - 0.01:
        bar = (k // 4) % 4; r = prog[bar][0]
        if k % 2 == 0: P(mus, bassoon(NOTE(r - 12), beat * 0.8), t, 0.7 * g)
        else: P(mus, pizz(NOTE(r + 7), 0.25), t, 0.45 * g, -0.3); P(mus, pizz(NOTE(r + 12), 0.25), t, 0.35 * g, -0.3)
        if k % 2 == 1: P(mus, snare(), t, 0.25 * g)
        P(mus, pizz(NOTE(mel[k % 16]), 0.3), t, 0.5 * g, 0.3)
        if k % 4 == 3: P(mus, pizz(NOTE(mel[(k + 1) % 16]), 0.2), t + beat / 2, 0.35 * g, 0.3)
        t += beat; k += 1
def galop(a, b, bpm=168, g=1.0):
    beat = 60 / bpm; k = 0; t = a
    mel = [76, 77, 79, 81, 79, 77, 76, 74, 72, 74, 76, 77, 79, 79, 79, 72]
    prog = [53, 48, 53, 48]
    while t < b - 0.01:
        r = prog[(k // 8) % 4]
        if k % 2 == 0: P(mus, bassoon(NOTE(r - 12), beat * 0.6), t, 0.7 * g); P(mus, kick(), t, 0.35 * g)
        else: P(mus, snare(), t, 0.35 * g); P(mus, pizz(NOTE(r + 4), 0.15), t, 0.4 * g, -0.3); P(mus, pizz(NOTE(r + 7), 0.15), t, 0.4 * g, -0.3)
        P(mus, brass(NOTE(mel[k % 16]), beat * 0.85, 1.0), t, 0.28 * g, 0.25)
        t += beat; k += 1
def musicbox(a, b, g=1.0):
    notes = [72, 76, 79, 76, 74, 77, 81, 77, 72, 76, 79, 84, 83, 79, 76, 74]
    t = a; k = 0
    while t < b - 0.01:
        P(mus, celesta(NOTE(notes[k % 16])), t, 0.5 * g, 0.2 * math.sin(k))
        if k % 4 == 0: P(mus, celesta(NOTE(notes[k % 16] - 24), 1.4), t, 0.35 * g)
        t += 0.3; k += 1
march(6.64, 19.95)
galop(22.0, 29.35)
galop(30.74, 35.85, 176, 0.9)
musicbox(36.72, 42.65)
for f in (NOTE(65), NOTE(69), NOTE(72), NOTE(77)): P(mus, brass(f, 0.9, 1.0), 42.72, 0.35)
P(mus, cymbal(1.2), 42.72, 0.4)
musicbox(43.4, 44.9, 0.8)
for f in (NOTE(65), NOTE(72), NOTE(77)): P(mus, pizz(f, 0.6), 44.55, 0.6)

def verb(x, dec=0.35, dl=(0.031, 0.047, 0.061, 0.083, 0.11)):
    y = x.copy()
    for d_ in dl:
        k = int(d_ * SR); z = np.zeros_like(x); z[k:] = x[:-k] * dec; y += z
    return y
mus = verb(mus, 0.28); sfx = verb(sfx + amb * 0.6, 0.18)
def wr(fn, x):
    w = wave.open(fn, 'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    x = x / (np.abs(x).max() + 1e-9) * 0.9
    w.writeframes((x * 32767).astype(np.int16).tobytes()); w.close()
wr('work/music.wav', mus); wr('work/sfx.wav', sfx)
print('ok')
