# FableVerse 2D Shorts engine (Python + OpenCV + NumPy + PIL, ffmpeg)

Start a new chat, attach this zip (or point Claude to it in Drive > Animation),
and say: "Use the FableVerse engine and workflow for a new Short on <topic>."

## Folders


## v3 style (inside v2/, Nov 2026) — premium toon look
- char3.py   original egg-head toons (thick outlines, dot eyes + lids/brows, thin limbs), toon(), track() snappy poses
              NO lip sync: characters act with expressions while the narrator talks
- set25d.py  + camera pitch, bump-lit realistic textures: tex_wood_floor, tex_plaster, tex_parchment, fbm, dof_blur
- sfx3.py    crisp foley kit (swish, tick, clink, thump, heel, rustle, paper, quill, sniff, squeak, hop, shock hit,
              stamp, squish, sparkle, creak, pat, gulp, riser) + beds (room tone, candle, birds, water, crickets)
              + duck() music under voice
- demo3.py / demo3_audio.py  reference 10 s sequence: cut every ~1.1 s, macro prop shots, DOF, one-word captions

## v2/  (NEWEST, Nov 2026 training build) — start premium Shorts from here
- lipsync.py   audio -> per-frame mouth shapes (rest, MBP, small, A, E, O, U, FV) + jaw open; no ASR needed
- face.py      face rig v2 for rig.human(face_fn=Face(expr('proud'), viseme, open)):
               eyes w/ iris + lids + lower-lid squint, tapered brows, 8 mouth shapes,
               expressions: neutral happy proud smug angry worried scared shocked sad deadpan excited sly confused
               timeline([(t, expr(...)), ...], t) cross-fades emotions
- set25d.py    2.5D perspective sets: Cam(x,y,z,f), plane() textured floors/walls/ceilings (homography + near clip),
               board() puts any rig/prop at a world point, floor_shadow(), procedural marble/carpet/wall textures, column()
- look.py      premium look stack: paint_texture, haze, grade LUT, bloom, god_rays, sun_glow, Motes (dust),
               grain, chroma, dof_layer (blurred foreground), key_light (directional light), contrast, cast_shadow
- props.py     rabbits (side/front/back views, hop), coach, cages, raft, pavilion, musket, whip, stick, carrot, flag, rock, bell
- rig.py       + outfits napoleon, berthier, tsar, hunter, hunter2; bicorne/tricorne/round hats; tall boots; head cel-shading
- demo_talk.py reference scene: talking Napoleon in palace hall with lip sync, expressions, reflections, window light
## napoleon_rabbits/  first premium-look Short (2.5D meadow sets, motion blur, cinematic swarm shots, synth SFX)

## Premium checklist (learned from Ricks Clips study, Nov 2026)
- faces above captions; close-ups and low angles over wide frontal shots; a cut every ~2.5-3.5 s
- directional key light + rays + dust + contact/long shadows; avoid washed-out haze
- motion blur on fast action (mb=True renders 5 sub-frames); shake on impacts
- characters ACT: lip sync, expression changes per line, gestures on stressed words
- a sound effect for nearly every action; music ducks under voice (-6 dB)
- calm curiosity titles ("Why X...", "How X worked")
- Still missing without laptop: true 3D (Blender), hand-drawn character art, recorded SFX library

- dancing_plague/  NEWEST engine. Start every new Short from here.
  - rig.py    characters + props: human(), dancer() (styles bounce/spin/kick/hold/star),
              outfits (peasants, doctor, musician, council, priest, troffea), hats, crowds
  - render.py camera keyframes, @shot(t0,t1,bg) shots, whip-pans, white flashes,
              captions (white text, stroke + soft shadow, key words yellow), HUD props
  - audio.py  synthesized music + SFX stems -> music.wav, sfx.wav
  - mix.py    voice / music / sfx mix (music -6 dB vs voice; SFX ratio from env)
  - sheet.py  contact sheet of stills
  - work/timing.json  phrase timings (render.py reads this path)
- emu_war/   older engine with extra props: emu (crested), 1930s truck, Lewis gun,
             soldiers, wheat field with world-fixed foreground wheat, dust trails, tracking pans
- fonts/     Poppins Bold/ExtraBold, DejaVu Sans Bold (copy to /usr/share/fonts/... if missing)

## Run
  S=0.3333333 python3 render.py frames ff 0-1798     # 360p preview frames
  S=1 python3 render.py frames ff 0-1798             # 1080x1920 final (split in 2 processes)
  python3 render.py stills st 3.2,10.5,22.0          # stills at times
  NOTEXT=1 ... stills                                # no captions/HUD (thumbnails)
  python3 audio.py ; SFXR=0.3 SFXCAP=0.5 python3 mix.py voice.mp3 music.wav sfx.wav
  ffmpeg -r 30 -i ff/f%05d.jpg -i mix.wav -c:v libx264 -crf 17 -pix_fmt yuv420p -c:a aac -b:a 256k out.mp4
  Loudness: one linear gain to -15 LUFS + alimiter. Upload copy ~5.5 Mbps (<40 MB).

## Timing
ffmpeg silencedetect at -45 dB (and -35 dB), match segments to script phrases by
syllable count, words weighted by syllables -> timing.json.

## Workflow + rules (user's standing rules)
1. User picks topic. Funny/surprising true history with a twist. Under 1 min (~125 words).
2. Plain script first, wait for approval. Then "Voice script for <title>": ONE paragraph,
   v4 tags, paste-safe. Eleven v4, voice Roger (Laid-Back Casual Resonant), stability 50, similarity 75.
   Never use/connect ElevenLabs; user records.
3. 360p preview -> fixes as short clips only (changed part +1 s before/after, merge changes
   within 2-3 s), with sound and times. Stills OK for look-only fixes. Full render only at end.
4. Self-review every frame; fix what looks bad without being told.
5. 4 thumbnails A-D; title, description, captions match the chosen one.
6. User uploads MP4 to Drive "Animation" folder; share anyone-with-link; vidIQ video_upload
   (free) + approved thumbnail only. Show drafts, publish only on explicit "yes".
   Remind user to set Drive files back to Restricted.
7. Post ONLY at 7:30 AM or 11:45 PM IST, YouTube + Instagram, tier-one audience.
8. Never spend vidIQ/tool credits without telling cost per step first.
9. Show progress status each step; keep "FableVerse 30-Day Posting Schedule" sheet status
   in step (Planned > Scripted > Voiceover > Preview > Ready > Scheduled > Posted).
