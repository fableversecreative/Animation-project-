---
name: fableverse-premium-shorts
description: Make FableVerse animated history Shorts in the premium toon style with this engine (v3 + Blender plates): script, voice script, preview, fixes, final, thumbnails, posting.
---
# FableVerse premium Shorts (Claude Code copy)
Read ../../../README.md first, then follow the same rules as the claude.ai skill "fableverse-premium-shorts":
- Workflow: user picks topic -> plain script (<1 min, true history + twist) -> approval -> "Voice script for <title>" (ElevenLabs v4 tags, Roger, stab 50, sim 75; user records) -> 360p preview -> fix clips (changed part ±1 s) -> final 1080x1920 -> 4 thumbnails -> posting kit -> schedule 7:30 AM / 11:45 PM IST. Never spend tool credits without stating cost first.
- Look: original egg-head toons (v2/char3.py), NO lip sync, expressions + snappy poses; cut every 1-1.5 s; macro prop shots; one-word captions; 2.5D sets (v2/set25d.py) or Blender plates (v2/blender/hall_plate.py, Eevee) composited with plate_bg + cam_from_keys; warm key light, rays, dust, DOF, motion blur, shake.
- Sound: v2/sfx3.py, a crisp effect every ~0.7 s, whoosh per cut, ambience beds, music ducked under voice, -15 LUFS.
- Self-review contact sheets before sending. All designs original.
