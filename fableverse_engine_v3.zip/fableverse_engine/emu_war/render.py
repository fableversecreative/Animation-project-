import numpy as np, cv2, math, json, sys, os, random
from rig import *

W, H, FPS = 1080, 1920, 30
DUR = 71.70
NF = int(round(DUR * FPS))
S = float(os.environ.get('S', '0.3333333'))
OW, OH = int(round(W * S)), int(round(H * S))
MARG = 420

def rng(seed): return random.Random(seed)

# ---------------- backgrounds (cached, design coords + margin) ----------------
_bg = {}
def gradient(img, y0, y1, c0, c1):
    for y in range(max(0, y0), min(img.shape[0], y1)):
        t = (y - y0) / max(1, y1 - y0)
        img[y, :] = [int(lerp(c0[i], c1[i], t)) for i in range(3)]

BGOFF = {}
def bgimg(kind):
    if kind in _bg: return _bg[kind]
    if kind.endswith('_blur'):
        b = bgimg(kind[:-5]); k = int(28 * S) | 1
        BGOFF[kind] = BGOFF[kind[:-5]]
        _bg[kind] = cv2.GaussianBlur(b, (k, k), 0); return _bg[kind]
    field = kind in ('day', 'gold', 'dusk')
    mxl, mxr = (900, 3600) if field else (MARG, MARG)
    BGOFF[kind] = (mxl, MARG)
    bw, bh = int((W + mxl + mxr) * S), int((H + 2 * MARG) * S)
    img = np.zeros((bh, bw, 3), np.uint8)
    d = D(img, Aff(mxl * S, MARG * S, S))
    XL, XR = -mxl, W + mxr
    r = rng(hash(kind) % 1000)
    if kind in ('day', 'gold', 'dusk'):
        sky = {'day': (C('7fc4ef'), C('f3e6c4')), 'gold': (C('f2a65a'), C('ffe2a8')), 'dusk': (C('6a5fa8'), C('f6a26a'))}[kind]
        hz = 900
        gradient(img, 0, int((MARG + hz) * S), sky[0], sky[1])
        sx, sy = (760, 520) if kind == 'day' else (300, 760)
        sc_ = C('fff4c2') if kind == 'day' else C('ffd27a')
        for rr, a in ((260, 0.12), (170, 0.2)):
            ov = img.copy(); d2 = D(ov, d.M); d2.ell(sx, sy, rr, rr, sc_, None, 0)
            img[:] = cv2.addWeighted(ov, a, img, 1 - a, 0)
        d.ell(sx, sy, 90, 90, sc_, None, 0)
        # clouds
        for i in range(16):
            cx = r.uniform(XL, XR); cy = r.uniform(150, 600)
            for j in range(4):
                d.ell(cx + j * 60 - 90, cy + (0 if j % 3 else -25), 80, 46, shade(sky[1], 1.04) if kind != 'day' else C('ffffff'), None, 0)
        # far hills
        for layer, (col, base, amp) in enumerate(((C('9fb38a') if kind == 'day' else C('c98f6a'), hz - 60, 60), (C('7f9a6a') if kind == 'day' else C('a8755a'), hz - 15, 35))):
            xs = np.linspace(XL, XR, 160)
            ys = base - amp * (0.5 + 0.5 * np.sin(xs / 210 + layer * 2.1)) - 18 * np.sin(xs / 67 + layer)
            pts = np.concatenate([np.stack([xs, ys], 1), [[XR, hz + 40], [XL, hz + 40]]])
            d.poly(pts, col, None)
        # field
        fc0 = {'day': C('dda23a'), 'gold': C('df9536'), 'dusk': C('c07e3c')}[kind]
        fc1 = shade(fc0, 1.12)
        gradient(img, int((MARG + hz) * S), bh, shade(fc0, 0.92), fc1)
        # trees on horizon
        for i in range(30):
            tx = r.uniform(XL, XR); ty = hz + r.uniform(-4, 10); s_ = r.uniform(0.5, 1.0)
            d.tube([(tx, ty), (tx + 4, ty - 120 * s_)], 10 * s_, C('8a7a6a'), INK, 2)
            for j in range(4):
                d.ell(tx + r.uniform(-50, 50) * s_, ty - 130 * s_ + r.uniform(-30, 30) * s_, 50 * s_, 34 * s_, C('6d8c5a') if kind == 'day' else C('8a7a4a'), INK, 2)
        # farmhouse far right
        hx = 930
        for hx in (930, 2600, -700):
          d.poly([(hx, hz + 10), (hx + 150, hz + 10), (hx + 150, hz - 60), (hx, hz - 60)], C('e8dcc4'), INK, 3)
          d.poly([(hx - 15, hz - 60), (hx + 165, hz - 60), (hx + 75, hz - 115)], C('b0473c'), INK, 3)
          d.poly([(hx + 60, hz + 10), (hx + 90, hz + 10), (hx + 90, hz - 30), (hx + 60, hz - 30)], C('7a5530'), INK, 2)
        # far fence
        for i in range(int(XL / 60), int(XR / 60)):
            fx = i * 60
            d.line([(fx, hz + 30), (fx, hz - 5)], C('7a5a3a'), 4)
        d.line([(XL, hz + 5), (XR, hz + 5)], C('7a5a3a'), 3); d.line([(XL, hz + 18), (XR, hz + 18)], C('7a5a3a'), 3)
        # wheat: rows + ear glyphs with perspective
        for i in range(60):
            y = hz + 20 + (i / 60) ** 1.7 * (H + MARG - hz)
            d.line([(XL, y), (XR, y + r.uniform(-6, 6))], shade(fc0, r.choice((0.86, 1.1))), 3 + (y - hz) / 120)
        # cloud shadows
        ov = img.copy(); d3 = D(ov, d.M)
        for i in range(12):
            d3.ell(r.uniform(XL, XR), hz + r.uniform(150, 900), r.uniform(300, 600), r.uniform(60, 150), shade(fc0, 0.72), None, 0)
        img[:] = cv2.addWeighted(ov, 0.35, img, 0.65, 0)
        glyphs = []
        ng = int(13000 * (XR - XL) / 1920)
        for i in range(ng):
            y = hz + 22 + (r.random() ** 1.35) * (H + MARG - hz)
            glyphs.append((y, r.uniform(XL, XR), r.choice((0.74, 0.86, 1.0, 1.12, 1.22)), r.uniform(-0.25, 0.25)))
        glyphs.sort()
        for y, x, f_, sw in glyphs:
            sz = 0.12 + (y - hz) / 1000.0
            if sz > 0.32:
                wheat_ear(d, x, y, 120 * sz * 1.6, sw * 0.4, sz * 0.9, shade(fc0, f_), ink=(sz > 0.75), awn=(sz > 0.5))
            else:
                col = shade(fc0, f_)
                d.line([(x, y), (x + sw * 20 * sz, y - 70 * sz)], shade(col, 0.78), max(1.0, 3 * sz))
                for j in range(3):
                    d.ell(x + sw * 26 * sz + (j % 2 * 2 - 1) * 3 * sz, y - (66 + j * 12) * sz, 4 * sz + 0.8, 7 * sz + 1, shade(col, 1.0 if j % 2 else 0.88), None, 0, ang=sw * 0.5 + (j % 2 * 2 - 1) * 0.4, n=8)
                d.line([(x + sw * 26 * sz, y - 100 * sz), (x + sw * 30 * sz, y - 128 * sz)], shade(col, 1.15), max(0.8, 1.2 * sz))
    elif kind == 'tent':
        gradient(img, 0, bh, C('d9c7a0'), C('bfa77a'))
        for i in range(-3, 14):
            x = i * 110; d.line([(x, -MARG), (x + 40, H + MARG)], C('c7b386'), 8)
        d.poly([(-MARG, 1480), (W + MARG, 1480), (W + MARG, H + MARG), (-MARG, H + MARG)], C('8a6a44'), INK, 5)
        for i in range(-3, 16): d.line([(i * 90, 1480), (i * 90 - 60, H + MARG)], C('7a5c38'), 4)
    elif kind == 'house':
        gradient(img, 0, bh, C('c9935e'), C('a8743f'))
        for i in range(-6, 30):
            y = i * 80; d.line([(-MARG, y), (W + MARG, y)], C('8e5f33'), 5)
        d.poly([(120, 300), (560, 300), (560, 760), (120, 760)], C('9fd3ec'), INK, 8)
        d.line([(340, 300), (340, 760)], INK, 8); d.line([(120, 530), (560, 530)], INK, 8)
        d.poly([(-MARG, 1500), (W + MARG, 1500), (W + MARG, H + MARG), (-MARG, H + MARG)], C('6b4a2e'), INK, 5)
    elif kind == 'blue':
        img[:] = C('1f4f8a')
        for i in range(-10, 40):
            d.line([(i * 60, -MARG), (i * 60, H + MARG)], C('3a6ca8'), 2)
            d.line([(-MARG, i * 60), (W + MARG, i * 60)], C('3a6ca8'), 2)
    _bg[kind] = img
    return img

VIG = None
def vignette():
    global VIG
    if VIG is None:
        y, x = np.mgrid[0:OH, 0:OW]
        r = np.sqrt(((x - OW / 2) / (OW / 2)) ** 2 + ((y - OH / 2) / (OH / 2)) ** 2)
        VIG = (1 - 0.28 * np.clip(r - 0.55, 0, 1) ** 1.5)[..., None].astype(np.float32)
    return VIG

# ---------------- camera ----------------
def cam_keys(keys, t):
    """keys: list of (time, cx, cy, z, rot). smootherstep between."""
    if t <= keys[0][0]: k = keys[0]; return k[1:]
    for a, b in zip(keys, keys[1:]):
        if t <= b[0]:
            u = (t - a[0]) / max(1e-6, b[0] - a[0])
            e = b[5] if len(b) > 5 else 's'
            u = smooth(u) if e == 's' else eout(u) if e == 'o' else u
            return tuple(lerp(a[i], b[i], u) for i in range(1, 5))
    k = keys[-1]; return k[1:5]

def camM(cx, cy, z, rot, shake=(0, 0)):
    R = Aff(0, 0, z, rot)
    T = Aff(-cx, -cy)
    C2 = Aff(W / 2 + shake[0], H / 2 + shake[1])
    return Aff(0, 0, S) @ C2 @ R @ T

def shake_at(t, kicks, amp=14):
    sx = sy = 0
    for k in kicks:
        dt = t - k
        if 0 <= dt < 0.25:
            a = amp * (1 - dt / 0.25)
            sx += a * math.sin(dt * 90); sy += a * math.cos(dt * 70)
    return sx, sy

# ---------------- HUD helpers (screen design coords) ----------------
def hud_text(img, txt, x, y, size, rgb=(255, 255, 255), scale=1.0, alpha=1.0, rot=0.0, font=None):
    spr = text_sprite(txt, int(size * S), rgb, 0.14, font)
    blit(img, spr, x * S, y * S, scale, alpha, rot)

def pop(t, t0, dur=0.25):
    if t < t0: return 0.0
    return back((t - t0) / dur, 2.2)

def tag(img, txt, t, t0, t1, y=170):
    if t < t0 or t > t1: return
    a = clamp((t - t0) / 0.15) * clamp((t1 - t) / 0.2)
    sc = 0.6 + 0.4 * pop(t, t0, 0.3)
    hd = D(img, Aff(0, 0, S))
    w = len(txt) * 30 + 70
    ov = img.copy(); D(ov, Aff(0, 0, S)).poly([(540 - w / 2 * sc, y - 42 * sc), (540 + w / 2 * sc, y - 42 * sc), (540 + w / 2 * sc, y + 42 * sc), (540 - w / 2 * sc, y + 42 * sc)], C('2a1a2a'), None)
    img[:] = cv2.addWeighted(ov, 0.6 * a, img, 1 - 0.6 * a, 0)
    hud_text(img, txt, 540, y, 54, (255, 214, 64), sc, a)

def board(img, t, t0, army, emus, flip_t=None, y=330, x=540):
    """wooden scoreboard"""
    if t < t0: return
    sc = pop(t, t0, 0.35)
    d = D(img, Aff(0, 0, S)).sub(Aff(x, y, sc))
    d.poly([(-300, -95), (300, -95), (300, 95), (-300, 95)], C('8a5a32'), INK, 7)
    for i in range(-2, 3): d.line([(-296, i * 38), (296, i * 38)], C('734a28'), 3)
    d.poly([(-6, -80), (6, -80), (6, 80), (-6, 80)], C('5a3a20'), None)
    hud_text(img, 'ARMY', x - 150 * sc, y - 45 * sc, 46, (255, 240, 220), sc)
    hud_text(img, 'EMUS', x + 150 * sc, y - 45 * sc, 46, (255, 240, 220), sc)
    e = emus
    sp = 1.0
    if flip_t is not None and t >= flip_t:
        sp = 0.7 + 0.3 * back((t - flip_t) / 0.3)
    hud_text(img, str(army), x - 150 * sc, y + 35 * sc, 84, (255, 255, 255), sc)
    hud_text(img, str(e), x + 150 * sc, y + 35 * sc, 84, (255, 214, 64), sc * sp)

def counter(img, t, t0, t1, v0, v1, label, y=330, x=540, color=(255, 214, 64)):
    if t < t0: return
    u = eout((t - t0) / max(0.01, t1 - t0))
    v = int(round(lerp(v0, v1, u)))
    sc = pop(t, t0, 0.3)
    d = D(img, Aff(0, 0, S)).sub(Aff(x, y, sc))
    d.poly([(-280, -100), (280, -100), (280, 100), (-280, 100)], C('2a1a2a'), C('ffd640'), 6)
    hud_text(img, label, x, y - 50 * sc, 40, (255, 255, 255), sc)
    hud_text(img, f'{v:,}', x, y + 30 * sc, 90, color, sc)

def world_text(d, txt, x, y, size, rgb):
    q = d.tp([(x, y)])[0]
    spr = text_sprite(txt, max(6, int(size * d.k)), rgb, 0.0)
    blit(d.img, spr, q[0], q[1])

# ---------------- crowd helper ----------------
def herd(d, t, n, seed, x0, x1, y0, y1, speed=0.0, flip=1, run=1.0, scale_base=0.55, neckf=0.6, wrap=None, faces=None):
    r = rng(seed)
    items = []
    for i in range(n):
        x = r.uniform(x0, x1); y = r.uniform(y0, y1); ph = r.uniform(0, 6.28)
        items.append((y, x, ph, i))
    items.sort()
    for y, x, ph, i in items:
        sc = scale_base * (0.45 + 0.55 * (y - y0) / max(1, y1 - y0)) * 1.0 + 0.0
        xx = x + speed * t * flip * (0.8 + 0.4 * ((i * 37) % 10) / 10)
        if wrap: xx = (xx - wrap[0]) % (wrap[1] - wrap[0]) + wrap[0]
        if run > 0.6: trail(d, xx, y, t, flip, sc, i, 0.8)
        emu(d, xx, y, sc, flip, run, ph + t * 14 * (0.5 + run * 0.5), neckf, face='open')

def dust(d, x, y, t, t0, n=6, size=40, seed=1):
    if t < t0 or t > t0 + 0.9: return
    u = (t - t0) / 0.9; r = rng(seed)
    for i in range(n):
        a = r.uniform(math.pi, 2 * math.pi); dd = 30 + u * r.uniform(60, 140)
        rr = size * (0.5 + u) * (1 - u * 0.7)
        d.ell(x + math.cos(a) * dd, y + math.sin(a) * dd * 0.5, rr, rr * 0.8, C('e2cfa6'), INK, 2)

def speedlines(d, t, y0, y1, n=14, seed=3, dirn=-1):
    r = rng(seed)
    for i in range(n):
        y = r.uniform(y0, y1); x = ((r.uniform(0, 1400) + dirn * t * 2600) % 1600) - 260
        d.line([(x, y), (x + 220 * -dirn, y)], C('fff6dc'), 6)

def bullets_row(d, x, y, n, sc=1.0, t=0, t0=0, step=0.08):
    for i in range(n):
        if t < t0 + i * step: continue
        p = pop(t, t0 + i * step, 0.2)
        bx = x + i * 70 * sc
        L = d.sub(Aff(bx, y, sc * p))
        L.poly([(-14, 0), (14, 0), (14, -60), (-14, -60)], C('d9a640'), INK, 4)
        L.poly([(-14, -60), (14, -60), (8, -88), (0, -96), (-8, -88)], C('b87333'), INK, 4)

def crate(d, x, y, sc=1.0, label='', empty=False, tilt=0.0):
    L = d.sub(Aff(x, y, sc, tilt))
    L.poly([(-110, 0), (110, 0), (110, -140), (-110, -140)], C('a87444'), INK, 5)
    for k in (-35, -70, -105): L.line([(-110, k), (110, k)], C('8a5a32'), 3)
    L.line([(-110, 0), (110, -140)], C('7a4e2a'), 6)
    if not empty:
        for i in range(6):
            L.poly([(-90 + i * 32, -140), (-70 + i * 32, -140), (-75 + i * 32, -175), (-85 + i * 32, -175)], C('d9a640'), INK, 3)

# ---------------- shots ----------------
SH = []
def shot(t0, t1, bg=None, light=None):
    def deco(fn):
        SH.append(dict(t0=t0, t1=t1, fn=fn, bg=bg)); return fn
    return deco

def emu_eye_world(x, y, sc, flip=1, **kw):
    dummy = np.zeros((4, 4, 3), np.uint8)
    q = emu(D(dummy, Aff()), x, y, sc, flip, **kw)
    return q

HERO = dict(x=470, y=1650, sc=2.3)

def draw_hero(d, t, face='open', mouth=None, look=(0, 0), tilt=0.0, wink=False, blink=False):
    return emu(d, HERO['x'], HERO['y'], HERO['sc'], 1, 0.0, 0, 0.0, face=face, mouth=mouth, tilt=tilt,
               bob=math.sin(t * 2.2) * 4, look=look, wink=wink, blink=blink, star=True)

EYE = None
def hero_eye():
    global EYE
    if EYE is None: EYE = emu_eye_world(HERO['x'], HERO['y'], HERO['sc'])
    return EYE

def blinkat(t, times):
    return any(0 <= t - k < 0.12 for k in times)

# S1 hook 0.0-3.8
@shot(0.0, 3.8, 'day')
def s1(t, lt):
    ex, ey = hero_eye()
    keys = [(0, ex + 4, ey + 2, 7.5, 0.05), (1.1, 520, 1050, 1.15, -0.03, 'o'), (2.3, 520, 1050, 1.05, 0.0), (2.6, 520, 1080, 1.22, 0.02, 'o'), (3.8, 530, 1080, 1.28, 0.02)]
    return keys, [2.55]
def s1_draw(d, t, lt):
    herd(d, t, 26, 11, -200, 1300, 930, 1180, speed=30, flip=-1, run=0.25, scale_base=0.7, neckf=0.2)
    for i, x in enumerate((-60, 1100)):
        emu(d, x, 1500, 1.4, 1 if i == 0 else -1, 0, 0, 0.1, bob=math.sin(t * 3 + i) * 4, face='open')
    face = 'wide' if 2.4 < lt < 3.8 else 'open'
    draw_hero(d, t, face=face, blink=blinkat(lt, [1.6]), look=(2, 0) if lt < 2.4 else (-3, 2))
    fg_wheat(d, t, 1840, n=22, seed=2, sc=1.9, h=280)
SH[-1]['draw'] = s1_draw

def hud_s1(img, t, lt):
    a = 1.0 if lt < 3.5 else clamp((3.8 - lt) / 0.3)
    pul = 1 + 0.03 * math.sin(lt * 7)
    hud_text(img, '1932: WAR', 540, 250, 140, (255, 255, 255), pul, a)
    hud_text(img, 'ON BIRDS?', 540, 410, 140, (255, 214, 64), pul, a)
SH[-1]['hud'] = hud_s1

# S2 chalkboard 3.8-7.4
@shot(3.8, 7.4, 'tent')
def s2(t, lt):
    return [(0, 540, 980, 1.25, 0.0), (1.8, 540, 960, 1.35, 0.0), (1.95, 560, 1000, 1.55, 0.03, 'o'), (3.6, 560, 1010, 1.62, 0.02)], [5.80 - 3.8 + 0.0]
def s2_draw(d, t, lt):
    # chalkboard
    d.poly([(160, 560), (920, 560), (920, 1180), (160, 1180)], C('2f4a3c'), C('7a5230'), 22)
    d.line([(140, 1210), (940, 1210)], C('7a5230'), 18)
    cx = 540
    T2 = 5.77 - 3.8
    if lt < T2:
        # countries: flag blobs crossed out
        for i, (x, y, c1, c2) in enumerate(((330, 760, 'c0392b', 'ffffff'), (750, 760, '2e5aa8', 'ffffff'), (330, 1000, 'e8b13a', '2a7a3a'), (750, 1000, 'ffffff', 'c0392b'))):
            d.poly([(x - 110, y - 70), (x + 110, y - 70), (x + 110, y + 70), (x - 110, y + 70)], C(c1), C('f2f2f2'), 5)
            d.poly([(x - 110, y - 20), (x + 110, y - 20), (x + 110, y + 20), (x - 110, y + 20)], C(c2), None)
            if lt > 0.35 + i * 0.22:
                u = clamp((lt - 0.35 - i * 0.22) / 0.12)
                d.line([(x - 120, y - 80), (lerp(x - 120, x + 120, u), lerp(y - 80, y + 80, u))], C('e74c3c'), 18)
                if u >= 1: d.line([(x + 120, y - 80), (x - 120, y + 80)], C('e74c3c'), 18)
    else:
        # chalk emu target
        u = clamp((lt - T2) / 0.3)
        d.ell(540, 870, 210 * u, 210 * u, None, C('f2f2f2'), 7)
        d.ell(540, 870, 120 * u, 120 * u, None, C('e74c3c'), 7)
        d.line([(540, 870 - 250 * u), (540, 870 + 250 * u)], C('f2f2f2'), 5); d.line([(540 - 250 * u, 870), (540 + 250 * u, 870)], C('f2f2f2'), 5)
    # officer pointing (left)
    human(d, 290, 1640, 1.25, 'officer', face='half' if lt < T2 else 'wide', mouth='smirk' if lt < T2 else 'o',
          armL=(150, 95), armR=(-15, 70), brow=-1 if lt < T2 else 1, bob=math.sin(lt * 3) * 3)
    if lt >= T2:
        p = back((lt - T2) / 0.35, 2.0)
        emu(d, 800, 1950 - 0 * p, 2.0, -1, 0, 0, 0.0, face='open', look=(-4, 0), tilt=math.sin(lt * 5) * 0.05,
            bob=-(1 - p) * -400 - 0) if False else emu(d, 820, 2200 - 520 * p, 2.0, -1, 0, 0, 0.0, face='open', look=(-4, 1), tilt=math.sin(lt * 5) * 0.05, star=True)
SH[-1]['draw'] = s2_draw
def hud_s2(img, t, lt):
    hud_text(img, 'ENEMY:', 540, 520 if False else 640 * 1, 0, (0, 0, 0), 0, 0)
SH[-1]['hud'] = None

# S3 wide herd 7.4-12.75
@shot(7.4, 12.75, 'day')
def s3(t, lt):
    return [(0, 540, 960, 1.0, 0.0), (5.35, 600, 980, 1.18, -0.02)], []
def s3_draw(d, t, lt):
    herd(d, lt, 70, 5, -200, 2600, 930, 1500, speed=320, flip=-1, run=1.0, scale_base=0.95, neckf=0.7, wrap=(-400, 1500))
    fg_wheat(d, t, 1800, n=26, seed=3, sc=1.9, h=280)
def hud_s3(img, t, lt):
    tag(img, 'WESTERN AUSTRALIA · 1932', t, 7.45, 12.7)
    counter(img, t, 7.62, 9.4, 0, 20000, 'HUNGRY EMUS', y=380)
SH[-1]['draw'] = s3_draw; SH[-1]['hud'] = hud_s3

# S4 damage 12.75-17.2
@shot(12.75, 17.2, 'day')
def s4(t, lt):
    return [(0, 560, 1250, 1.45, 0.0), (0.45, 560, 1250, 1.55, 0.01, 'o'), (2.5, 600, 1300, 1.6, 0.0), (2.7, 640, 1340, 1.7, -0.02, 'o'), (4.45, 650, 1350, 1.72, -0.02)], [13.15 - 12.75, 15.4 - 12.75]
def s4_draw(d, t, lt):
    tb = 13.15 - 12.75
    # fence posts
    for i in range(5):
        x = 180 + i * 190
        brk = (i == 2) and lt > tb
        ang = 0.0 if not brk else -min(1.2, (lt - tb) * 6)
        L = d.sub(Aff(x, 1430, 1, ang))
        L.poly([(-16, 0), (16, 0), (16, -220), (-16, -220)], C('8a6239'), INK, 5)
    if lt <= tb:
        d.line([(100, 1300), (1000, 1300)], C('7a5530'), 10); d.line([(100, 1360), (1000, 1360)], C('7a5530'), 10)
    else:
        d.line([(100, 1300), (500, 1310)], C('7a5530'), 10); d.line([(640, 1330), (1000, 1300)], C('7a5530'), 10)
        d.line([(100, 1360), (480, 1390)], C('7a5530'), 10); d.line([(660, 1395), (1000, 1360)], C('7a5530'), 10)
        dust(d, 560, 1400, lt, tb, 7, 50, 4)
    # wheat rows (flatten after 15.4)
    tf = 15.4 - 12.75
    for i in range(16):
        x = 60 + i * 70; flat = clamp((lt - tf - i * 0.02) / 0.2) if lt > tf and i > 6 else 0
        for j in range(3):
            L = d.sub(Aff(x + j * 18, 1620 + j * 30, 1, -flat * 1.3))
            wheat_tuft(L, 0, 0, 170, C('d9a53a'), math.sin(t * 2 + i) * 0.2, 6)
    # emu smashing through fence then eating
    if lt < tf:
        p = clamp((lt) / 0.6)
        emu(d, lerp(250, 620, eout(p)), 1500, 1.25, 1, 1.0 if p < 1 else 0.2, lt * 14, 0.8 if p < 1 else 0.3, face='angry' if p < 1 else 'open', star=True)
    else:
        pk = 0.5 + 0.5 * math.sin((lt - tf) * 12)
        emu(d, 760, 1560, 1.3, -1, 0, 0, 0.0, peck=pk if lt < 16.3 - 12.75 else 0.2, mouth='chew' if lt > 16.0 - 12.75 else None, face='half' if lt > 16.0 - 12.75 else 'open', star=True)
        emu(d, 1080, 1520, 1.1, -1, 0, 0, 0.0, peck=0.5 + 0.5 * math.sin((lt - tf) * 10 + 1), face='open')
    # farmer foreground left
    human(d, 445, 1830, 1.15, 'farmer', face='wide', mouth='o', brow=1, armL=(175, 90), armR=(-175, 90), bob=abs(math.sin(lt * 9)) * 6 if lt > tb else 0)
SH[-1]['draw'] = s4_draw

# S5 phone 17.2-19.5
@shot(17.2, 19.5, 'house')
def s5(t, lt):
    return [(0, 540, 1230, 1.3, 0.02), (2.3, 540, 1210, 1.45, -0.02)], [17.45 - 17.2]
def phone(B, hL, hR):
    hx, hy = hR
    B.poly([(hx - 10, hy + 10), (hx + 10, hy + 10), (hx + 6, hy - 60), (hx - 6, hy - 60)], C('2a2a2a'), INK, 3)
    B.ell(hx, hy - 66, 22, 10, C('2a2a2a'), INK, 3)
def s5_draw(d, t, lt):
    d.poly([(560, 1500), (1000, 1500), (1000, 1700), (560, 1700)], C('7a5530'), INK, 6)
    # candlestick phone base on table
    d.poly([(820, 1500), (880, 1500), (870, 1380), (830, 1380)], C('2a2a2a'), INK, 4)
    d.ell(850, 1370, 40, 22, C('2a2a2a'), INK, 4)
    shout = 0.5 + 0.5 * math.sin(lt * 16)
    human(d, 420, 1750, 1.7, 'farmer', face='squint', mouth='grit' if shout > 0.5 else 'o', brow=-1,
          armL=(150, 85), armR=(-150, 85), prop=phone, bob=shout * 6, tilt=math.sin(lt * 8) * 0.05)
    for i in range(3):
        a = -0.9 + i * 0.35; r0 = 260 + (lt * 300 % 60)
        d.line([(420 + 160 + math.cos(a) * r0, 1050 + math.sin(a) * r0), (420 + 160 + math.cos(a) * (r0 + 70), 1050 + math.sin(a) * (r0 + 70))], C('e74c3c'), 10)
def hud_s5(img, t, lt):
    if lt > 0.25:
        hud_text(img, 'ARMY!!', 760, 600, 130, (231, 76, 60), pop(t, 17.45, 0.3) * (1 + 0.04 * math.sin(lt * 20)), 1, -0.12)
SH[-1]['draw'] = s5_draw; SH[-1]['hud'] = hud_s5

# S6 army lineup 19.5-24.4
@shot(19.5, 24.4, 'day')
def s6(t, lt):
    return [(0, 540, 1420, 1.2, 0.0), (2.0, 540, 1420, 1.22, 0.0), (4.9, 550, 1440, 1.3, 0.01)], [19.7 - 19.5, 20.35 - 19.5, 21.0 - 19.5]
TS = [19.7, 20.35, 21.0]
def s6_draw(d, t, lt):
    for i, ts in enumerate(TS):
        if t < ts: continue
        p = back((t - ts) / 0.3, 2.2)
        human(d, 290 + i * 250, 1700, 1.5 * p, 'soldier', face='happy' if t > 23.2 else 'open', mouth='grin', brow=-0.3,
              armL=(10, 70) if t < 23.2 else (170, 80), armR=(-10, 70), bob=math.sin(t * 4 + i) * 3, var=i)
    for i, ts in enumerate((21.55, 22.2)):
        if t < ts: continue
        p = back((t - ts) / 0.3, 2.2)
        lewis(d, 330 + i * 420, 1900, 1.3 * p, -0.05)
    if t > 23.0:
        p = back((t - 23.0) / 0.3, 2.0)
        for i in range(3): crate(d, 210 + i * 330, 2080, 0.9 * p)
def hud_s6(img, t, lt):
    labels = [(19.7, '3 SOLDIERS'), (21.55, '2 MACHINE GUNS'), (23.0, '10,000 BULLETS')]
    for i, (ts, l) in enumerate(labels):
        if t >= ts:
            hud_text(img, l, 540, 260 + i * 120, 82, (255, 214, 64) if i == 2 else (255, 255, 255), pop(t, ts, 0.3))
SH[-1]['draw'] = s6_draw; SH[-1]['hud'] = hud_s6

# S7 Easy right 24.4-25.75
@shot(24.4, 25.75, 'day')
def s7(t, lt):
    return [(0, 540, 1190, 2.0, 0.0), (1.35, 540, 1180, 2.15, 0.02)], []
def thumb(B, hL, hR):
    hx, hy = hL
    B.poly([(hx - 6, hy - 10), (hx + 6, hy - 10), (hx + 6, hy - 42), (hx - 6, hy - 42)], SKIN, INK, 3)
def s7_draw(d, t, lt):
    human(d, 540, 1600, 1.6, 'soldier', face='happy', mouth='grin', armL=(160, 80), armR=(-15, 70), prop=thumb,
          tilt=0.08 * math.sin(lt * 4), bob=math.sin(lt * 5) * 4)
    if lt > 0.5:
        u = clamp((lt - 0.5) / 0.4)
        for (sx, sy) in ((700, 900), (760, 990)):
            r = 40 * math.sin(u * math.pi)
            d.poly([(sx, sy - r), (sx + r * 0.3, sy - r * 0.3), (sx + r, sy), (sx + r * 0.3, sy + r * 0.3), (sx, sy + r), (sx - r * 0.3, sy + r * 0.3), (sx - r, sy), (sx - r * 0.3, sy - r * 0.3)], C('fff2a0'), INK, 3)
SH[-1]['draw'] = s7_draw; SH[-1]['blur'] = True

# S8 Wrong 25.75-27.5
@shot(25.75, 27.5, 'day')
def s8(t, lt):
    return [(0, 540, 1180, 2.15, 0.02), (0.15, 540, 1170, 2.35, -0.05, 'o'), (1.75, 540, 1165, 2.4, -0.05)], [25.9 - 25.75]
def s8_draw(d, t, lt):
    pk = back((lt - 0.2) / 0.35, 2.0) if lt > 0.2 else 0
    emu(d, 760, 1700 + (1 - pk) * 500, 1.6, -1, 0, 0, 0.0, face='half', look=(-4, 2), star=True)
    human(d, 540, 1600, 1.6, 'soldier', face='wide', mouth='frown', brow=1, armL=(20, 70), armR=(-20, 70), sweat=lt > 0.4,
          tilt=-0.05, look=(6, 0))
SH[-1]['draw'] = s8_draw; SH[-1]['blur'] = True
SH[-1]['desat'] = True

# S9 day one 27.5-31.9
@shot(27.5, 31.9, 'day')
def s9(t, lt):
    return [(0, 540, 1150, 1.05, 0.0), (2.6, 560, 1130, 1.12, 0.0), (2.9, 560, 1110, 1.0, 0.0, 'o'), (4.4, 560, 1110, 0.98, 0.01)], [30.45 - 27.5]
def s9_draw(d, t, lt):
    ts = 30.45 - 27.5
    r = rng(9)
    pts = [(r.uniform(150, 950), r.uniform(990, 1250), r.uniform(-1, 1)) for _ in range(28)]
    cur = []
    for i, (x, y, rd) in enumerate(pts):
        if lt < ts:
            cur.append((y, x, i, 0.0, 1 if i % 2 else -1, 0.0))
        else:
            u = (lt - ts)
            dirx = 1 if x > 550 + rd * 60 else -1
            dx = dirx * eout(min(1, u / 1.4)) * (600 + abs(rd) * 500) + dirx * max(0, u - 1.4) * 300
            dy = rd * 70 * min(1, u)
            cur.append((max(960, y + dy), x + dx, i, 1.0, dirx, u))
    cur.sort()
    for y, x, i, run, fl, u in cur:
        sc = 0.45 + (y - 980) / 900
        if run:
            trail(d, x, y, t, fl, sc, i)
            emu(d, x, y, sc, fl, 1.0, t * 16 + i, 0.8, face='wide')
        else:
            emu(d, x + math.sin(t * 2 + i) * 6, y, sc, fl, 0.15, t * 6 + i, 0.2, face='wide' if lt > 1.2 else 'open', look=(0, 3))
    dust(d, 550, 1150, lt, ts, 10, 60, 7)
    human(d, 170, 1900, 1.3, 'soldier', face='squint' if lt < ts else 'wide', mouth='smirk' if lt < ts else 'o', brow=-1 if lt < ts else 1,
          armL=(80, 75), armR=(60, 75), look=(0 if lt < ts else math.sin(lt * 10) * 8, 0), var=2)
    fire = (29.95 - 27.5 <= lt < 30.45 - 27.5) and int(lt * 20) % 2 == 0
    lewis(d, 430, 1720, 1.3, -0.12, fire=1.0 if fire else 0.0)
    if 29.95 - 27.5 <= lt < 31.5 - 27.5:
        for k in range(4):
            t0 = 29.95 - 27.5 + k * 0.12
            dust(d, 380 + k * 170, 1270 - (k % 2) * 40, lt, t0, 5, 34, 20 + k)
    human(d, 900, 1950, 1.2, 'soldier', face='open' if lt < ts else 'wide', mouth='smile' if lt < ts else 'o', flip=-1, armL=(30, 70), armR=(-30, 70),
          look=(0 if lt < ts else math.sin(lt * 11 + 1) * 8, 0), var=1)
    fg_wheat(d, t, 1990, seed=4, sc=2.1, h=300, density=0.9)
def hud_s9(img, t, lt):
    tag(img, 'DAY 1', t, 27.6, 31.85)
SH[-1]['draw'] = s9_draw; SH[-1]['hud'] = hud_s9

# S10 ambush 31.9-36.3
@shot(31.9, 36.3, 'gold')
def s10(t, lt):
    return [(0, 620, 1200, 1.12, 0.0), (4.4, 520, 1330, 1.38, 0.0)], []
def sandbags(d, x, y, n=5, rows=3, sc=1.0):
    for rw in range(rows):
        for i in range(n - (rw % 2)):
            bx = x + (i + (rw % 2) * 0.5) * 120 * sc; by = y - rw * 52 * sc
            d.poly([(bx - 58 * sc, by), (bx + 58 * sc, by), (bx + 62 * sc, by - 26 * sc), (bx + 52 * sc, by - 50 * sc), (bx - 52 * sc, by - 50 * sc), (bx - 62 * sc, by - 26 * sc)], C('cdb27e'), INK, 4)
            d.line([(bx - 40 * sc, by - 24 * sc), (bx + 40 * sc, by - 26 * sc)], C('a88c5a'), 3)
def brush(d, x, y, w, seed, sc=1.0, t=0):
    rr = rng(seed)
    for i in range(int(w / 26)):
        bx = x + i * 26 + rr.uniform(-8, 8); h = rr.uniform(70, 150) * sc; a = rr.uniform(-0.5, 0.5) + math.sin(t * 2 + i) * 0.04
        tx, ty = bx + math.sin(a) * h, y - math.cos(a) * h
        d.line([(bx, y), (tx, ty)], C('6b5a3e'), 4)
        for k in range(3):
            fx = bx + (tx - bx) * (0.4 + k * 0.25); fy = y + (ty - y) * (0.4 + k * 0.25)
            d.ell(fx + (k % 2 * 2 - 1) * 10, fy, 14 * sc, 6 * sc, C('8a8a4a') if k % 2 else C('77783e'), INK, 2, ang=a + (k % 2 * 2 - 1) * 0.8)
def s10_draw(d, t, lt):
    # dam / waterhole with muddy bank and reeds
    d.ell(700, 1215, 340, 86, C('8a6a44'), INK, 5)
    d.ell(700, 1205, 300, 66, C('4f93b6'), INK, 4)
    d.ell(680, 1196, 240, 44, C('72b4d4'), None, 0)
    for k in range(3):
        rr_ = 30 + ((lt * 40 + k * 40) % 120)
        d.ell(820, 1210, rr_, rr_ * 0.25, None, C('d8eef7'), 2)
    for (rx, ry) in ((380, 1210), (420, 1225), (1010, 1205), (1050, 1220)):
        for j in range(5):
            d.line([(rx + j * 8, ry), (rx + j * 8 + math.sin(t * 2 + j) * 6, ry - 70 - j % 2 * 20)], C('6f7a3a'), 4)
    # emus coming down to drink, single file from the right
    for i in range(12):
        x = 1250 + i * 150 - lt * 240
        spot = 760 + (i % 5) * 70
        y = 1150 + (i % 3) * 16
        drink = x < spot
        if drink: x = spot
        emu(d, x, y, 0.72, -1, 0 if drink else 0.55, t * 9 + i, 0.4, face='open', peck=0.75 + 0.15 * math.sin(t * 6 + i) if drink else 0)
    # hide: sandbags + dry brush, soldiers peeking, gun barrel out
    human(d, 340, 1710, 1.45, 'soldier', face='half', mouth='smirk', brow=-1, armL=(60, 70), armR=(40, 70), var=2)
    human(d, 590, 1730, 1.4, 'soldier', face='half', mouth='grin', brow=-1, armL=(60, 70), armR=(40, 70), var=1)
    lewis(d, 500, 1470, 1.3, -0.06)
    sandbags(d, 120, 1780, 6, 3, 1.0)
    brush(d, 40, 1610, 820, 3, 1.0, t)
    fg_wheat(d, t, 1880, seed=12, sc=2.0, h=260, density=1.1)
def hud_s10(img, t, lt):
    tag(img, 'DAY 3 · THE AMBUSH', t, 31.95, 36.25)
SH[-1]['draw'] = s10_draw; SH[-1]['hud'] = hud_s10

# S11 jam 36.3-38.8
@shot(36.3, 38.8, 'gold')
def s11(t, lt):
    return [(0, 520, 1480, 1.6, 0.0), (1.5, 530, 1470, 1.72, 0.01), (1.62, 540, 1460, 1.9, -0.04, 'o'), (2.5, 540, 1455, 1.95, -0.04)], [37.9 - 36.3]
def s11_draw(d, t, lt):
    tj = 37.9 - 36.3
    sm = clamp((lt - tj) / 0.5) if lt > tj else 0
    human(d, 400, 1820, 1.35, 'soldier', face='squint' if lt < tj else 'wide', mouth='grit' if lt < tj else 'o', brow=-1 if lt < tj else 1,
          armL=(85, 75), armR=(70, 75), soot=lt > tj + 0.1, bob=math.sin(lt * 40) * 3 if lt < tj else 0)
    lewis(d, 640, 1560, 1.25, -0.08, smoke=sm)
    sandbags(d, 180, 1880, 6, 3, 1.15)
    brush(d, 160, 1730, 300, 5, 1.0, t)
    brush(d, 820, 1730, 300, 6, 1.0, t)
    if lt > tj:
        u = lt - tj
        for i in range(6):
            emu(d, 1100 + u * 600 + i * 90, 1250 + (i % 2) * 30, 0.6, 1, 1, t * 16 + i, 0.8, face='open')
def hud_s11(img, t, lt):
    if t > 37.95:
        hud_text(img, '*CLICK*', 760, 700, 96, (255, 255, 255), pop(t, 37.95, 0.25), 1, 0.12)
    board(img, t, 38.3, 0, 1, 38.3, y=330)
SH[-1]['draw'] = s11_draw; SH[-1]['hud'] = hud_s11; SH[-1]['blur'] = True

# S12 truck bolt 38.8-41.8
@shot(38.8, 41.8, 'day')
def s12(t, lt):
    return [(0, 600, 1380, 1.12, 0.0), (3.0, 600, 1370, 1.2, 0.0)], [39.85 - 38.8, 41.1 - 38.8]
def wrench(B, hL, hR):
    hx, hy = hL
    B.poly([(hx - 6, hy), (hx + 6, hy), (hx + 6, hy - 60), (hx - 6, hy - 60)], C('9aa0a6'), INK, 3)
    B.ell(hx, hy - 66, 14, 10, C('9aa0a6'), INK, 3)
def s12_draw(d, t, lt):
    truck(d, 640, 1600, 1.2, 1)
    gp = clamp((lt - 0.3) / 0.6)
    lewis(d, 450, lerp(1150, 1440, smooth(gp)), 1.1, -0.06)
    fg_wheat(d, t, 1930, n=20, seed=8, sc=1.9, h=240)
    human(d, 275, 1780, 1.15, 'soldier', face='happy', mouth='grin', armL=(150 + 20 * math.sin(lt * 18), 80), armR=(-20, 70), prop=wrench)
    for k in (39.85, 41.1):
        if 0 < t - k < 0.35:
            u = (t - k) / 0.35
            for i in range(6):
                a = i * 1.05; r = 30 + u * 80
                d.line([(360 + math.cos(a) * r * 0.5, 1430 + math.sin(a) * r * 0.5), (360 + math.cos(a) * r, 1430 + math.sin(a) * r)], C('ffe066'), 7)
def hud_s12(img, t, lt):
    for k in (39.85, 41.1):
        if 0 < t - k < 0.5: hud_text(img, 'CLANG!', 760, 700 if k < 40 else 820, 90, (255, 214, 64), pop(t, k, 0.2), clamp((k + 0.5 - t) / 0.2), 0.15)
SH[-1]['draw'] = s12_draw; SH[-1]['hud'] = hud_s12

# S13 sprint 41.8-44.5 (camera tracks a running emu)
V13 = 950
@shot(41.8, 44.5, 'day')
def s13(t, lt):
    ex = 300 + V13 * lt
    return [(0, 380, 1300, 1.25, 0.0), (2.7, 400, 1290, 1.32, -0.02)], []
def s13_draw(d, t, lt):
    pass
SH[-1]['blur'] = True
def s13_cam(t, lt):
    keys, kicks = s13(t, lt)
    return keys, kicks, 300 + V13 * lt - 300
def s13_draw(d, t, lt):
    x = 300 + V13 * lt
    x2 = x - 380 + math.sin(lt * 2) * 40
    trail(d, x2, 1600, t, 1, 1.0, 2)
    emu(d, x2, 1600, 1.0, 1, 1.0, t * 26 + 2, 0.9, face='open')
    trail(d, x, 1700, t, 1, 1.6, 1)
    emu(d, x + math.sin(t * 3) * 20, 1700, 1.6, 1, 1.0, t * 26, 0.9, face='half', mouth=None, star=True)
    fg_wheat(d, t, 1880, x0=-400, x1=3800, seed=5, sc=2.0, h=280, wind=1.3, density=1.0)
def hud_s13(img, t, lt):
    if t < 42.35: return
    sc = pop(t, 42.35, 0.3)
    d = D(img, Aff(0, 0, S)).sub(Aff(540, 380, sc))
    d.ell(0, 0, 190, 190, C('2a1a2a'), C('ffd640'), 8)
    for i in range(9):
        a = math.pi * (0.8 + i * 0.175); d.line([(math.cos(a) * 150, math.sin(a) * 150), (math.cos(a) * 175, math.sin(a) * 175)], C('ffffff'), 6)
    u = eout((t - 42.35) / 0.8); a = math.pi * (0.8 + u * 1.15) + math.sin(t * 30) * 0.02
    d.line([(0, 0), (math.cos(a) * 140, math.sin(a) * 140)], C('e74c3c'), 10); d.dot(0, 0, 16, C('ffffff'))
    hud_text(img, '50 KM/H', 540, 380 + 250 * sc, 64, (255, 214, 64), sc)
SH[-1]['draw'] = s13_draw; SH[-1]['hud'] = hud_s13; SH[-1]['pan'] = lambda t, lt: V13 * lt; SH[-1]['blur'] = True

# S14 truck chase 44.5-48.9 (camera tracks the truck; emus overtake)
VT, VE = 600, 920
@shot(44.5, 48.9, 'day')
def s14(t, lt):
    return [(0, 560, 1360, 1.05, 0.0), (4.4, 620, 1340, 1.1, 0.0)], [44.62 - 44.5, 45.0 - 44.5]
def s14_draw(d, t, lt):
    tx = 420 + VT * lt
    bnc = abs(math.sin(lt * 9)) * 34
    tl = math.sin(lt * 7) * 0.05
    # emus in the far lane, start behind the truck and overtake
    tov = 46.74 - 44.5
    for i in range(5):
        x = 420 - 650 - i * 150 + VE * lt
        y = 1480 + (i % 2) * 36
        trail(d, x, y, t, 1, 0.8, i)
        emu(d, x, y, 0.85, 1, 1, t * 24 + i, 0.9, face='half' if lt > tov else 'open')
    B = truck(d, tx, 1720, 1.3, 1, wheel=-lt * 11 * 0 + lt * 11, bounce=bnc, tilt=tl)
    trail(d, tx - 330, 1720, t, 1, 1.4, 9)
    wob = math.sin(lt * 11) * 0.5
    human(B, -110, -100, 0.85, 'soldier', face='wide', mouth='o', brow=1, armL=(90 + math.degrees(wob) * 0.6, 75), armR=(70, 75), tilt=wob * 0.4, var=1)
    fire = (45.55 <= t < 46.6) and int(t * 20) % 2 == 0
    lewis(B, 40, -235, 0.95, wob * 0.8 - 0.1, fire=1.0 if fire else 0.0)
    if 45.55 <= t < 47.4:
        for k in range(5):
            t0 = 45.6 + k * 0.2
            px = tx + 300 + k * 140 + (k % 2) * 60; py = 1400 + (k % 3) * 60 - (k == 2) * 250
            dust(d, px, py, t, t0, 5, 30, 40 + k)
    fg_wheat(d, t, 2010, x0=-400, x1=4000, seed=6, sc=2.2, h=300, wind=1.4, density=0.9)
SH[-1]['draw'] = s14_draw; SH[-1]['pan'] = lambda t, lt: VT * lt

# S15 month later 48.9-53.05
@shot(48.9, 53.05, 'gold')
def s15(t, lt):
    return [(0, 540, 1400, 1.2, 0.0), (4.15, 540, 1380, 1.35, 0.01)], [51.9 - 48.9]
def s15_draw(d, t, lt):
    for i in range(4):
        crate(d, 130 + i * 230, 1820 - (i % 2) * 30, 0.9, empty=True, tilt=(-0.15 if i == 1 else 0.1 if i == 3 else 0))
    sh = math.sin(lt * 20) * 0.25 if lt > 1.5 else 0
    human(d, 560, 1640, 1.35, 'soldier', face='closed' if lt > 3.1 else 'half', mouth='frown', brow=1, armL=(172, 95), armR=(-172, 95), soot=True)
    L = d.sub(Aff(560, 930, 0.75, math.pi + sh))
    crate(L, 0, 0, 1.0, empty=True)
    if lt > 1.5:
        u = (lt - 1.5) % 0.6
        d.ell(560 + math.sin(lt * 20) * 20, 1060 + u * 300, 6, 10, C('d9a640'), INK, 2) if (lt < 2.2) else None
def hud_s15(img, t, lt):
    tag(img, '1 MONTH LATER', t, 48.95, 53.0)
    counter(img, t, 49.6, 51.9, 0, 9860, 'BULLETS USED', y=320, color=(231, 76, 60))
SH[-1]['draw'] = s15_draw; SH[-1]['hud'] = hud_s15

# S16 math 53.05-56.2
@shot(53.05, 56.2, 'blue')
def s16(t, lt):
    return [(0, 540, 1100, 1.0, 0.0), (3.15, 540, 1100, 1.1, 0.0)], [54.2 - 53.05]
def s16_draw(d, t, lt):
    bullets_row(d, 115, 1090, 10, 1.25, t, 53.6, 0.09)
    emu(d, 720, 1860, 1.5, -1, 0, 0, 0.0, star=True, face='half' if lt > 2.3 else 'open', mouth=None, wink=lt > 2.3, look=(-2, 0),
        bob=math.sin(lt * 4) * 4)
def hud_s16(img, t, lt):
    hud_text(img, '9,860 bullets', 540, 420, 90, (255, 255, 255), pop(t, 53.17, 0.3))
    if t > 53.6: hud_text(img, '÷ 986 birds', 540, 540, 90, (255, 255, 255), pop(t, 53.6, 0.3), font=FDJ)
    if t > 54.4:
        hud_text(img, '= 10 PER BIRD', 540, 700, 110, (255, 214, 64), pop(t, 54.4, 0.3) * (1 + 0.03 * math.sin(lt * 8)))
SH[-1]['draw'] = s16_draw; SH[-1]['hud'] = hud_s16

# S17 commander 56.2-61.1
@shot(56.2, 61.1, 'tent')
def s17(t, lt):
    return [(0, 520, 1350, 1.3, 0.0), (3.6, 540, 1250, 1.34, 0.0), (3.8, 560, 1150, 1.06, 0.02, 'o'), (4.9, 560, 1140, 1.04, 0.02)], [60.25 - 56.2]
def pen(B, hL, hR):
    hx, hy = hL
    B.line([(hx, hy), (hx + 20, hy - 50)], C('2a2a2a'), 6)
def s17_draw(d, t, lt):
    human(d, 330, 1720, 1.35, 'officer', face='half' if lt < 3.8 else 'wide', mouth='flat' if lt < 3.8 else 'o', brow=-1 if lt < 3.8 else 1,
          armL=(120 + 15 * math.sin(lt * 14), 80), armR=(60, 70), prop=pen, tilt=0.06)
    d.poly([(380, 1560), (1000, 1560), (1000, 1600), (380, 1600)], C('7a5230'), INK, 5)
    d.poly([(420, 1600), (460, 1600), (460, 1900), (420, 1900)], C('6a4528'), INK, 4); d.poly([(920, 1600), (960, 1600), (960, 1900), (920, 1900)], C('6a4528'), INK, 4)
    d.poly([(520, 1560), (760, 1560), (740, 1530), (540, 1530)], C('f6f0dc'), INK, 3)
    # thought bubble
    tb = 57.4 - 56.2
    if lt > tb:
        p = back((lt - tb) / 0.35, 1.8)
        B = d.sub(Aff(590, 860, 0.85 * p))
        B.ell(-250, 330, 20, 20, C('ffffff'), INK, 4); B.ell(-205, 268, 30, 30, C('ffffff'), INK, 4)
        circ = [(-200, -60, 130), (-60, -150, 140), (110, -140, 140), (230, -40, 120), (180, 110, 130), (0, 150, 140), (-170, 100, 120), (0, 0, 200)]
        for x_, y_, r_ in circ: B.ell(x_, y_, r_ + 6, r_ + 6, INK, None, 0)
        for x_, y_, r_ in circ: B.ell(x_, y_, r_, r_, C('ffffff'), None, 0)
        B.ell(-20, -10, 250, 190, C('f3f6f8'), None, 0)
        tk = lt > (60.2 - 56.2)
        if not tk:
            # emu shrugging off bullets
            emu(B, -40, 170, 0.62, 1, 0, 0, 0.0, face='half', shadow_on=False, bob=math.sin(lt * 5) * 3, star=True)
            for i in range(4):
                ph = (lt * 1.8 + i * 0.25) % 1.0
                bx = 280 - ph * 260; by = -40 + i * 40 - ph * 30
                if ph < 0.6:
                    B.poly([(bx, by - 6), (bx + 26, by - 6), (bx + 34, by), (bx + 26, by + 6), (bx, by + 6)], C('d9a640'), INK, 3)
                else:
                    q = (ph - 0.6) / 0.4
                    B.poly([(bx, by - 6 - q * 80), (bx + 26, by - 6 - q * 80), (bx + 34, by - q * 80), (bx + 26, by + 6 - q * 80), (bx, by + 6 - q * 80)], C('d9a640'), INK, 3)
                    for k in range(4):
                        aa = k * 1.57 + 0.6; B.line([(70 + math.cos(aa) * 12, by + math.sin(aa) * 12), (70 + math.cos(aa) * 30, by + math.sin(aa) * 30)], C('ffb020'), 4)
        else:
            u = back((lt - (60.2 - 56.2)) / 0.3, 2.0)
            T = B.sub(Aff(-10, 60, 0.9 * u))
            # tracks
            T.poly([(-230, 60), (230, 60), (260, 100), (230, 140), (-230, 140), (-260, 100)], C('2c2c2c'), INK, 5)
            for i in range(7): T.ell(-180 + i * 60, 100, 26, 26, C('6a6e66'), INK, 3); T.dot(-180 + i * 60, 100, 7, C('2c2c2c'))
            for i in range(14): T.line([(-240 + i * 35, 60), (-232 + i * 35, 66)], C('555555'), 3)
            # hull
            T.poly([(-220, 60), (220, 60), (250, 0), (-240, 0)], C('5b6b3c'), INK, 5)
            T.poly([(-200, 10), (210, 10), (226, 0), (-220, 0)], C('6d7f48'), None)
            for i in range(9): T.dot(-180 + i * 45, 42, 4, C('3e4a28'))
            # emu body as turret, cannon from chest
            T.poly([(60, -60), (270, -72), (270, -50), (60, -40)], C('4b5258'), INK, 4)
            emu(T, -30, 150, 0.85, 1, 0, 0, 0.0, face='half', shadow_on=False, star=True)
            T.poly([(-60, -440), (60, -440), (70, -410), (-70, -410)], C('5b6b3c'), INK, 4)
SH[-1]['draw'] = s17_draw
def hud_s17(img, t, lt):
    if t > 60.2:
        hud_text(img, 'EMU = TANK', 540, 260, 110, (255, 214, 64), pop(t, 60.2, 0.3))
SH[-1]['hud'] = hud_s17

# S18 packing up 61.1-64.85
@shot(61.1, 64.85, 'gold')
def s18(t, lt):
    return [(0, 540, 1300, 1.2, 0.0), (3.75, 500, 1280, 1.05, 0.0)], []
def s18_draw(d, t, lt):
    u = clamp((lt - 1.3) / 2.4)
    x = 600 - smooth(u) * 900
    B = truck(d, x, 1650, 1.25, -1, wheel=-lt * 8 * (u > 0), bounce=abs(math.sin(lt * 6)) * 6 * (u > 0))
    for i in range(3):
        human(B, -40 - i * 70, -100, 0.75, 'soldier', face='closed', mouth='frown', brow=1, armL=(20, 70), armR=(-20, 70), tilt=0.15 + 0.03 * math.sin(lt * 3 + i), flip=-1)
    if u > 0: trail(d, x + 330, 1650, t, -1, 1.3 * min(1, u * 4), 3)
    fg_wheat(d, t, 1960, n=20, seed=9, sc=1.9, h=240)
    # emus watching right
    for i in range(3):
        emu(d, 820 + i * 120, 1500 + i * 40, 0.85, -1, 0, 0, 0.1, face='half', look=(-3, 0), bob=math.sin(t * 3 + i) * 3)
SH[-1]['draw'] = s18_draw

# S19 victory 64.85-67.7
@shot(64.85, 67.7, 'day')
def s19(t, lt):
    return [(0, 540, 1200, 1.15, 0.0), (0.8, 540, 1200, 1.2, 0.0), (0.95, 540, 1180, 1.32, 0.03, 'o'), (2.85, 540, 1170, 1.36, 0.02)], [65.65 - 64.85]
def s19_draw(d, t, lt):
    r = rng(19)
    for i in range(9):
        x = 120 + i * 105 + r.uniform(-20, 20); y = 1500 + r.uniform(-80, 120)
        hop = abs(math.sin(t * 8 + i)) * 50 if lt > 0.8 else 0
        emu(d, x, y - hop, 0.8 + (y - 1400) / 1500, 1 if i % 2 else -1, 0.3 if hop else 0, t * 10 + i, -0.2, face='half', mouth='open' if lt > 0.8 else None, star=(i == 4))
    if lt > 0.8:
        rr = rng(int(t * 30))
        for i in range(30):
            rx = rng(i)
            x0 = rx.uniform(0, 1080); vy = rx.uniform(200, 500); ph = rx.uniform(0, 6)
            y = 500 + (lt - 0.8) * vy
            L = d.sub(Aff(x0 + math.sin(lt * 3 + ph) * 40, y, 1, lt * 2 + ph))
            L.ell(0, 0, 10, 26, C('6e5848') if i % 2 else C('8aa2b8'), INK, 2)
    fg_wheat(d, t, 1880, n=22, seed=7, sc=1.9, h=260)
def hud_s19(img, t, lt):
    board(img, t, 64.9, 0, 1, None, y=280)
    if t > 65.6:
        u = (t - 65.6) / 0.18
        sc = 2.4 - 1.4 * clamp(u) if u < 1 else 1.0 + 0.04 * math.exp(-(t - 65.78) * 8) * math.sin((t - 65.78) * 40)
        d = D(img, Aff(0, 0, S)).sub(Aff(540, 760, sc, -0.18))
        d.poly([(-420, -80), (420, -80), (420, 80), (-420, 80)], None, C('e23b3b'), 12)
        hud_text(img, 'VICTORY: EMUS', 540, 760, 80, (226, 59, 59), sc, 1, -0.18)
SH[-1]['draw'] = s19_draw; SH[-1]['hud'] = hud_s19

# S20 today, loop 67.7-71.7
@shot(67.7, 71.7, 'day')
def s20(t, lt):
    ex, ey = hero_eye()
    return [(0, 520, 1050, 1.0, 0.0), (1.4, 520, 1060, 1.12, 0.0), (2.7, 500, 1000, 1.6, 0.0), (3.85, ex + 4, ey + 2, 7.5, 0.05, 'i'), (4.1, ex + 4, ey + 2, 7.5, 0.05)], []
def s20_draw(d, t, lt):
    herd(d, t, 26, 11, -200, 1300, 930, 1180, speed=30, flip=-1, run=0.25, scale_base=0.7, neckf=0.2)
    for i, x in enumerate((-60, 1100)):
        emu(d, x, 1500, 1.4, 1 if i == 0 else -1, 0, 0, 0.1, bob=math.sin(t * 3 + i) * 4, face='open')
    tl = 69.9 - 67.7
    draw_hero(d, t, face='half' if tl < lt < 3.6 else 'open', look=(-3, 0) if tl < lt < 3.6 else (2, 0), tilt=0.12 if tl < lt < 3.5 else 0.0)
    fg_wheat(d, t, 1840, n=22, seed=2, sc=1.9, h=280)
SH[-1]['draw'] = s20_draw

# assign the fn as camera
for s_ in SH: s_['cam'] = s_['fn']

# ---------------- captions ----------------
TIM = json.load(open(os.path.join(os.path.dirname(__file__), 'work/timing.json')))
import re
def syl(w):
    w = re.sub(r'[^a-z]', '', w.lower())
    if not w: return 1
    n = len(re.findall(r'[aeiouy]+', w))
    if w.endswith('e') and n > 1 and not w.endswith('le'): n -= 1
    return max(1, n)
KEY = {'1932', 'war', 'birds', 'twenty', 'thousand', 'emus', 'army', 'three', 'two', 'ten', 'wrong', 'one', 'split', 'trap', 'jammed', 'truck',
       'fifty', 'bounced', 'month', 'gone', 'single', 'tanks', 'won', 'still', 'nineteen', 'thirty-two'}
CH = []
for a, b, txt in TIM:
    ws = txt.replace('...', '…').split()
    ss = [syl(w) for w in ws]; tot = sum(ss); tt = a
    wt = []
    for w, s_ in zip(ws, ss):
        d_ = (b - a) * s_ / tot; wt.append((tt, w)); tt += d_
    # chunks of 1-2 words, break after punctuation
    i = 0
    while i < len(wt):
        n = 1
        if i + 1 < len(wt) and not re.search(r'[,.?!…]$', wt[i][1]) and len(wt[i][1]) + len(wt[i + 1][1]) < 14: n = 2
        words = [w for _, w in wt[i:i + n]]
        CH.append([wt[i][0], ' '.join(words)])
        i += n
    CH[-1].append(b + 0.25)
for i in range(len(CH)):
    if len(CH[i]) == 2: CH[i].append(CH[i + 1][0])
    CH[i][2] = min(CH[i][2], CH[i + 1][0] if i + 1 < len(CH) else 99)

def pill(img, cx, cy, w, h, a=0.45):
    x0, y0, x1, y1 = int(cx - w / 2), int(cy - h / 2), int(cx + w / 2), int(cy + h / 2)
    x0, y0 = max(0, x0), max(0, y0); x1, y1 = min(OW, x1), min(OH, y1)
    if x0 >= x1 or y0 >= y1: return
    m = np.zeros((y1 - y0, x1 - x0), np.uint8)
    rr = int(h / 2)
    cv2.rectangle(m, (rr, 0), (x1 - x0 - rr, y1 - y0), 255, -1)
    cv2.circle(m, (rr, rr), rr, 255, -1); cv2.circle(m, (x1 - x0 - rr, rr), rr, 255, -1)
    m = (m.astype(np.float32) / 255 * a)[..., None]
    roi = img[y0:y1, x0:x1].astype(np.float32)
    img[y0:y1, x0:x1] = (roi * (1 - m) + np.array([40, 20, 30], np.float32) * m).astype(np.uint8)

def caption(img, t):
    for t0, txt, t1 in CH:
        if t0 - 0.03 <= t < t1:
            disp_ = txt.upper().replace('…', '...').rstrip(',.')
            spr = text_sprite(disp_, int(96 * S), (255, 255, 255), 0.14, None)
            pill(img, 540 * S, 1325 * S, spr.shape[1] * 1.22 + 50 * S, spr.shape[0] * 1.2 + 26 * S, 0.5)
            break
    for t0, txt, t1 in CH:
        if t0 - 0.03 <= t < t1:
            clean = re.sub(r'[^\w\-:]', '', txt.lower().split()[-1]) if txt else ''
            words = [re.sub(r'[^\w\-]', '', w.lower()) for w in txt.split()]
            key = any(w in KEY for w in words)
            disp = txt.upper().replace('…', '...').rstrip(',.')
            if disp.endswith('...'): pass
            if key:
                u = (t - t0) / 0.22
                sc = 0.6 + 0.6 * back(u, 2.6) if u < 1 else 1.2
                col = (255, 255, 255) if u < 0.4 else (255, 160, 40) if u < 0.7 else (255, 214, 64)
                hud_text(img, disp, 540, 1325, 96, col, sc)
            else:
                sc = 0.7 + 0.3 * back((t - t0) / 0.15, 2.0)
                hud_text(img, disp, 540, 1325, 96, (255, 255, 255), sc)
            return

FLASH = [(31.9, 6), (48.9, 6)]
FIELD = ('day', 'gold', 'dusk')
HZ = 900

def wind_waves(img, M, t):
    gh, gw = OH // 8 + 1, OW // 8 + 1
    ys, xs = np.mgrid[0:gh, 0:gw].astype(np.float32) * 8
    Mi = np.linalg.inv(M)
    wx = Mi[0, 0] * xs + Mi[0, 1] * ys + Mi[0, 2]
    wy = Mi[1, 0] * xs + Mi[1, 1] * ys + Mi[1, 2]
    g = 1 + (0.055 * np.sin(wx * 0.0045 + wy * 0.0016 - t * 2.1) + 0.03 * np.sin(wx * 0.011 - wy * 0.003 - t * 3.3))
    g = np.where(wy > HZ + 30, g, 1.0) * np.clip((wy - HZ - 30) / 120, 0, 1) + (1 - np.clip((wy - HZ - 30) / 120, 0, 1))
    g = cv2.resize(g.astype(np.float32), (OW, OH), interpolation=cv2.INTER_LINEAR)
    img[:] = np.clip(img.astype(np.float32) * g[..., None], 0, 255).astype(np.uint8)

def sky_life(d, t, kind):
    col = C('ffffff') if kind == 'day' else C('ffe9c8')
    for i, (bx, by, s_) in enumerate(((-600, 300, 1.0), (500, 200, 0.8), (1700, 420, 1.2), (2900, 260, 0.9), (3900, 380, 1.0))):
        x = (bx + t * 22 + 900) % 5600 - 900
        for j in range(5):
            d.ell(x + (j - 2) * 70 * s_, by + (0 if j % 2 else -26) * s_, 85 * s_, 48 * s_, col, None, 0)
    for i in range(4):
        x = (200 + i * 260 + t * 90) % 2400 - 400; y = 360 + i * 45 + math.sin(t * 1.3 + i) * 20
        f = math.sin(t * 14 + i * 2) * 10
        d.line([(x - 18, y - f), (x, y), (x + 18, y - f)], C('3a2f2a'), 4)

WHIP = [s_['t0'] for s_ in SH if s_['t0'] not in (0.0, 25.75, 31.9, 48.9)]
def whip(img, f):
    for b in WHIP:
        df = f - int(round(b * FPS))
        if -4 <= df <= 3:
            if df < 0: p = (df + 5) / 5.0; sh = -p * p * OW * 0.3
            else: p = (4 - df) / 4.0; sh = p * p * OW * 0.3
            M2 = np.float32([[1, 0, sh], [0, 1, 0]])
            out = cv2.warpAffine(img, M2, (OW, OH), borderMode=cv2.BORDER_REPLICATE)
            k = max(1, int(abs(sh) * 0.35)) | 1
            img[:] = cv2.blur(out, (k, 1))
            return


def render(f):
    t = f / FPS
    sh = next((s for s in SH if s['t0'] <= t < s['t1']), SH[-1])
    lt = t - sh['t0']
    keys, kicks = sh['cam'](t, lt)
    cx, cy, z, rot = cam_keys(keys, lt)
    if sh.get('pan'): cx += sh['pan'](t, lt)
    # creep
    cx += math.sin(t * 0.9) * 6; cy += math.cos(t * 0.7) * 5
    sx, sy = shake_at(lt, kicks)
    M = camM(cx, cy, z, rot, (sx, sy))
    img = np.zeros((OH, OW, 3), np.uint8)
    if sh['bg']:
        bg = bgimg(sh['bg'] + ('_blur' if sh.get('blur') else ''))
        ox, oy = BGOFF[sh['bg'] + ('_blur' if sh.get('blur') else '')]
        Mb = M @ np.array([[1 / S, 0, -ox], [0, 1 / S, -oy], [0, 0, 1]])
        cv2.warpAffine(bg, Mb[:2], (OW, OH), dst=img, flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    d = D(img, M)
    if sh['bg'] in FIELD:
        wind_waves(img, M, t)
        if not sh.get('blur'): sky_life(d, t, sh['bg'])
    sh['draw'](d, t, lt)
    if sh.get('desat'):
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        u = clamp((lt - 0.12) / 0.15)
        img[:] = cv2.addWeighted(img, 1 - 0.75 * u, cv2.cvtColor(g, cv2.COLOR_GRAY2BGR), 0.75 * u, 0)
    img[:] = (img.astype(np.float32) * vignette()).astype(np.uint8)
    if os.environ.get('NOTEXT'):
        return img
    if sh.get('hud'): sh['hud'](img, t, lt)
    whip(img, f)
    caption(img, t)
    for ft, n in FLASH:
        df = f - int(ft * FPS)
        if -3 <= df < n:
            a = 1 - abs(df) / (n if df >= 0 else 3)
            img[:] = cv2.addWeighted(img, 1 - a, np.full_like(img, 255), a, 0)
    return img

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'stills':
        out = sys.argv[2]; os.makedirs(out, exist_ok=True)
        for tt in sys.argv[3].split(','):
            f = int(float(tt) * FPS); cv2.imwrite(f'{out}/s_{float(tt):05.2f}.jpg', render(f))
    else:
        out = sys.argv[2]; a, b = map(int, sys.argv[3].split('-')); os.makedirs(out, exist_ok=True)
        for f in range(a, b + 1):
            cv2.imwrite(f'{out}/f{f:05d}.jpg', render(f), [cv2.IMWRITE_JPEG_QUALITY, 92])
