import numpy as np, wave, math, random
SR=44100; DUR=71.70; N=int(SR*DUR)
rnd=np.random.default_rng(7)
def tt(d): return np.arange(int(SR*d))/SR
def env(n,a=0.005,r=0.1):
    e=np.ones(n); na=max(1,int(a*SR)); nr=max(1,int(r*SR))
    e[:na]=np.linspace(0,1,na); e[-nr:]*=np.linspace(1,0,nr); return e
def lp(x,k):
    k=max(1,int(k)); return np.convolve(x,np.ones(k)/k,'same')
def place(buf,x,t,g=1.0,pan=0.0):
    i=int(t*SR); 
    if i>=len(buf): return
    x=x[:len(buf)-i]
    l=g*math.cos((pan+1)*math.pi/4); r=g*math.sin((pan+1)*math.pi/4)
    buf[i:i+len(x),0]+=x*l*1.41; buf[i:i+len(x),1]+=x*r*1.41
noise=lambda d: rnd.standard_normal(int(SR*d))
def whoosh(d=0.5,up=True):
    n=noise(d); t=tt(d); e=np.sin(np.pi*t/d)**2
    out=np.zeros_like(n); 
    for k,w in ((3,0.5),(9,0.3),(30,0.2)): out+=lp(n,k)*w
    return out*e*0.6
def riser(d=0.6):
    t=tt(d); return (lp(noise(d),4)*0.4+0.2*np.sin(2*np.pi*(300+900*t/d)*t))*(t/d)**2
def impact(d=0.9,f=55):
    t=tt(d); sub=np.sin(2*np.pi*(f*np.exp(-t*3))*t*2)*np.exp(-t*5)
    click=noise(d)*np.exp(-t*80)*0.6; crunch=lp(noise(d),3)*np.exp(-t*14)*0.4
    return sub+click+crunch
def pop(f=600):
    t=tt(0.12); return np.sin(2*np.pi*f*t*(1+3*np.exp(-t*40)))*np.exp(-t*35)
def boing():
    t=tt(0.5); return np.sin(2*np.pi*(180+120*np.sin(2*np.pi*9*t))*t)*np.exp(-t*6)*0.8
def ting(f=1800):
    t=tt(1.0); x=sum(np.sin(2*np.pi*f*m*t+ 2*np.sin(2*np.pi*f*1.4*t)*np.exp(-t*6))*a for m,a in ((1,1),(2.01,0.4),(3.03,0.2)))
    return x*np.exp(-t*5)*0.5
def tick(): t=tt(0.03); return np.sin(2*np.pi*2400*t)*np.exp(-t*200)*0.6
def thunk(): t=tt(0.25); return (np.sin(2*np.pi*110*t)*np.exp(-t*25)+lp(noise(0.25),6)*np.exp(-t*30)*0.6)
def clang():
    t=tt(0.9); x=sum(np.sin(2*np.pi*f*t)*a for f,a in ((523,1),(1187,.6),(1789,.5),(2650,.3)))
    return (x*np.exp(-t*6)*0.5+noise(0.9)*np.exp(-t*60)*0.5)
def crash():
    t=tt(1.0); x=lp(noise(1.0),2)*np.exp(-t*5)
    for k in range(6): 
        i=int(rnd.uniform(0,0.4)*SR); x[i:i+3000]+=thunk()[:3000][:len(x[i:i+3000])]*0.8
    return x
def chomp(): t=tt(0.15); return lp(noise(0.15),5)*np.exp(-t*30)*np.sin(np.pi*t/0.15)
def scratch():
    t=tt(0.6); f=600+500*np.sin(2*np.pi*3*t); return (np.sin(2*np.pi*np.cumsum(f)/SR)*0.3+lp(noise(0.6),2)*0.5)*np.exp(-t*3)
def click(): t=tt(0.08); return noise(0.08)*np.exp(-t*120)+np.sin(2*np.pi*3000*t)*np.exp(-t*90)*0.5
def puff(): t=tt(0.6); return lp(noise(0.6),20)*np.exp(-t*6)*1.5
def rumble(d):
    t=tt(d); x=lp(noise(d),60)*3; 
    steps=np.zeros_like(t)
    for k in np.arange(0,d-0.06,0.07): 
        i=int((k+rnd.uniform(0,0.03))*SR); steps[i:i+800]+=np.exp(-np.arange(800)/120)*rnd.uniform(0.3,1)
    return (x*0.6+lp(steps,8)*1.5)*np.minimum(1,np.minimum(t/0.3,(d-t)/0.4))
def engine(d,f=38):
    t=tt(d); x=np.sign(np.sin(2*np.pi*f*t+0.3*np.sin(2*np.pi*7*t)))*0.3; return lp(x,10)*np.minimum(1,np.minimum(t/0.2,(d-t)/0.5))
def strain(): t=tt(0.7); return lp(noise(0.7),3)*np.sin(np.pi*t/0.7)*0.4
def ring():
    t=tt(0.8); x=np.sin(2*np.pi*1100*t)*(0.5+0.5*np.sign(np.sin(2*np.pi*20*t))); return x*0.4*np.minimum(1,(0.8-t)*8)
def chalk(): t=tt(0.12); return lp(noise(0.12),2)*np.sin(np.pi*t/0.12)*0.5
def cheer(d=1.6):
    t=tt(d); x=np.zeros_like(t)
    for k in range(10):
        f=rnd.uniform(500,900); x+=np.sin(2*np.pi*f*t*(1+0.05*np.sin(2*np.pi*rnd.uniform(5,9)*t)))*rnd.uniform(.2,.5)
    return x*np.minimum(1,np.minimum(t/0.1,(d-t)/0.6))*0.25
def splash(): t=tt(0.4); return lp(noise(0.4),2)*np.exp(-t*10)*0.6

sfx=np.zeros((N,2))
P=place
P(sfx,whoosh(0.9),0.0,0.7); P(sfx,riser(0.5),2.05,0.6); P(sfx,impact(),2.55,1.0)
P(sfx,whoosh(0.4),3.75,0.6)
for i in range(4): P(sfx,chalk(),4.15+i*0.22,0.7,-0.3+i*0.2)
P(sfx,pop(500),5.77,0.9); P(sfx,boing(),5.8,0.6)
P(sfx,whoosh(0.4),7.35,0.6); P(sfx,rumble(5.3),7.4,0.7)
for k in np.arange(7.62,9.4,0.07): P(sfx,tick(),k,0.5)
P(sfx,crash(),13.12,1.0); P(sfx,whoosh(0.5),15.35,0.6)
for k in (16.0,16.3,16.6,16.9): P(sfx,chomp(),k,0.9)
P(sfx,ring(),17.2,0.5); P(sfx,thunk(),17.45,0.7)
for k in (19.7,20.35,21.0): P(sfx,pop(700),k,0.9)
for k in (21.55,22.2): P(sfx,clang()[:int(.4*SR)],k,0.6)
for k in np.arange(23.0,23.6,0.05): P(sfx,tick(),k,0.4)
P(sfx,ting(2200),24.9,0.8)
P(sfx,scratch(),25.85,1.0)
P(sfx,whoosh(0.3),27.45,0.5)
P(sfx,whoosh(0.6),30.4,0.9); P(sfx,rumble(1.4),30.45,0.8)
P(sfx,riser(0.5),31.4,0.6); P(sfx,whoosh(0.5),31.9,0.7)
P(sfx,splash(),33.5,0.3)
P(sfx,strain(),36.4,0.8); P(sfx,click(),37.9,1.0); P(sfx,click(),38.05,0.7); P(sfx,puff(),37.95,0.8)
P(sfx,thunk(),38.3,0.8)
P(sfx,clang(),39.85,0.8,-0.2); P(sfx,clang(),41.1,0.8,0.2)
P(sfx,whoosh(0.6),41.8,0.8); P(sfx,rumble(2.6),41.8,0.6); P(sfx,ting(1400),42.6,0.4)
P(sfx,engine(4.3),44.5,0.5)
for k in np.arange(44.62,48.5,0.349): P(sfx,boing(),k,0.45,rnd.uniform(-.3,.3))
P(sfx,riser(0.5),48.4,0.6); P(sfx,whoosh(0.5),48.9,0.7)
for k in np.arange(49.6,51.9,0.06): P(sfx,tick(),k,0.35)
for k in (53.17,53.6,54.4): P(sfx,pop(650),k,0.8)
for i in range(10): P(sfx,tick(),53.6+i*0.09,0.6)
P(sfx,ting(2000),55.4,0.6)
P(sfx,pop(400),57.4,0.7); P(sfx,riser(0.4),59.8,0.5); P(sfx,impact(0.7,45),60.2,0.9)
P(sfx,engine(2.6),62.3,0.6)
P(sfx,impact(0.6,70),65.25,0.5); P(sfx,impact(1.0,45),65.6,1.0); P(sfx,cheer(2.0),65.7,0.6)
P(sfx,ting(2600),69.9,0.6); P(sfx,whoosh(0.8),70.9,0.6)

def boom(n=2):
    t=tt(0.9); x=np.zeros_like(t)
    for k in range(n):
        i=int(k*0.22*SR); tk=t[:len(t)-i]
        x[i:]+=np.sin(2*np.pi*(70+20*np.exp(-tk*20))*tk)*np.exp(-tk*9)*(1-0.3*k)
    return lp(x,6)*1.4
def burst(d=0.5,rate=14):
    t=tt(d); x=np.zeros_like(t)
    for k in np.arange(0,d-0.05,1/rate):
        i=int(k*SR); s=tt(0.06); x[i:i+len(s)]+=(noise(0.06)*np.exp(-s*70)+np.sin(2*np.pi*120*s)*np.exp(-s*50))[:len(x[i:i+len(s)])]
    return x*0.8
def windbed(d):
    t=tt(d); n=lp(noise(d),40)*1.5; mod=0.6+0.4*np.sin(2*np.pi*0.15*t)
    return n*mod*np.minimum(1,np.minimum(t/1.0,(d-t)/1.0))*0.5
P(sfx,boom(2),0.25,0.8); P(sfx,boom(1),5.85,0.7); P(sfx,boom(2),55.3,0.6); P(sfx,boom(2),69.95,0.7); P(sfx,boom(3),65.9,0.5)
P(sfx,burst(0.5),29.95,0.7,-0.3)
for k in (45.55,46.0): P(sfx,burst(0.4),k,0.6,-0.2)
for k in range(4): P(sfx,lp(noise(0.2),4)*np.exp(-tt(0.2)*20)*0.6,29.95+k*0.12+0.05,0.4,0.3)
for k in range(5): P(sfx,lp(noise(0.2),4)*np.exp(-tt(0.2)*20)*0.6,45.6+k*0.2,0.4,0.3)
for a0,b0 in ((0.0,3.8),(7.4,17.2),(19.5,25.75),(27.5,36.3),(38.8,53.05),(61.1,71.7)):
    P(sfx,windbed(b0-a0),a0,0.35)
WH=[3.8,7.4,12.75,17.2,19.5,24.4,27.5,36.3,38.8,41.8,44.5,53.05,56.2,61.1,64.85,67.7]
for w in WH: P(sfx,whoosh(0.32),w-0.18,0.55)

# music: march 112 bpm
bpm=112; beat=60/bpm
mus=np.zeros((N,2))
def kick(): t=tt(0.25); return np.sin(2*np.pi*(50+90*np.exp(-t*30))*t)*np.exp(-t*12)
def snare(): t=tt(0.2); return (noise(0.2)*0.6+np.sin(2*np.pi*190*t)*0.4)*np.exp(-t*20)
def shaker(): t=tt(0.08); return lp(noise(0.08),1)*np.exp(-t*50)*0.3
def pluck(f,d=0.35):
    t=tt(d); return (np.sin(2*np.pi*f*t)+0.4*np.sin(2*np.pi*2*f*t)+0.2*np.sin(2*np.pi*3*f*t))*np.exp(-t*7)
def brass(f,d):
    t=tt(d); x=sum(np.sin(2*np.pi*f*m*t)/m**1.2 for m in range(1,6)); return lp(x,3)*np.minimum(1,np.minimum(t/0.05,(d-t)/0.15))*0.35
roots=[110,146.83,123.47,164.81]  # A D B E
mel=[440,494,523,494,440,392,440,0, 587,523,494,440,392,440,494,0]
def section(a,b,dense=1.0):
    k=0; t=a
    while t<b-0.01:
        bar=int((t-a)/(beat*4))%4; r=roots[bar]
        P(mus,kick(),t,0.9 if k%2==0 else 0.5)
        if k%2==1: P(mus,snare(),t,0.5)
        P(mus,shaker(),t+beat/2,0.6,0.3); P(mus,shaker(),t,0.4,-0.3)
        P(mus,pluck(r,0.3),t,0.7); 
        if k%4==2: P(mus,pluck(r*1.5,0.3),t,0.5)
        if dense>0.5:
            m=mel[k%16]
            if m: P(mus,pluck(m,0.25)*0.5,t,0.5,0.2); P(mus,pluck(m,0.25)*0.5,t+beat/2,0.3,-0.2)
        if k%8==0: P(mus,brass(r*2,beat*3.5),t,0.6)
        t+=beat; k+=1
section(0.0,25.85); section(27.5,64.8)
# drone after twist + soft ending
t=tt(DUR-64.85); dr=(np.sin(2*np.pi*55*t)+0.5*np.sin(2*np.pi*82.5*t))*np.minimum(1,t/0.5)*0.3
P(mus,dr,64.85,0.8)
section(67.7,71.7,0.0)
# stop music cleanly at 25.85 and 64.8: fade 30ms
for a,b in ((25.85,27.5),(64.8,64.85)):
    i=int(a*SR); mus[i:i+int(.03*SR)]*=np.linspace(1,0,int(.03*SR))[:,None]
    j=int(b*SR) if b>a+0.1 else int((a+0.03)*SR); 
    if b>a+0.1: mus[i+int(.03*SR):j]=0
# simple reverb: comb
def verb(x,dec=0.35,dl=(0.031,0.047,0.061,0.083)):
    y=x.copy()
    for d in dl:
        k=int(d*SR); z=np.zeros_like(x); z[k:]=x[:-k]*dec; y+=z
    return y
mus=verb(mus,0.25); sfx=verb(sfx,0.2)
def wr(fn,x):
    w=wave.open(fn,'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    x=x/ (np.abs(x).max()+1e-9)*0.9
    w.writeframes((x*32767).astype(np.int16).tobytes()); w.close()
wr('music.wav',mus); wr('sfx.wav',sfx)
print('ok')
