"""Face rig v2: expressive eyes/brows/lids + lip-sync mouths for rig.human(face_fn=...).

Use:  human(d, x, y, sc, 'napoleon', face_fn=Face(expr('proud'), viseme='A', open_=0.7))
Params (all optional, blended with expr()):
  look=(x,y) pupil offset (-1..1), lid=(L,R) upper-lid close 0..1, low=(L,R) lower-lid squint 0..1,
  brow=(L,R) raise -1..1, bang=(L,R) brow tilt (+ = angry, - = worried), pupil=0.6..1.4 size,
  smile=-1..1, sweat, blush, tears, shock (pupils tiny + lines), iris colour.
"""
import math, numpy as np
from rig import C, INK, shade, bez, lerp, clamp

BASE = dict(look=(0.0, 0.0), lid=(0.12, 0.12), low=(0.0, 0.0), brow=(0.0, 0.0), bang=(0.0, 0.0), pupil=1.0,
            smile=0.2, sweat=0.0, blush=0.25, tears=0.0, shock=0.0)
EXPR = {
    'neutral': {},
    'happy':   dict(lid=(0.2, 0.2), low=(0.35, 0.35), brow=(0.4, 0.4), smile=1.0, blush=0.6),
    'proud':   dict(lid=(0.42, 0.42), low=(0.1, 0.1), brow=(0.2, 0.55), bang=(0.15, -0.1), smile=0.65, look=(-0.2, 0.0)),
    'smug':    dict(lid=(0.5, 0.45), low=(0.2, 0.2), brow=(-0.1, 0.7), bang=(0.3, -0.2), smile=0.8, look=(0.35, 0.0)),
    'angry':   dict(lid=(0.3, 0.3), low=(0.25, 0.25), brow=(-0.6, -0.6), bang=(1.0, 1.0), smile=-0.7, blush=0.5),
    'worried': dict(lid=(0.1, 0.1), brow=(0.5, 0.5), bang=(-0.9, -0.9), smile=-0.5, sweat=0.7, look=(0.3, 0.15)),
    'scared':  dict(lid=(0.0, 0.0), brow=(0.9, 0.9), bang=(-0.8, -0.8), smile=-0.6, sweat=1.0, pupil=0.7),
    'shocked': dict(lid=(0.0, 0.0), brow=(1.0, 1.0), bang=(-0.2, -0.2), smile=-0.2, pupil=0.45, shock=1.0, sweat=0.6),
    'sad':     dict(lid=(0.35, 0.35), brow=(0.3, 0.3), bang=(-1.0, -1.0), smile=-0.8, look=(0.0, 0.4), tears=0.6),
    'deadpan': dict(lid=(0.55, 0.55), low=(0.05, 0.05), brow=(-0.15, -0.15), smile=0.0, blush=0.1),
    'excited': dict(lid=(0.0, 0.0), brow=(0.8, 0.8), smile=1.0, pupil=1.25, blush=0.7),
    'sly':     dict(lid=(0.45, 0.2), low=(0.3, 0.1), brow=(-0.3, 0.6), bang=(0.6, -0.2), smile=0.6, look=(0.5, 0.0)),
    'confused': dict(lid=(0.15, 0.3), brow=(0.8, -0.3), bang=(-0.4, 0.5), smile=-0.3, look=(0.0, -0.3)),
}
def expr(name, **over):
    p = dict(BASE); p.update(EXPR[name]); p.update(over); return p
def _l(a, b, u):
    if isinstance(a, tuple): return tuple(lerp(x, y, u) for x, y in zip(a, b))
    return lerp(a, b, u)
def blend(a, b, u):
    return {k: _l(a[k], b[k], u) for k in a}
def timeline(keys, t, ease=0.18):
    """keys: [(time, exprdict)], cross-fades over `ease` seconds at each key"""
    cur = keys[0][1]
    for i in range(1, len(keys)):
        tk, ex = keys[i]
        if t >= tk:
            u = clamp((t - tk) / ease); u = u * u * (3 - 2 * u)
            cur = blend(keys[i - 1][1] if i - 1 >= 0 else cur, ex, u) if u < 1 else ex
    return cur

IRIS = C('6b4a2e')
TEETH = (250, 250, 248); MOUTH = C('5a1f24'); TONGUE = C('e0727a'); LIP = C('c4605a')

class Face:
    def __init__(s, P=None, viseme='rest', open_=0.0, blink=False, iris=IRIS):
        s.P = P or dict(BASE); s.v = viseme; s.o = open_; s.blink = blink; s.iris = iris
    def __call__(s, Hh, sk, o):
        draw_face(Hh, sk, s.P, s.v, s.o, s.blink, s.iris)

def eye(Hh, cx, cy, side, P, sk, blink, iris):
    lx, ly = P['look']
    li = 1.0 if blink else P['lid'][0 if side < 0 else 1]
    lo = P['low'][0 if side < 0 else 1]
    rx, ry = 15, 18
    # sclera
    Hh.ell(cx, cy, rx, ry, (252, 250, 247), INK, 3.5)
    # iris + pupil
    ix, iy = cx + lx * 6, cy + ly * 6 + 1
    ps = P['pupil']
    if P['shock'] > 0.5:
        Hh.ell(ix, iy, 3.2, 3.6, C('201418'), None, 0)
    else:
        Hh.ell(ix, iy, 9.5 * min(1.2, ps + 0.1), 11 * min(1.2, ps + 0.1), iris, None, 0)
        Hh.ell(ix, iy + 1, 5.8 * ps, 6.6 * ps, C('1c1216'), None, 0)
        Hh.dot(ix + 3.5, iy - 4.5, 3.2, (255, 255, 255))
        Hh.dot(ix - 3, iy + 4, 1.5, (255, 255, 255))
    # upper lid (skin) closing down
    ytop = cy - ry - 2; ylid = lerp(cy - ry, cy + ry, li)
    if li > 0.02:
        pts = [(cx - rx - 2, ytop)] + [(cx + k * (rx + 2), ylid + (1 - k * k) * 4 * (1 - li)) for k in np.linspace(-1, 1, 9)] + [(cx + rx + 2, ytop)]
        Hh.poly(pts, shade(sk, 0.96), None)
    # lash line
    lash = [(cx + k * (rx + 1), ylid + (1 - k * k) * 4 * (1 - li) - (0 if li > 0.02 else 1.5)) for k in np.linspace(-1, 1, 9)]
    if li < 0.02:
        lash = [(cx + k * (rx + 1), cy - ry * math.sqrt(max(0, 1 - k * k)) - 0.5) for k in np.linspace(-1, 1, 11)]
    Hh.line(lash, INK, 4.5 if li < 0.95 else 4)
    Hh.line([lash[-1 if side > 0 else 0], (cx + side * (rx + 6), lash[-1 if side > 0 else 0][1] - 4)], INK, 3)
    # lower lid squint
    if lo > 0.02:
        yl = lerp(cy + ry + 2, cy + 2, lo)
        pts = [(cx - rx - 2, cy + ry + 3)] + [(cx + k * (rx + 2), yl - (1 - k * k) * 3) for k in np.linspace(-1, 1, 9)] + [(cx + rx + 2, cy + ry + 3)]
        Hh.poly(pts, sk, None)
        Hh.line([(cx + k * (rx + 1), yl - (1 - k * k) * 3) for k in np.linspace(-0.8, 0.8, 7)], shade(sk, 0.7), 2.5)

def brow(Hh, cx, cy, side, P, col):
    r = P['brow'][0 if side < 0 else 1]; a = P['bang'][0 if side < 0 else 1]
    by = cy - 31 - r * 8
    inner = (cx - side * 13, by + a * 7); outer = (cx + side * 14, by - a * 4 - 2)
    mid = ((inner[0] + outer[0]) / 2, (inner[1] + outer[1]) / 2 - 4 + abs(a) * 2)
    top = list(bez(inner, mid, outer, 8)); bot = [(x, y + 6 - 3 * k / 7) for k, (x, y) in enumerate(bez(inner, mid, outer, 8))]
    Hh.poly(top + bot[::-1], col, INK, 2)

def mouth(Hh, mx, my, v, o, smile, sk):
    sm = smile * 6
    w = 18 + 5 * max(0, smile)
    def corners(): return (mx - w, my - sm), (mx + w, my - sm)
    L_, R_ = corners()
    if v in ('rest',) or o < 0.08:
        Hh.line(bez(L_, (mx, my + 4 + sm * 0.8), R_, 10), INK, 4)
        if smile > 0.5:
            for c_ in (L_, R_): Hh.line([c_, (c_[0] + (3 if c_[0] > mx else -3), c_[1] - 4)], INK, 3)
        return
    if v == 'MBP':
        Hh.poly(list(bez((mx - w * 0.8, my), (mx, my - 4), (mx + w * 0.8, my), 8)) + list(bez((mx + w * 0.8, my), (mx, my + 6), (mx - w * 0.8, my), 8)), LIP, INK, 3)
        return
    if v == 'FV':
        Hh.poly(list(bez(L_, (mx, my - 5), R_, 8)) + list(bez(R_, (mx, my + 9), L_, 8)), MOUTH, INK, 3.5)
        Hh.poly([(mx - w * 0.7, my - 3), (mx + w * 0.7, my - 3), (mx + w * 0.6, my + 4), (mx - w * 0.6, my + 4)], TEETH, None)
        Hh.line(bez((mx - w * 0.75, my + 6), (mx, my + 10), (mx + w * 0.75, my + 6), 8), LIP, 4)
        return
    if v in ('U', 'small') and o < 0.6 or v == 'U':
        rw = 8 + (4 if v == 'small' else 0); rh = 4 + 8 * o
        Hh.ell(mx, my + 3, rw, rh, MOUTH, INK, 3.5)
        if v == 'U': Hh.ell(mx, my + 3, rw + 4, rh + 4, None, LIP, 3)
        return
    if v == 'O':
        rw = 11 + 3 * o; rh = 10 + 14 * o
        Hh.ell(mx, my + 6, rw, rh, MOUTH, INK, 4)
        Hh.ell(mx, my + 6 + rh * 0.55, rw * 0.6, rh * 0.32, TONGUE, None, 0)
        return
    if v == 'E':
        h = 6 + 10 * o
        top = list(bez(L_, (mx, my - 4), R_, 10)); bot = list(bez(R_, (mx, my + h), L_, 10))
        Hh.poly(top + bot, MOUTH, INK, 4)
        Hh.poly(top + [(R_[0] - 3, R_[1] + 3), (mx, my + 1), (L_[0] + 3, L_[1] + 3)], TEETH, None)
        if h > 9: Hh.poly(list(bez((mx - w * 0.6, my + h * 0.75), (mx, my + h * 0.55), (mx + w * 0.6, my + h * 0.75), 6)) + [(mx, my + h * 0.95)], TEETH, None)
        Hh.line(top, INK, 4)
        return
    # 'A' (and loud small): big open jaw
    h = 10 + 26 * o
    top = list(bez(L_, (mx, my - 6 - 2 * o), R_, 10)); bot = list(bez(R_, (mx, my + h), L_, 12))
    Hh.poly(top + bot, MOUTH, INK, 4.5)
    Hh.poly(top + [(R_[0] - 4, R_[1] + 4), (mx, my - 1), (L_[0] + 4, L_[1] + 4)], TEETH, None)
    Hh.ell(mx, my + h * 0.72, w * 0.55, h * 0.25, TONGUE, None, 0)
    Hh.poly(top + bot, None, INK, 4.5)

def draw_face(Hh, sk, P, v='rest', o=0.0, blink=False, iris=IRIS):
    bc = C('4a3022')
    if P.get('blush', 0) > 0.05:
        for sd in (-1, 1): Hh.ell(sd * 36, 27, 11, 6, shade(C('f09a90'), 1.0), None, 0)
    for side in (-1, 1):
        eye(Hh, side * 22, 3, side, P, sk, blink, iris)
        brow(Hh, side * 22, 5, side, P, bc)
    # nose
    Hh.ell(1, 22, 6.5, 5, shade(sk, 0.84), None, 0)
    Hh.line(bez((-4, 23), (1, 27), (6, 23), 6), C('b97c62'), 2.6)
    M_ = Hh.sub(np.array([[1.18, 0, 0], [0, 1.18, 40 - 40 * 1.18], [0, 0, 1]], float)); mouth(M_, 0, 40, v, o, P['smile'], sk)
    if P['sweat'] > 0.3:
        Hh.poly([(64, -26), (73, -6), (64, 0), (56, -6)], C('9fd8ff'), INK, 3)
        if P['sweat'] > 0.8: Hh.poly([(-62, -16), (-55, 0), (-62, 5), (-69, 0)], C('9fd8ff'), INK, 3)
    if P['tears'] > 0.3:
        for sd in (-1, 1): Hh.poly([(sd * 30, 12), (sd * 34, 26), (sd * 30, 32), (sd * 26, 26)], C('9fd8ff'), INK, 2.5)
    if P['shock'] > 0.5:
        for k in range(3):
            a = -2.3 + k * 0.35
            Hh.line([(math.cos(a) * 80, math.sin(a) * 80 - 20), (math.cos(a) * 100, math.sin(a) * 100 - 20)], INK, 4)
