"""v3 demo: first 10 s of the Napoleon story in the premium toon style.
Fast cuts (~1.1 s), macro prop shots, 2.5D realistic sets with DOF, original egg-head toons,
acting without lip sync, one-word captions."""
import numpy as np, cv2, math, json, sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from props import rabbit, raft, pavilion, carrot
from rig import *
from char3 import toon, hat3, track, OL
from face import expr, timeline
import look as LK
from set25d import Cam, plane, board, floor_shadow, tex_wood_floor, tex_plaster, tex_parchment, fbm, ramp, dof_blur

W, H, FPS = 1080, 1920, 30
S = float(os.environ.get('S', '0.3333333'))
OW, OH = int(round(W * S)), int(round(H * S))
HERE = os.path.dirname(os.path.abspath(__file__))
DUR = 10.0

TX = {}
def T():
    if not TX:
        TX['wood'] = tex_wood_floor(1024, 2048, 128)
        TX['table'] = tex_wood_floor(1024, 1024, 200, 11, (C('3a2414'), C('5a3a22'), C('7a5030'), C('8f6038')))
        TX['plaster'] = tex_plaster(2048, 1600, C('cdb08a'))
        TX['parch'] = tex_parchment(700, 960)
        n = fbm(1024, 1024, 21, 5, 6)
        TX['grass'] = cv2.GaussianBlur(ramp(0.5 + 0.35 * n, [C('1f3a14'), C('3e6a26'), C('6f9a3a'), C('a8c866')]).astype(np.uint8), (9, 9), 0)
        w = fbm(1024, 2048, 33, 5, 4)
        TX['water'] = ramp(0.5 + 0.3 * w, [C('163a52'), C('2a6a8a'), C('5aa0c0'), C('bfe6f2')]).astype(np.uint8)
        ceil = np.zeros((512, 512, 3), np.uint8); ceil[:] = C('2a1c14'); TX['ceil'] = ceil
    return TX

# ---------------- sets ----------------
HL, HR, HC, HZ = -900, 900, -1500, 2600
WINX = (-420, 420)
def hall(img, cam, t):
    X = T()
    plane(img, cam, X['ceil'], (HL, HC, 0), (HR - HL, 0, 0), (0, 0, HZ))
    plane(img, cam, X['plaster'], (HL, HC, HZ), (HR - HL, 0, 0), (0, -HC, 0))
    plane(img, cam, X['plaster'], (HL, HC, HZ), (0, 0, -HZ), (0, -HC, 0))
    plane(img, cam, X['plaster'], (HR, HC, 0), (0, 0, HZ), (0, -HC, 0))
    plane(img, cam, X['wood'], (HL, 0, 0), (HR - HL, 0, 0), (0, 0, HZ))
    for wx in WINX:                                  # tall glowing windows on the back wall
        Bd = board(img, cam, wx, -300, HZ - 2)
        Bd.poly([(-150, 0), (150, 0), (150, -900), (0, -1040), (-150, -900)], C('fff1cc'), C('5a3a22'), 22)
        Bd.line([(0, 0), (0, -1000)], C('5a3a22'), 14); Bd.line([(-150, -450), (150, -450)], C('5a3a22'), 14)
        for sd in (-1, 1):
            Bd.poly([(sd * 150, -980), (sd * 270, -980), (sd * 240, 20), (sd * 160, 20)], C('8a1a24'), INK, 8)
    for sx in (-760, 760):                           # wall sconces (candle glow)
        for z in (900, 1800):
            if z - cam.z < 80: continue
            Bd = board(img, cam, sx, -760, z)
            Bd.poly([(-20, 0), (20, 0), (14, 60), (-14, 60)], C('c99a30'), INK, 5)
            Bd.ell(0, -16, 9, 16, C('ffe08a'), None, 0)

def hall_glow(img, cam, t):
    for wx in WINX:
        p, dz = cam.proj([(wx, -800, HZ)])
        if dz[0] > 60: LK.god_rays(img, p[0][0], p[0][1], t, 0.2, (120, 200, 255), 7, 0.55, math.pi / 2 + (0.25 if wx < 0 else -0.05), 1.1, abs(int(wx)))
    for sx in (-760, 760):
        for z in (900, 1800):
            p, dz = cam.proj([(sx, -776, z)])
            if dz[0] > 60: LK.sun_glow(img, p[0][0], p[0][1], 9000 / dz[0] * S * 3, (90, 180, 255), 0.55)

# ---------------- shots ----------------
SH = []
def shot(t0, t1, **kw):
    def deco(fn): SH.append(dict(t0=t0, t1=t1, fn=fn, **kw)); return fn
    return deco

def camlerp(lt, d, a, b, ease=smooth):
    u = ease(clamp(lt / d)); return tuple(lerp(x, y, u) for x, y in zip(a, b))

# S1 macro: the bicorne on the map table, candle light, slow push + rack focus
@shot(0.0, 1.25, mb=False)
def s1(img, t, lt):
    x, y, z = camlerp(lt, 1.25, (40, -150, -150), (0, -135, 40))
    cam = Cam(x, y - 120, z + 140, 1100, S, 0, 0, -330, 0.22)
    X = T()
    plane(img, cam, X['plaster'], (-1200, -1600, 1400), (2400, 0, 0), (0, 1600, 0))
    plane(img, cam, X['table'], (-900, 0, 0), (1800, 0, 0), (0, 0, 1400))
    dof_blur(img, 22 * S * 3)
    floor_shadow(img, cam, 0, 520, 150, 40, 30, 10, 0.45)
    Bd = board(img, cam, 0, 0, 520).sub(Aff(0, 92, 1.05))
    hat3(Bd, 'bicorne', {'trim': C('f4f1ea')})
    p, dz = cam.proj([(-420, -420, 1200)]); LK.sun_glow(img, p[0][0], p[0][1], 40 * S * 3, (90, 190, 255), 0.6)
    return cam

# S2 hero: Napoleon in the palace hall, low angle, proud
POSE_PROUD = dict(aL=(45, 120), elL=30, aR=(-150, 110), elR=-120, lean=-0.06, tilt=-0.05)
@shot(1.25, 2.30)
def s2(img, t, lt):
    x, y, z = camlerp(lt, 1.05, (-60, -170, 700), (-20, -185, 820))
    cam = Cam(x, y, z, 1150, S, 0.02)
    hall(img, cam, t); dof_blur(img, 14 * S * 3)
    floor_shadow(img, cam, 0, 1250, 110, 40, 0, -120, 0.5)
    P = timeline([(0, expr('proud')), (0.6, expr('smug', look=(-0.3, 0)))], lt)
    toon(board(img, cam, 0, 0, 1250), 0, 0, 1.0, 'napoleon', P, dict(aL=(lerp(25, 160, smooth(clamp((lt - 0.45) / 0.15))), 120), elL=-40, aR=(54, 70), elR=80, lean=-0.05, tilt=-0.05),
         blink=0.7 < lt < 0.8, shadow_on=False)
    hall_glow(img, cam, t)
    return cam

# S3 macro: map of Europe turning blue (abstract shapes, our own design)
BLOBS = [(0.32, 0.38, 0.13), (0.55, 0.34, 0.12), (0.45, 0.55, 0.14), (0.7, 0.55, 0.1), (0.25, 0.62, 0.09), (0.62, 0.74, 0.08)]
@shot(2.30, 2.92)
def s3(img, t, lt):
    cam = Cam(0, -620, -80 + lt * 110, 1150, S, -0.04, 0, 0, 0.62)
    X = T()
    plane(img, cam, X['plaster'], (-2400, -2600, 1300), (4800, 0, 0), (0, 2600, 0))
    plane(img, cam, X['table'], (-900, 0, 0), (1800, 0, 0), (0, 0, 1400))
    par = X['parch'].copy(); h, w = par.shape[:2]
    blue = np.zeros((h, w), np.uint8); land = np.zeros((h, w), np.uint8)
    for i, (bx, by, br) in enumerate(BLOBS):
        pts = [(bx * w + math.cos(a) * br * w * (1 + 0.25 * math.sin(a * 5 + i)), by * h + math.sin(a) * br * w * 0.8 * (1 + 0.2 * math.cos(a * 3 + i))) for a in np.linspace(0, 6.28, 40)]
        cv2.fillPoly(land, [np.int32(pts)], 255)
    r = (lt / 0.55) * w * 0.75
    cv2.circle(blue, (int(w * 0.38), int(h * 0.5)), int(r), 255, -1)
    m = (cv2.bitwise_and(land, blue).astype(np.float32) / 255)[..., None]
    par = (par * (1 - 0.55 * m) + np.array(C('2b4aa8'), np.float32) * 0.55 * m).astype(np.uint8)
    cnt, _ = cv2.findContours(land, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE); cv2.drawContours(par, cnt, -1, C('3a2414'), 4)
    plane(img, cam, par, (-300, 0, 200), (600, 0, 0), (0, 0, 820))
    hud = text_sprite('EUROPE', int(64 * S), (60, 36, 20), 0.0)
    q, _ = cam.proj([(0, 0, 640)]); blit(img, hud, q[0][0], q[0][1] - 140 * S, 1.0, 0.8)
    return cam

# S4 close-up: smug -> worried
@shot(2.92, 4.25)
def s4(img, t, lt):
    x, y, z = camlerp(lt, 1.33, (10, -330, 900), (0, -330, 960))
    cam = Cam(x, y, z, 1150, S)
    hall(img, cam, t); dof_blur(img, 30 * S * 3)
    P = timeline([(0, expr('smug', look=(0.3, 0))), (0.75, expr('worried', look=(0.7, 0.2))), (1.05, expr('worried', look=(0, 0)))], lt, 0.12)
    pose = track([(0, dict(aL=(54, 70), elL=80, aR=(-25, 120), tilt=0.0)), (0.75, dict(aL=(150, 110), elL=-90, aR=(-25, 120), tilt=0.12))], lt)
    toon(board(img, cam, 0, 0, 1250), 0, 0, 1.0, 'napoleon', P, pose, blink=1.0 < lt < 1.08, shadow_on=False)
    hall_glow(img, cam, t)
    return cam

# S5 macro: a single bunny in the grass, nose twitch, ears perk
@shot(4.25, 4.80)
def s5(img, t, lt):
    cam = Cam(0, -120, 0, 1150, S)
    X = T()
    plane(img, cam, X['grass'], (-2000, -2200, 2400), (4000, 0, 0), (0, 2400, 0))
    plane(img, cam, X['grass'], (-1500, 0, 0), (3000, 0, 0), (0, 0, 2400))
    dof_blur(img, 40 * S * 3)
    rabbit(board(img, cam, 0, 40, 520), 0, 0, 1.45, 1, 0, 'front', face='open', ear=lerp(0.2, 1.0, smooth(clamp((lt - 0.25) / 0.1))))
    def fg():
        Bd = board(img, cam, 0, 0, 260)
        r = np.random.default_rng(4)
        for i in range(26):
            gx = r.uniform(-500, 500); hh = r.uniform(120, 260); sw = math.sin(t * 2 + i) * 10
            Bd.poly([(gx - 8, 0), (gx + 8, 0), (gx + sw, -hh)], C('3e6a26') if i % 2 else C('5a8a30'), None)
    LK.dof_layer(img, fg, 26 * S * 3)
    return cam

# S6 the reveal: bunny hops in, Napoleon snaps into shock (motion blur + shake)
@shot(4.80, 5.95, mb=True)
def s6(img, t, lt):
    sh = 16 * max(0, 1 - lt / 0.3)
    cam = Cam(40, -260, 380, 1150, S, -0.03, sh * math.sin(t * 90) * S * 3, sh * math.cos(t * 70) * S * 3)
    hall(img, cam, t); dof_blur(img, 16 * S * 3)
    floor_shadow(img, cam, 0, 1250, 110, 40, 0, -120, 0.5)
    shock = lt > 0.08
    P = expr('shocked', look=(0.5, 0.9)) if shock else expr('worried')
    pose = track([(0, dict(aL=(150, 110), elL=-90, aR=(-25, 120), squash=0.0, bob=0)),
                  (0.08, dict(aL=(170, 120), elL=-20, aR=(-170, 120), elR=20, squash=-0.08, bob=26)),
                  (0.5, dict(aL=(165, 120), elL=-30, aR=(-165, 120), elR=30, squash=0.0, bob=10))], lt, 0.1)
    toon(board(img, cam, 0, 0, 1250), 0, 0, 1.0, 'napoleon', P, pose, shadow_on=False)
    u = clamp(lt / 0.45)
    rx = lerp(520, 170, smooth(u)); rz = lerp(980, 1060, u)
    floor_shadow(img, cam, rx, rz, 60, 24, 0, 0, 0.5)
    rabbit(board(img, cam, rx, 0, rz), 0, 0, 0.85, -1, 0, 'hop' if u < 1 else 'sit', hop=u * 1.98 % 1.0, face='happy', ear=1.0, shadow_on=False)
    hall_glow(img, cam, t)
    return cam

# S7 deadpan close-up
@shot(5.95, 6.64)
def s7(img, t, lt):
    cam = Cam(0, -335, 1000 + lt * 30, 1150, S)
    hall(img, cam, t); dof_blur(img, 30 * S * 3)
    toon(board(img, cam, 0, 0, 1250), 0, 0, 1.0, 'napoleon', expr('deadpan', sweat=1.0), dict(aL=(25, 120), aR=(-25, 120)), shadow_on=False)
    hall_glow(img, cam, t)
    return cam

# S8 Tilsit: the raft on the river
@shot(6.64, 7.90)
def s8(img, t, lt):
    x, y, z = camlerp(lt, 1.26, (-90, -300, 650), (-30, -290, 820))
    cam = Cam(x, y, z, 1150, S)
    X = T()
    sky = np.zeros((OH, OW, 3), np.uint8)
    for yy in range(OH): sky[yy] = [int(lerp(a, b, yy / OH)) for a, b in zip(C('7cb8e8'), C('fde3b8'))]
    img[:] = sky
    wt = np.roll(X['water'], int(t * 40), axis=0)
    plane(img, cam, wt, (-6000, 0, 0), (12000, 0, 0), (0, 0, 9000))
    Bs = board(img, cam, 0, 0, 8900)
    Bs.poly([(-9000, 0), (9000, 0), (9000, -260), (-9000, -200)], C('7f9a6a'), None)
    for k in range(-14, 15):
        Bs.poly([(k * 520 - 90, -200), (k * 520 + 90, -200), (k * 520, -360)], C('f2ece0'), None)
    dof_blur(img, 8 * S * 3)
    bob = math.sin(t * 1.6) * 6
    raft(board(img, cam, 0, bob, 1500), 0, 0, 1.2, t)
    pavilion(board(img, cam, 0, bob - 10, 1560), 0, 0, 0.8, t)
    reach = smooth(clamp((lt - 0.4) / 0.25))
    toon(board(img, cam, -170, bob - 6, 1480), 0, 0, 0.85, 'napoleon', expr('proud'), dict(aL=(lerp(25, 95, reach), 120), aR=(54, 70), elR=80), shadow_on=False)
    toon(board(img, cam, 170, bob - 6, 1480), 0, 0, 0.85, 'tsar', expr('happy'), dict(aR=(lerp(-25, -95, reach), 120), aL=(25, 120)), shadow_on=False)
    LK.god_rays(img, OW * 0.85, OH * 0.12, t, 0.16, (130, 205, 255), 9, 1.0, 2.2, 1.6, 4)
    return cam

# S9 macro: quill signs the treaty
SIG = [(-150 + i * 9, math.sin(i * 0.55) * 26 + math.sin(i * 0.17) * 18) for i in range(34)]
@shot(7.90, 8.80)
def s9(img, t, lt):
    cam = Cam(0, -520, 300, 1150, S, 0.05, 0, 0, 0.55)
    X = T()
    plane(img, cam, X['plaster'], (-2400, -2600, 1300), (4800, 0, 0), (0, 2600, 0))
    plane(img, cam, X['table'], (-900, 0, 0), (1800, 0, 0), (0, 0, 1400))
    par = X['parch'].copy(); h, w = par.shape[:2]
    for k in range(4): cv2.line(par, (90, 200 + k * 80), (w - 90, 200 + k * 80), C('9a7a50'), 3)
    n = int(len(SIG) * clamp(lt / 0.7))
    pts = np.int32([(w / 2 + x * 1.4, h * 0.72 + y * 1.4) for x, y in SIG[:max(2, n)]])
    cv2.polylines(par, [pts], False, C('1a1420'), 7, cv2.LINE_AA)
    plane(img, cam, par, (-300, 0, 500), (600, 0, 0), (0, 0, 820))
    dof_blur(img, 3)
    tip = pts[-1]
    q, _ = cam.proj([(-300 + tip[0] / w * 600, 0, 500 + tip[1] / h * 820)])
    Bd = D(img, Aff(q[0][0], q[0][1], 2.2 * S, -0.7))
    Bd.line([(0, 0), (0, -60)], C('3a2a1e'), 6)
    Bd.poly(list(bez((0, -40), (-60, -260), (10, -420), 14)) + list(bez((10, -420), (40, -250), (0, -40), 14)), C('f4f1ea'), INK, 5)
    for k in range(8): Bd.line([(4, -80 - k * 40), (-30 + k * 2, -110 - k * 40)], C('cfc8b8'), 3)
    return cam

# S10 handshake + wax seal stamp
@shot(8.80, 10.0, mb=True)
def s10(img, t, lt):
    cam = Cam(0, -520, 300, 1150, S, 0, 0, 0, 0.55)
    X = T()
    plane(img, cam, X['plaster'], (-2400, -2600, 1300), (4800, 0, 0), (0, 2600, 0))
    plane(img, cam, X['table'], (-900, 0, 0), (1800, 0, 0), (0, 0, 1400))
    plane(img, cam, X['parch'], (-300, 0, 500), (600, 0, 0), (0, 0, 820))
    dof_blur(img, 16 * S * 3)
    hd = D(img, Aff(0, 0, S))
    shake = math.sin(lt * 22) * 26 if lt < 0.6 else 0
    hd.line([(-80, 760), (430, 760 + shake)], INK, 120); hd.line([(-80, 760), (430, 760 + shake)], C('2d4594'), 104)
    hd.line([(1160, 760), (650, 760 + shake)], INK, 120); hd.line([(1160, 760), (650, 760 + shake)], C('eef0f3'), 104)
    hd.ell(540, 760 + shake, 120, 82, C('fbf9f4'), INK, 9)
    hd.line([(470, 730 + shake), (610, 730 + shake)], C('e6e2da'), 6)
    # wax seal press
    if lt > 0.62:
        u = clamp((lt - 0.62) / 0.12)
        sy = lerp(1100, 1430, u ** 2)
        if u >= 1:
            hd.ell(540, 1450, 130, 112, C('a3141e'), INK, 7); hd.ell(540, 1450, 92, 80, C('c8323a'), None, 0)
            spr = text_sprite('N', int(150 * S), (250, 205, 120), 0.08, None, (90, 10, 20)); blit(img, spr, 540 * S, 1450 * S)
        hd.poly([(470, sy - 400), (610, sy - 400), (640, sy), (440, sy)], C('6a4428'), INK, 8)
        hd.ell(540, sy - 410, 90, 50, C('8a5a34'), INK, 8)
    return cam

# ---------------- captions: one word at a time ----------------
TIM = json.load(open(os.path.join(HERE, 'work/timing.json')))
def syl(w):
    if re.search(r'\d', w): return 4
    w = re.sub(r'[^a-z]', '', w.lower()); n = len(re.findall(r'[aeiouy]+', w))
    if w.endswith('e') and n > 1 and not w.endswith('le'): n -= 1
    return max(1, n)
WORDS = []
for a, b, txt in TIM:
    ws = txt.split(); ss = [syl(w) for w in ws]; tot = sum(ss); tt = a
    for w, s_ in zip(ws, ss):
        d_ = (b - a) * s_ / tot; WORDS.append([tt, tt + d_, w]); tt += d_
    WORDS[-1][1] = b + 0.2
for i in range(len(WORDS) - 1): WORDS[i][1] = min(WORDS[i][1] + 0.12, WORDS[i + 1][0])
def caption(img, t):
    for t0, t1, w in WORDS:
        if t0 - 0.02 <= t < t1:
            disp = w.replace('...', '').rstrip(',.!?') if not w.endswith('?') else w
            sc = 0.82 + 0.18 * back(clamp((t - t0) / 0.12), 2.0)
            spr = text_sprite(disp, int(112 * S), (255, 255, 255), 0.2, None, (12, 8, 14))
            shd = spr.copy(); shd[..., :3] = 0; k = max(3, int(16 * S) | 1); shd[..., 3] = cv2.GaussianBlur(shd[..., 3], (k, k), 0)
            blit(img, shd, 540 * S + 3 * S, 1190 * S + 8 * S, sc, 0.75); blit(img, spr, 540 * S, 1190 * S, sc)
            return

MOT = LK.Motes(60, 3)
_V = {}
def vig(img):
    if 'v' not in _V:
        y, x = np.mgrid[0:OH, 0:OW]; rr = np.sqrt(((x - OW / 2) / (OW / 2)) ** 2 + ((y - OH / 2) / (OH / 2)) ** 2)
        _V['v'] = (1 - 0.42 * np.clip(rr - 0.35, 0, 1) ** 1.25)[..., None].astype(np.float32)
    img[:] = (img * _V['v']).astype(np.uint8)

def core(t, sh):
    img = np.zeros((OH, OW, 3), np.uint8)
    cam = sh['fn'](img, t, t - sh['t0'])
    return img, cam

def render(fi):
    t = fi / FPS
    sh = next((s for s in SH if s['t0'] <= t < s['t1']), SH[-1])
    if sh.get('mb'):
        acc = None
        for k in range(4):
            im_, cam = core(max(sh['t0'], t - k / (FPS * 4) * 0.5), sh); acc = im_.astype(np.float32) if acc is None else acc + im_
        img = (acc / 4).astype(np.uint8)
    else:
        img, cam = core(t, sh)
    LK.key_light(img, -2.3, 0.28)
    LK.grade(img, 'warm', 1.12)
    LK.contrast(img, 1.1)
    LK.bloom(img, 222, 0.3)
    MOT.draw(img, t, 0, 0, (150, 210, 255), 0.7)
    vig(img)
    LK.grain(img, fi, 5)
    caption(img, t)
    return img

if __name__ == '__main__':
    mode = sys.argv[1]; out = sys.argv[2]; os.makedirs(out, exist_ok=True)
    if mode == 'stills':
        for tt in sys.argv[3].split(','):
            cv2.imwrite(f'{out}/s_{float(tt):05.2f}.jpg', render(int(round(float(tt) * FPS))))
    else:
        a, b = map(int, sys.argv[3].split('-'))
        for f in range(a, b + 1): cv2.imwrite(f'{out}/f{f:05d}.jpg', render(f), [cv2.IMWRITE_JPEG_QUALITY, 92])
