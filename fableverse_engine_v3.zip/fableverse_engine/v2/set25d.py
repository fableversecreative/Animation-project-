"""2.5D set engine: a real perspective camera over textured planes + billboard characters.

World: X right, Y down (floor at Y=0, ceiling negative), Z forward (into the screen).
Cam(x, y, z, f): screen = (W/2 + f*(X-x)/(Z-z), H/2 + f*(Y-y)/(Z-z)) in design units (1080x1920).
plane(): textured quad via homography with near-plane clipping (floors that reach the camera).
board(): a D() drawer placed at a world point with perspective scale (for rig/props drawing).
"""
import numpy as np, cv2, math
from rig import D, Aff, C, INK, shade, lerp, clamp
import look as LK

W, H = 1080, 1920

class Cam:
    def __init__(s, x, y, z, f=1150, S=1.0, roll=0.0, sx=0, sy=0, pitch=0.0):
        s.x, s.y, s.z, s.f, s.S, s.roll = x, y, z, f, S, roll; s.sx, s.sy = sx, sy; s.pitch = pitch
    def depth(s, P):
        P = np.asarray(P, float).reshape(-1, 3)
        cp, sp = math.cos(s.pitch), math.sin(s.pitch)
        return (P[:, 1] - s.y) * sp + (P[:, 2] - s.z) * cp
    def proj(s, P):
        P = np.asarray(P, float).reshape(-1, 3)
        cp, sp = math.cos(s.pitch), math.sin(s.pitch)
        yc = (P[:, 1] - s.y) * cp - (P[:, 2] - s.z) * sp
        dz = np.maximum((P[:, 1] - s.y) * sp + (P[:, 2] - s.z) * cp, 1e-3)
        u = s.f * (P[:, 0] - s.x) / dz; v = s.f * yc / dz
        c, sn = math.cos(s.roll), math.sin(s.roll)
        X = W / 2 + s.sx + u * c - v * sn; Y = H / 2 + s.sy + u * sn + v * c
        return np.stack([X, Y], 1) * s.S, dz
    def scale(s, Z): return s.f / max(1e-3, Z - s.z)

def plane(img, cam, tex, P0, U, V, near=40, alpha=1.0):
    """world point = P0 + u*U + v*V, u,v in [0,1]; tex covers the full quad"""
    P0, U, V = map(lambda a: np.asarray(a, float), (P0, U, V))
    v0 = 0.0
    zr0 = cam.depth(P0)[0]; dzv = cam.depth(P0 + V)[0] - zr0
    zr1 = cam.depth(P0 + U)[0]
    if min(zr0, zr1) < near:
        if dzv <= 1e-6: return
        v0 = (near - min(zr0, zr1)) / dzv
        if v0 >= 1: return
    th, tw = tex.shape[:2]
    corners = [P0 + 0 * U + v0 * V, P0 + U + v0 * V, P0 + U + V, P0 + V]
    src = np.float32([[0, v0 * (th - 1)], [tw - 1, v0 * (th - 1)], [tw - 1, th - 1], [0, th - 1]])
    dst, _ = cam.proj(corners)
    dst = dst.astype(np.float32)
    h, w = img.shape[:2]
    if dst[:, 0].max() < -50 or dst[:, 0].min() > w + 50 or dst[:, 1].max() < -50 or dst[:, 1].min() > h + 50: return
    Mh = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(tex, Mh, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
    m = np.zeros((h, w), np.uint8)
    cv2.fillPoly(m, [(dst * 16).astype(np.int32)], 255, cv2.LINE_AA, shift=4)
    mf = (m.astype(np.float32) / 255 * alpha)[..., None]
    img[:] = (img * (1 - mf) + warped * mf).astype(np.uint8)

def board(img, cam, X, Y, Z, extra=1.0):
    """drawer whose (0,0) sits at world (X,Y,Z) and whose units are world units"""
    p, dz = cam.proj([(X, Y, Z)])
    k = cam.f / dz[0] * cam.S * extra
    c, sn = math.cos(cam.roll), math.sin(cam.roll)
    return D(img, np.array([[k * c, -k * sn, p[0][0]], [k * sn, k * c, p[0][1]], [0, 0, 1]], float))

def floor_shadow(img, cam, X, Z, rx, rz, dx=0.0, dz=0.0, k=0.55, blur=0.25):
    pts = [(X + dx + math.cos(a) * rx, 0, Z + dz + math.sin(a) * rz) for a in np.linspace(0, 2 * math.pi, 28, endpoint=False)]
    p, d_ = cam.proj(pts)
    if (d_ < 30).any(): return
    h, w = img.shape[:2]
    x0, y0 = np.floor(p.min(0)).astype(int) - 4; x1, y1 = np.ceil(p.max(0)).astype(int) + 4
    xa, ya, xb, yb = max(0, x0), max(0, y0), min(w, x1), min(h, y1)
    if xa >= xb or ya >= yb: return
    m = np.zeros((yb - ya, xb - xa), np.uint8)
    cv2.fillPoly(m, [((p - [xa, ya]) * 16).astype(np.int32)], 255, cv2.LINE_AA, shift=4)
    kk = max(3, int((x1 - x0) * blur) | 1)
    m = cv2.GaussianBlur(m, (kk, kk), 0).astype(np.float32)[..., None] / 255
    roi = img[ya:yb, xa:xb].astype(np.float32)
    img[ya:yb, xa:xb] = (roi * (1 - m * (1 - k))).astype(np.uint8)

# ---------------- procedural textures ----------------
def _noise(h, w, cells, seed):
    r = np.random.default_rng(seed)
    return cv2.resize(r.standard_normal((max(2, h // cells), max(2, w // cells))).astype(np.float32), (w, h), interpolation=cv2.INTER_CUBIC)

def tex_marble(w=1024, h=2048, tiles=(6, 14), c1=C('efe6d6'), c2=C('3b3340'), seed=1):
    img = np.zeros((h, w, 3), np.uint8)
    tw, th = w // tiles[0], h // tiles[1]
    for i in range(tiles[0]):
        for j in range(tiles[1]):
            img[j * th:(j + 1) * th, i * tw:(i + 1) * tw] = c1 if (i + j) % 2 == 0 else c2
    n = _noise(h, w, 60, seed) * 0.6 + _noise(h, w, 14, seed + 1) * 0.4
    veins = np.abs(np.sin((np.mgrid[0:h, 0:w][1] * 0.02 + n * 3.0))) ** 12
    img = img.astype(np.float32) * (1 - 0.18 * veins[..., None]) * (1 + 0.04 * n[..., None])
    for i in range(tiles[0] + 1): cv2.line(img, (i * tw, 0), (i * tw, h), (60, 50, 50), 3)
    for j in range(tiles[1] + 1): cv2.line(img, (0, j * th), (w, j * th), (60, 50, 50), 3)
    return np.clip(img, 0, 255).astype(np.uint8)

def tex_carpet(w=256, h=2048, col=C('a3202a')):
    img = np.zeros((h, w, 3), np.uint8); img[:] = col
    cv2.rectangle(img, (0, 0), (w, h), C('e3b84a'), 18)
    cv2.rectangle(img, (26, -10), (w - 26, h + 10), shade(col, 0.75), 6)
    n = _noise(h, w, 20, 5)
    img = np.clip(img.astype(np.float32) * (1 + 0.06 * n[..., None]), 0, 255).astype(np.uint8)
    return img

def tex_wall(w=2048, h=1600, col=C('e9dcc0'), panel=C('d8c8a6'), seed=3, windows=True):
    img = np.zeros((h, w, 3), np.uint8); img[:] = col
    d = D(img, Aff())
    # wainscot
    d.poly([(0, h * 0.72), (w, h * 0.72), (w, h), (0, h)], shade(panel, 0.85), None)
    for i in range(10):
        x = i * w / 10 + 30
        d.poly([(x, h * 0.76), (x + w / 10 - 60, h * 0.76), (x + w / 10 - 60, h * 0.96), (x, h * 0.96)], None, shade(panel, 0.65), 5)
    d.line([(0, h * 0.72), (w, h * 0.72)], C('c99a30'), 10)
    d.line([(0, h * 0.06), (w, h * 0.06)], C('c99a30'), 14)
    if windows:
        for k in range(3):
            cx = w * (0.2 + 0.3 * k)
            # tall arched window
            pts = [(cx - 150, h * 0.66), (cx - 150, h * 0.3)] + [(cx + 150 * math.cos(a), h * 0.3 + 150 * -math.sin(a)) for a in np.linspace(math.pi, 0, 20)] + [(cx + 150, h * 0.66)]
            d.poly(pts, C('fff3d2'), C('8a6a3a'), 14)
            d.line([(cx, h * 0.66), (cx, h * 0.22)], C('8a6a3a'), 8); d.line([(cx - 150, h * 0.45), (cx + 150, h * 0.45)], C('8a6a3a'), 8)
            # drapes
            for sd in (-1, 1):
                x0 = cx + sd * 150
                d.poly([(x0, h * 0.18), (x0 + sd * 110, h * 0.18), (x0 + sd * 90, h * 0.7), (x0 - sd * 10, h * 0.7), (x0 + sd * 10, h * 0.45)], C('a3202a'), INK, 6)
                for q in range(3): d.line([(x0 + sd * (25 + q * 28), h * 0.2), (x0 + sd * (20 + q * 24), h * 0.68)], C('7a1820'), 5)
            d.poly([(cx - 280, h * 0.15), (cx + 280, h * 0.15), (cx + 260, h * 0.21), (cx - 260, h * 0.21)], C('c99a30'), INK, 5)
    n = _noise(h, w, 80, seed) * 0.7 + _noise(h, w, 16, seed + 1) * 0.3
    img = np.clip(img.astype(np.float32) * (1 + 0.05 * n[..., None]), 0, 255).astype(np.uint8)
    return img

def column(d, h=1000, r=70, col=C('efe6d6')):
    """draw a fluted column on a board drawer (base at 0, top at -h)"""
    d.poly([(-r * 1.4, 0), (r * 1.4, 0), (r * 1.4, -40), (-r * 1.4, -40)], shade(col, 0.9), INK, 5)
    d.poly([(-r, -40), (r, -40), (r, -h + 50), (-r, -h + 50)], col, INK, 5)
    d.poly([(r * 0.3, -40), (r, -40), (r, -h + 50), (r * 0.3, -h + 50)], shade(col, 0.82), None)
    d.poly([(-r, -40), (-r * 0.55, -40), (-r * 0.55, -h + 50), (-r, -h + 50)], shade(col, 1.04), None)
    for k in (-0.5, 0, 0.5): d.line([(r * k, -50), (r * k, -h + 60)], shade(col, 0.88), 4)
    d.poly([(-r * 1.5, -h + 50), (r * 1.5, -h + 50), (r * 1.3, -h), (-r * 1.3, -h)], C('e3b84a'), INK, 5)

# ---------------- v3 realistic (bump-lit) textures ----------------
def fbm(h, w, seed=0, octaves=5, base=8):
    r = np.random.default_rng(seed); out = np.zeros((h, w), np.float32); amp = 1.0; tot = 0
    for o in range(octaves):
        cells = max(2, base * 2 ** o)
        g = r.standard_normal((cells, max(2, int(cells * w / h)))).astype(np.float32)
        out += cv2.resize(g, (w, h), interpolation=cv2.INTER_CUBIC) * amp; tot += amp; amp *= 0.5
    return out / tot

def bump_shade(height, albedo, light=(-0.6, -0.8), strength=2.2, ao=None):
    gx = cv2.Sobel(height, cv2.CV_32F, 1, 0, ksize=3); gy = cv2.Sobel(height, cv2.CV_32F, 0, 1, ksize=3)
    lx, ly = light; n = math.hypot(lx, ly); lx, ly = lx / n, ly / n
    sh = 1 + strength * -(gx * lx + gy * ly)
    sh = np.clip(sh, 0.55, 1.4)
    if ao is not None: sh = sh * ao
    return np.clip(albedo.astype(np.float32) * sh[..., None], 0, 255).astype(np.uint8)

def ramp(v, cols):
    v = np.clip(v, 0, 1); n = len(cols) - 1
    idx = np.clip((v * n).astype(int), 0, n - 1); u = (v * n - idx)[..., None]
    c = np.array(cols, np.float32)
    return c[idx] * (1 - u) + c[idx + 1] * u

def tex_wood_floor(w=1024, h=2048, plank=128, seed=3, cols=(C('5a3a22'), C('8a5a34'), C('b07a48'), C('c99566'))):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    col_id = (xx // plank).astype(int)
    r = np.random.default_rng(seed)
    offs = r.uniform(0, 1, 64); tone = r.uniform(-0.18, 0.18, 64)
    grain = fbm(h, w, seed, 4, 6)
    stretch = cv2.resize(fbm(h // 16, w, seed + 1, 3, 4), (w, h))
    g = 0.5 + 0.35 * np.sin((xx * 0.18 + stretch * 30 + grain * 4)) + 0.15 * grain
    g = g + tone[col_id % 64]
    alb = ramp(g * 0.8 + 0.1, list(cols))
    seam = ((xx % plank) < 3) | ((((yy + offs[col_id % 64] * h) % (h * 0.5)) < 3))
    height = (g * 0.6).astype(np.float32)
    height[seam] -= 1.2
    out = bump_shade(cv2.GaussianBlur(height, (5, 5), 0), alb, (-0.3, -1.0), 1.4)
    out[seam] = (out[seam] * 0.45).astype(np.uint8)
    return out

def tex_plaster(w=2048, h=1600, col=C('d9c3a0'), seed=5):
    n = fbm(h, w, seed, 6, 6)
    alb = np.zeros((h, w, 3), np.float32); alb[:] = col
    alb *= (1 + 0.12 * n[..., None])
    return bump_shade(n * 1.5, alb, (-0.5, -0.8), 1.2)

def tex_parchment(w=1024, h=1400, seed=9):
    n = fbm(h, w, seed, 5, 4)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    edge = np.minimum(np.minimum(xx, w - xx), np.minimum(yy, h - yy)) / 120
    burn = np.clip(1 - edge, 0, 1) ** 2
    alb = ramp(0.55 + 0.25 * n - 0.45 * burn, [C('5a3a1e'), C('b58a52'), C('e6cf9c'), C('f6e8c6')])
    return bump_shade(n * 0.8, alb, (-0.5, -0.8), 0.8)

def dof_blur(img, px):
    k = max(3, int(px) | 1); img[:] = cv2.GaussianBlur(img, (k, k), 0)

# ---------------- Blender plates (laptop) ----------------
_PL = {}
def plate_bg(img, folder, frame):
    """paste a Blender-rendered background plate (PNG ####) under the frame; returns True if found"""
    import os
    p = os.path.join(folder, f'{frame:04d}.png')
    if not os.path.exists(p): return False
    im = cv2.imread(p)
    img[:] = cv2.resize(im, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_AREA)
    return True

def cam_from_keys(keys, t, S=1.0):
    """same interpolation as blender/hall_plate.py so 2D toons line up with the 3D plates"""
    def sm(u): u = max(0, min(1, u)); return u * u * u * (u * (u * 6 - 15) + 10)
    if t <= keys[0][0]: k = keys[0][1:]
    else:
        k = keys[-1][1:]
        for a, b in zip(keys, keys[1:]):
            if t <= b[0]:
                u = sm((t - a[0]) / max(1e-6, b[0] - a[0])); k = [a[i] + (b[i] - a[i]) * u for i in range(1, 7)]; break
    x, y, z, p, r, f = k
    return Cam(x, y, z, f, S, r, 0, 0, p)
