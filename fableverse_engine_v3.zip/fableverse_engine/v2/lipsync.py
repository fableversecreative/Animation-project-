"""Audio-driven lip sync for cartoon characters (no speech recognition needed).

visemes(audio_path, fps) -> list per frame of dict(v=<shape>, open=0..1)
Shapes (Preston-Blair-style set):
  'rest'  closed, relaxed           (silence)
  'MBP'   lips pressed               (short closures between syllables)
  'small' slightly open              (quiet voiced sounds)
  'A'     wide open                  (loud open vowels: a, ah)
  'E'     wide, teeth showing        (ee, eh, s, z, t, d: bright / hissy)
  'O'     round open                 (o, aw: dark, loud)
  'U'     small round pucker         (oo, w: dark, quiet)
  'FV'    top teeth on lower lip     (noisy, unvoiced, low level)
Classification uses loudness + spectral balance + zero-crossing rate per frame,
then hold/hysteresis smoothing so the mouth doesn't flicker.
"""
import numpy as np, subprocess, json, os

SR = 16000

def load_mono(path):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)

def features(x, fps):
    hop = SR / fps; win = int(SR * 0.04)
    n = int(len(x) / hop) + 1
    F = []
    freqs = np.fft.rfftfreq(win, 1 / SR)
    bands = [(80, 300), (300, 1000), (1000, 2500), (2500, 7000)]
    w = np.hanning(win)
    for i in range(n):
        c = int(i * hop); seg = x[max(0, c - win // 2): c + win // 2]
        if len(seg) < win: seg = np.pad(seg, (0, win - len(seg)))
        rms = np.sqrt((seg ** 2).mean() + 1e-12)
        zcr = np.mean(np.abs(np.diff(np.sign(seg))) > 0)
        sp = np.abs(np.fft.rfft(seg * w)) ** 2
        be = [sp[(freqs >= a) & (freqs < b)].sum() + 1e-12 for a, b in bands]
        tot = sum(be)
        cen = (sp * freqs).sum() / (sp.sum() + 1e-12)
        F.append((rms, zcr, *[b / tot for b in be], cen))
    return np.array(F)

def classify(F):
    rms = F[:, 0]; db = 20 * np.log10(rms + 1e-9)
    loud = db[db > db.max() - 45]
    hi_ref = np.percentile(loud, 92) if len(loud) else db.max()
    lvl = np.clip((db - (hi_ref - 30)) / 30, 0, 1)          # 0 = silence, 1 = loudest speech
    voiced = lvl > 0.12
    cen = F[:, 6]
    # rank of spectral centroid among speech frames: voice-independent "brightness"
    order = np.argsort(np.argsort(cen[voiced]))
    rank = np.zeros(len(F)); rank[voiced] = order / max(1, voiced.sum() - 1)
    hiss = F[:, 5]; zcr = F[:, 1]
    hr = np.zeros(len(F)); hr[voiced] = np.argsort(np.argsort(hiss[voiced])) / max(1, voiced.sum() - 1)
    out = []
    for i in range(len(F)):
        L = lvl[i]; R = rank[i]
        if L < 0.12: v = 'rest'
        elif hr[i] > 0.9 and L < 0.5: v = 'FV' if zcr[i] > 0.25 else 'E'
        elif R > 0.78: v = 'E'
        elif R < 0.18: v = 'O' if L > 0.55 else 'U'
        elif L > 0.6: v = 'A'
        elif L < 0.35: v = 'small'
        else: v = 'A' if R < 0.5 else 'small'
        out.append([v, float(L)])
    return out

def smooth(seq, hold=2):
    """min hold frames, closures (MBP) on sharp dips between loud frames, rest after silence"""
    n = len(seq); vs = [s[0] for s in seq]; op = np.array([s[1] for s in seq])
    # dips -> MBP
    for i in range(1, n - 1):
        if vs[i] not in ('rest',) and op[i] < op[i - 1] - 0.12 and op[i] < op[i + 1] - 0.12 and op[i] < 0.5: vs[i] = 'MBP'
    # hold
    res = []; cur = vs[0]; age = 0
    for i in range(n):
        if vs[i] != cur and age >= hold: cur = vs[i]; age = 0
        else: age += 1
        res.append(cur)
    op = np.convolve(op, [0.25, 0.5, 0.25], 'same')
    return [dict(v=res[i], open=float(op[i])) for i in range(n)]

def visemes(audio_path, fps=30, cache=True):
    cp = audio_path + f'.vis{fps}.json'
    if cache and os.path.exists(cp): return json.load(open(cp))
    x = load_mono(audio_path)
    out = smooth(classify(features(x, fps)))
    if cache: json.dump(out, open(cp, 'w'))
    return out

if __name__ == '__main__':
    import sys, collections
    v = visemes(sys.argv[1], 30, False)
    print(len(v), collections.Counter(d['v'] for d in v))
    print(' '.join(d['v'] for d in v[:200]))
