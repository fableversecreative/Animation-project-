# FableVerse laptop setup (RTX 3050, 8 GB RAM)
1. Install Blender 4.2 LTS (free, blender.org). Default install path is fine.
2. Blender > Edit > Preferences > System > Cycles Render Devices: OptiX, tick the RTX 3050. Save preferences.
3. Install the Claude desktop app, sign in, open this FableVerse chat there and connect a folder, e.g. Documents/FableVerse.
4. Put fableverse_engine (unzipped) inside that folder.
5. Before long renders: plug in charger, Windows power mode = Best performance, close Chrome/other apps.
Claude then runs:  blender -b -P v2/blender/hall_plate.py -- v2/blender/test_shot.json v2/work/plates/test [--preview]
and composites the toons on top with set25d.plate_bg + cam_from_keys.
