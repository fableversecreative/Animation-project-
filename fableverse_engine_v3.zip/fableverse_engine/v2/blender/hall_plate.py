"""FableVerse Blender background-plate renderer (Eevee).

Run on the laptop:
  blender -b -P hall_plate.py -- shot.json OUT_DIR [--preview]

Builds the palace-hall 3D set, animates the camera from shot.json (in ENGINE coordinates),
renders PNG background plates only (no characters). The engine then draws the 2D toons on top
with the SAME camera (set25d.Cam), so characters sit perfectly in the 3D set.

Engine coords: X right, Y down (floor Y=0), Z forward.  Blender: (X, Z, -Y).
Engine focal f is in pixels on a 1080-wide frame -> lens_mm = f * 36 / 1080 (sensor width 36, horizontal fit).
shot.json: {"fps":30, "frames":N, "keys":[[t, x, y, z, pitch, roll, f], ...], "set":"hall"}
"""
import bpy, sys, json, math, os
from mathutils import Vector, Euler, Matrix, Quaternion

argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
SHOT = json.load(open(argv[0])); OUT = argv[1]; PREVIEW = '--preview' in argv
HERE = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(HERE, 'textures')

def B(x, y, z): return Vector((x, z, -y))          # engine -> blender
U = 0.01                                            # 1 engine unit = 1 cm

# ------------------------------------------------ scene reset + render settings
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
for eng in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
    try: sc.render.engine = eng; break
    except Exception: pass
sc.render.resolution_x, sc.render.resolution_y = 1080, 1920
sc.render.resolution_percentage = 33 if PREVIEW else 100
sc.render.fps = SHOT.get('fps', 30)
sc.render.image_settings.file_format = 'PNG'
sc.render.film_transparent = False
ee = sc.eevee
for k, v in (('taa_render_samples', 16 if PREVIEW else 48), ('use_gtao', True), ('use_soft_shadows', True),
             ('use_volumetric_shadows', True), ('volumetric_tile_size', '8'), ('use_raytracing', True),
             ('use_shadows', True), ('use_bloom', True), ('bloom_intensity', 0.06)):
    try: setattr(ee, k, v)
    except Exception: pass
try:
    sc.view_settings.view_transform = 'AgX'
except Exception:
    sc.view_settings.view_transform = 'Filmic'
sc.view_settings.look = 'None'

# ------------------------------------------------ materials
def img_mat(name, file, rough=0.6, bump=0.15, scale=(1, 1), emit=None, tint=None):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree; n = nt.nodes; l = nt.links
    bs = n['Principled BSDF']; bs.inputs['Roughness'].default_value = rough
    if file and os.path.exists(os.path.join(TEX, file)):
        tx = n.new('ShaderNodeTexImage'); tx.image = bpy.data.images.load(os.path.join(TEX, file))
        mp = n.new('ShaderNodeMapping'); co = n.new('ShaderNodeTexCoord')
        mp.inputs['Scale'].default_value = (scale[0], scale[1], 1)
        l.new(co.outputs['UV'], mp.inputs['Vector']); l.new(mp.outputs['Vector'], tx.inputs['Vector'])
        l.new(tx.outputs['Color'], bs.inputs['Base Color'])
        if bump > 0:
            bp = n.new('ShaderNodeBump'); bp.inputs['Strength'].default_value = bump
            l.new(tx.outputs['Color'], bp.inputs['Height']); l.new(bp.outputs['Normal'], bs.inputs['Normal'])
    elif tint:
        bs.inputs['Base Color'].default_value = tint
    if emit:
        for key in ('Emission Color', 'Emission'):
            if key in bs.inputs: bs.inputs[key].default_value = emit[0]; break
        bs.inputs['Emission Strength'].default_value = emit[1]
    return m

def col(name, rgb, rough=0.5, metal=0.0, emit=0.0):
    m = bpy.data.materials.new(name); m.use_nodes = True; bs = m.node_tree.nodes['Principled BSDF']
    bs.inputs['Base Color'].default_value = (*rgb, 1); bs.inputs['Roughness'].default_value = rough; bs.inputs['Metallic'].default_value = metal
    if emit:
        for key in ('Emission Color', 'Emission'):
            if key in bs.inputs: bs.inputs[key].default_value = (*rgb, 1); break
        bs.inputs['Emission Strength'].default_value = emit
    return m

M_WOOD = img_mat('wood', 'wood_floor.png', 0.35, 0.2, (3, 3))
M_PLAS = img_mat('plaster', 'plaster.png', 0.85, 0.4, (2, 1))
M_CEIL = col('ceiling', (0.09, 0.055, 0.035), 0.7)
M_GOLD = col('gold', (0.85, 0.62, 0.22), 0.3, 1.0)
M_RED = col('drape', (0.42, 0.04, 0.06), 0.8)
M_MARB = col('marble', (0.86, 0.82, 0.74), 0.25)
M_GLASS = col('window', (1.0, 0.9, 0.7), 0.5, 0, 6.0)
M_FLAME = col('flame', (1.0, 0.7, 0.3), 0.5, 0, 25.0)

def add(obj, mat):
    obj.data.materials.append(mat); return obj

def box(name, eng_min, eng_max, mat, bevel=0.0):
    (x0, y0, z0), (x1, y1, z1) = eng_min, eng_max
    c = B((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2) * U
    bpy.ops.mesh.primitive_cube_add(location=c)
    o = bpy.context.active_object; o.name = name
    o.scale = (abs(x1 - x0) * U / 2, abs(z1 - z0) * U / 2, abs(y1 - y0) * U / 2)
    if bevel:
        bm = o.modifiers.new('bev', 'BEVEL'); bm.width = bevel; bm.segments = 3
    return add(o, mat)

def plane_uv(name, eng_min, eng_max, mat):
    o = box(name, eng_min, eng_max, mat)
    bpy.context.view_layer.objects.active = o
    bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.uv.cube_project(cube_size=4.0); bpy.ops.object.mode_set(mode='OBJECT')
    return o

def column(x, z, h=1500, r=70):
    bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=r * U, depth=(h - 120) * U, location=B(x, -h / 2, z) * U)
    c = add(bpy.context.active_object, M_MARB)
    bpy.ops.mesh.primitive_cube_add(location=B(x, -20, z) * U); b = add(bpy.context.active_object, M_MARB); b.scale = (r * 1.5 * U, r * 1.5 * U, 20 * U)
    bpy.ops.mesh.primitive_cube_add(location=B(x, -h + 30, z) * U); t = add(bpy.context.active_object, M_GOLD); t.scale = (r * 1.4 * U, r * 1.4 * U, 30 * U)

# ------------------------------------------------ the palace hall (matches demo3 HL/HR/HC/HZ)
HL, HR, HC, HZ = -900, 900, -1500, 2600
plane_uv('floor', (HL, 0, -400), (HR, 10, HZ), M_WOOD)
box('ceiling', (HL, HC - 20, -400), (HR, HC, HZ), M_CEIL)
plane_uv('backwall', (HL, HC, HZ), (HR, 0, HZ + 20), M_PLAS)
plane_uv('lwall', (HL - 20, HC, -400), (HL, 0, HZ), M_PLAS)
plane_uv('rwall', (HR, HC, -400), (HR + 20, 0, HZ), M_PLAS)
for z in range(0, HZ, 300):                                     # ceiling beams
    box(f'beam{z}', (HL, HC + 60, z), (HR, HC, z + 40), col(f'bm{z}', (0.16, 0.1, 0.06), 0.6))
box('wainL', (HL, -420, -400), (HL + 12, 0, HZ), col('wain', (0.33, 0.2, 0.11), 0.5))
box('wainR', (HR - 12, -420, -400), (HR, 0, HZ), col('wain2', (0.33, 0.2, 0.11), 0.5))
for wx in (-420, 420):                                          # tall windows + drapes on back wall
    box(f'win{wx}', (wx - 150, -1250, HZ - 5), (wx + 150, -300, HZ - 2), M_GLASS)
    for sd in (-1, 1):
        box(f'drape{wx}{sd}', (wx + sd * 150 - (60 if sd < 0 else -60) * 0 - 50, -1280, HZ - 40), (wx + sd * 150 + 50, -280, HZ - 10), M_RED, 0.02)
    box(f'pel{wx}', (wx - 260, -1340, HZ - 50), (wx + 260, -1280, HZ - 10), M_GOLD)
for z in (500, 1300, 2100):                                     # columns
    for sx in (-720, 720): column(sx, z)
box('carpet', (-180, -2, -400), (180, 0, HZ), col('carpet', (0.45, 0.05, 0.07), 0.9))
for sx in (-890, 890):                                          # wall sconces with real lights
    for z in (900, 1800):
        box(f'sc{sx}{z}', (sx - 10, -780, z - 15), (sx + 10, -740, z + 15), M_GOLD)
        bpy.ops.object.light_add(type='POINT', location=B(sx * 0.97, -800, z) * U)
        L = bpy.context.active_object.data; L.energy = 60; L.color = (1.0, 0.72, 0.4); L.shadow_soft_size = 0.05
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.06, location=B(sx * 0.97, -800, z) * U); add(bpy.context.active_object, M_FLAME)

# sunlight through the windows (warm key) + soft fill
bpy.ops.object.light_add(type='SUN', location=(0, 0, 10))
sun = bpy.context.active_object; sun.data.energy = 3.5; sun.data.color = (1.0, 0.85, 0.65)
sun.rotation_euler = Euler((math.radians(55), 0, math.radians(180)), 'XYZ')
for wx in (-420, 420):
    bpy.ops.object.light_add(type='AREA', location=B(wx, -800, HZ - 60) * U)
    a = bpy.context.active_object; a.data.energy = 900; a.data.size = 3.0; a.data.color = (1.0, 0.86, 0.66)
    a.rotation_euler = Euler((math.radians(-90), 0, 0), 'XYZ')
w = bpy.data.worlds.new('w'); sc.world = w; w.use_nodes = True
w.node_tree.nodes['Background'].inputs['Color'].default_value = (0.05, 0.035, 0.025, 1)
w.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.6

# volumetric haze for visible light shafts (the premium "god rays")
bpy.ops.mesh.primitive_cube_add(location=B(0, -750, (HZ - 400) / 2) * U)
vol = bpy.context.active_object; vol.scale = ((HR - HL) * U / 2, (HZ + 400) * U / 2, 760 * U)
vm = bpy.data.materials.new('haze'); vm.use_nodes = True; nt = vm.node_tree
nt.nodes.remove(nt.nodes['Principled BSDF'])
pv = nt.nodes.new('ShaderNodeVolumePrincipled'); pv.inputs['Density'].default_value = 0.012 if not PREVIEW else 0.008
nt.links.new(pv.outputs[0], nt.nodes['Material Output'].inputs['Volume']); vol.data.materials.append(vm)

# ------------------------------------------------ camera from engine keys
bpy.ops.object.camera_add(); cam = bpy.context.active_object; sc.camera = cam
cam.data.sensor_fit = 'HORIZONTAL'; cam.data.sensor_width = 36
fps = SHOT.get('fps', 30); keys = SHOT['keys']
def smooth(u): u = max(0, min(1, u)); return u * u * u * (u * (u * 6 - 15) + 10)
def at(t):
    if t <= keys[0][0]: return keys[0][1:]
    for a, b in zip(keys, keys[1:]):
        if t <= b[0]:
            u = smooth((t - a[0]) / max(1e-6, b[0] - a[0])); return [a[i] + (b[i] - a[i]) * u for i in range(1, 7)]
    return keys[-1][1:]
def place_cam(x, y, z, pitch, roll, f):
    cam.location = B(x, y, z) * U
    fwd = Vector((0, math.cos(pitch), -math.sin(pitch)))       # engine pitch>0 looks down
    q = fwd.to_track_quat('-Z', 'Y')
    q = q @ Quaternion((0, 0, 1), -roll)
    cam.rotation_mode = 'QUATERNION'; cam.rotation_quaternion = q
    cam.data.lens = f * 36 / 1080
N = SHOT['frames']
sc.frame_start, sc.frame_end = 0, N - 1
for fi in range(N):
    x, y, z, p, r, f = at(fi / fps)
    place_cam(x, y, z, p, r, f)
    cam.keyframe_insert('location', frame=fi); cam.keyframe_insert('rotation_quaternion', frame=fi); cam.data.keyframe_insert('lens', frame=fi)

os.makedirs(OUT, exist_ok=True)
sc.render.filepath = os.path.join(OUT, '')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'set.blend'))
bpy.ops.render.render(animation=True)
print('PLATES DONE', OUT)
