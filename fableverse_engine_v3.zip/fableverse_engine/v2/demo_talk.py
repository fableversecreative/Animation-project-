"""v2 demo: talking Napoleon in a 2.5D palace hall (lip sync + expressions + perspective set)."""
import numpy as np, cv2, math, json, sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from props import *
from face import Face, expr, timeline
import look as LK
from set25d import Cam, plane, board, floor_shadow, tex_marble, tex_carpet, tex_wall, column
from lipsync import visemes

W, H, FPS = 1080, 1920, 30
S = float(os.environ.get('S', '0.3333333'))
OW, OH = int(round(W * S)), int(round(H * S))
HERE = os.path.dirname(os.path.abspath(__file__))
VIS = visemes(os.path.join(HERE, 'work/voice.mp3'), FPS)
DUR = 7.0

# ---------------- textures (built once) ----------------
TX = {}
def tex():
    if not TX:
        TX['floor'] = tex_marble(1024, 2048, (6, 16), C('efe4d2'), C('7a5a52'))
        TX['carpet'] = tex_carpet(256, 2048)
        TX['back'] = tex_wall(2048, 1600)
        TX['side'] = tex_wall(2048, 1600, windows=False, seed=7)
        c = np.zeros((1024, 1024, 3), np.uint8); c[:] = C('6a4a2e')
        for i in range(0, 1024, 128):
            cv2.rectangle(c, (i + 10, 10), (i + 118, 1014), C('8a6436'), -1)
        for j in range(0, 1024, 128): cv2.line(c, (0, j), (1024, j), C('c99a30'), 8)
        TX['ceil'] = c
        # bake light: floor brighter toward the windows (far end), darker near camera edges
        f = TX['floor'].astype(np.float32); hh, ww = f.shape[:2]
        yy, xx = np.mgrid[0:hh, 0:ww].astype(np.float32)
        g = 0.72 + 0.4 * (yy / hh) ** 1.5 - 0.18 * np.abs(xx / ww - 0.5) * 2
        TX['floor'] = np.clip(f * g[..., None], 0, 255).astype(np.uint8)
    return TX

L, R, Hc, ZB = -1100, 1100, -1700, 4200
def hall(img, cam):
    T = tex()
    plane(img, cam, T['ceil'], (L, Hc, 0), (R - L, 0, 0), (0, 0, ZB))
    plane(img, cam, T['back'], (L, Hc, ZB), (R - L, 0, 0), (0, -Hc, 0))
    plane(img, cam, T['side'], (L, Hc, ZB), (0, 0, -ZB), (0, -Hc, 0))
    plane(img, cam, T['side'], (R, Hc, 0), (0, 0, ZB), (0, -Hc, 0))
    plane(img, cam, T['floor'], (L, 0, 0), (R - L, 0, 0), (0, 0, ZB))
    plane(img, cam, T['carpet'], (-180, -1, 0), (360, 0, 0), (0, 0, ZB))

COLS = [(sx * 820, z) for z in (700, 1500, 2300, 3100, 3900) for sx in (-1, 1)]
WINS = [(L + (R - L) * (0.2 + 0.3 * k), Hc + 1600 * 0.45, ZB - 5) for k in range(3)]

# ---------------- performance timeline ----------------
EX = [(0.0, expr('proud')), (1.0, expr('smug')), (2.35, expr('neutral', look=(0.2, 0))), (2.9, expr('worried', look=(0.6, 0.1))),
      (3.6, expr('worried', look=(0.0, 0.0), sweat=0.0)), (4.45, expr('confused', look=(0.7, 0.8))), (4.8, expr('shocked', look=(0.6, 0.9))),
      (5.75, expr('deadpan', look=(0.0, 0.0)))]
BLINKS = (1.75, 3.55, 6.3)
def arms(t):
    if t < 1.05: return (lerp(25, 70, smooth(clamp(t / 0.6))), 70), (54, 52)
    if t < 2.4: return (lerp(70, 120, smooth(clamp((t - 1.05) / 0.4))), 74), (54, 52)
    if t < 4.5: return (lerp(30, 152, smooth(clamp((t - 2.85) / 0.25))), 62), (-25, 70)
    if t < 5.7: return (lerp(152, 168, smooth(clamp((t - 4.75) / 0.15))), 72), (lerp(-25, -168, smooth(clamp((t - 4.75) / 0.15))), 72)
    return (lerp(168, 25, smooth(clamp((t - 5.7) / 0.35))), 70), (lerp(-168, -25, smooth(clamp((t - 5.7) / 0.35))), 70)

def cam_at(t):
    # dolly path: (time, x, z, roll)
    keys = [(0.0, -90, 420, 0.0), (2.3, 30, 1000, 0.0), (2.9, 40, 1130, -0.04), (4.7, 0, 1170, -0.04), (5.05, 60, 560, 0.0), (7.0, 70, 600, 0.01)]
    for a, b in zip(keys, keys[1:]):
        if t <= b[0]:
            u = (t - a[0]) / (b[0] - a[0])
            u = eout(u) if b[0] == 5.05 else smooth(u)
            x, z, r = (lerp(a[i], b[i], u) for i in (1, 2, 3)); break
    else:
        x, z, r = keys[-1][1:]
    dz = 1500 - z; f = 1150
    y = -270 + (960 - 860) * dz / f
    sh = 0
    if 4.8 <= t < 5.1: sh = 14 * (1 - (t - 4.8) / 0.3)
    return Cam(x, y, z, f, S, r, sh * math.sin(t * 90), sh * math.cos(t * 70))

RAB_PATH = lambda t: (lerp(560, 150, smooth(clamp((t - 4.7) / 0.9))), lerp(1250, 1360, clamp((t - 4.7) / 0.9)))

def render(fi):
    t = fi / FPS
    cam = cam_at(t)
    img = np.zeros((OH, OW, 3), np.uint8)
    hall(img, cam)
    # glossy floor reflections (mirrored billboards, faded + blurred)
    before = img.copy()
    rv = VIS[min(fi, len(VIS) - 1)]
    def mirror(X, Z):
        Bd = board(img, cam, X, 0, Z); Bd.M = Bd.M @ np.array([[1, 0, 0], [0, -1, 0], [0, 0, 1]], float); return Bd
    for x, z in COLS:
        if z - cam.z > 80: column(mirror(x, z), 1700, 80)
    aL, aR = arms(t)
    human(mirror(0, 1500), 0, 0, 1.0, 'napoleon', face_fn=Face(timeline(EX, t), rv['v'], rv['open']), armL=aL, armR=aR, shadow_on=False)
    k = max(3, int(10 * S * 3) | 1)
    img[:] = cv2.addWeighted(before, 0.8, cv2.GaussianBlur(img, (k, k), 0), 0.2, 0)
    # depth-sorted billboards
    items = [(z, 'col', x) for x, z in COLS] + [(1500, 'nap', 0)]
    if t > 4.7: items.append((RAB_PATH(t)[1], 'rab', 0))
    items.sort(reverse=True)
    for z, kind, x in items:
        if z - cam.z < 60: continue
        if kind == 'col':
            floor_shadow(img, cam, x, z, 160, 60, 0, -120, 0.6)
            column(board(img, cam, x, 0, z), 1700, 80)
        elif kind == 'nap':
            v = VIS[min(fi, len(VIS) - 1)]
            P = timeline(EX, t)
            blink = any(0 <= t - b < 0.12 for b in BLINKS)
            aL, aR = arms(t)
            floor_shadow(img, cam, 0, 1500, 120, 50, 0, -160, 0.5)
            floor_shadow(img, cam, 0, 1500, 70, 26, 0, 0, 0.45)
            Bd = board(img, cam, 0, 0, 1500)
            talk = v['open']
            human(Bd, 0, 0, 1.0, 'napoleon', face_fn=Face(P, v['v'], v['open'], blink), armL=aL, armR=aR,
                  tilt=0.05 * math.sin(t * 2.6) + 0.04 * talk * math.sin(t * 9), lean=0.02 * math.sin(t * 1.7),
                  bob=3 * talk + (8 * math.exp(-(t - 4.8) * 6) if t > 4.8 else 0), shadow_on=False, brow=0)
        elif kind == 'rab':
            rx, rz = RAB_PATH(t)
            floor_shadow(img, cam, rx, rz, 55, 22, 0, 0, 0.5)
            hopping = t < 5.6
            rabbit(board(img, cam, rx, 0, rz), 0, 0, 0.75, -1, 0, 'hop' if hopping else 'sit', hop=(t * 2.2) % 1.0, face='open' if hopping else 'happy',
                   look=(-1, -1), shadow_on=False, ear=1.0, blink=False)
    # ---- look ----
    for wx, wy, wz in WINS:
        p, dz = cam.proj([(wx, wy, wz)])
        if dz[0] > 50:
            LK.god_rays(img, p[0][0], p[0][1], t, 0.12, (120, 200, 255), 8, 0.7, math.pi / 2 + 0.15, 1.2, abs(int(wx)))
    LK.key_light(img, -2.0, 0.22)
    LK.grade(img, 'warm', 1.12)
    LK.contrast(img, 1.06)
    LK.bloom(img, 225, 0.3)
    MOT.draw(img, t, cam.x / 3000, 0, (170, 225, 255), 0.9)
    vig(img)
    LK.grain(img, fi, 4)
    caption(img, t)
    return img

MOT = LK.Motes(70, 9)
_V = {}
def vig(img):
    if 'v' not in _V:
        y, x = np.mgrid[0:OH, 0:OW]; rr = np.sqrt(((x - OW / 2) / (OW / 2)) ** 2 + ((y - OH / 2) / (OH / 2)) ** 2)
        _V['v'] = (1 - 0.38 * np.clip(rr - 0.4, 0, 1) ** 1.3)[..., None].astype(np.float32)
    img[:] = (img * _V['v']).astype(np.uint8)

# ---------------- captions (same house style) ----------------
TIM = json.load(open(os.path.join(HERE, 'work/timing.json')))
def syl(w):
    if re.search(r'\d', w): return 4
    w = re.sub(r'[^a-z]', '', w.lower()); n = len(re.findall(r'[aeiouy]+', w))
    if w.endswith('e') and n > 1 and not w.endswith('le'): n -= 1
    return max(1, n)
KEY = {'napoleon', 'europe', 'bunnies', 'battle'}
CH = []
for a, b, txt in TIM:
    ws = txt.split(); ss = [syl(w) for w in ws]; tot = sum(ss); tt = a; wt = []
    for w, s_ in zip(ws, ss): wt.append((tt, w)); tt += (b - a) * s_ / tot
    i = 0
    while i < len(wt):
        n = 2 if i + 1 < len(wt) and not re.search(r'[,.?!]$', wt[i][1]) and len(wt[i][1]) + len(wt[i + 1][1]) < 14 else 1
        CH.append([wt[i][0], ' '.join(w for _, w in wt[i:i + n])]); i += n
    CH[-1].append(b + 0.25)
for i in range(len(CH)):
    if len(CH[i]) == 2: CH[i].append(CH[i + 1][0])
    CH[i][2] = min(CH[i][2], CH[i + 1][0] if i + 1 < len(CH) else 99)
def cap_text(img, txt, x, y, size, rgb, sc):
    spr = text_sprite(txt, int(size * S), rgb, 0.17); sh = spr.copy(); sh[..., :3] = 0
    k = max(3, int(14 * S) | 1); sh[..., 3] = cv2.GaussianBlur(sh[..., 3], (k, k), 0)
    blit(img, sh, x * S + 4 * S, y * S + 7 * S, sc, 0.7); blit(img, spr, x * S, y * S, sc)
def caption(img, t):
    for t0, txt, t1 in CH:
        if t0 - 0.03 <= t < t1:
            words = [re.sub(r"[^\w']", '', w.lower()) for w in txt.split()]
            disp = txt.upper().replace('…', '...').rstrip(',.')
            if any(w in KEY for w in words):
                u = (t - t0) / 0.22; sc = 0.6 + 0.6 * back(u, 2.6) if u < 1 else 1.2
                col = (255, 255, 255) if u < 0.4 else (255, 160, 40) if u < 0.7 else (255, 214, 64)
            else:
                sc = 0.7 + 0.3 * back((t - t0) / 0.15, 2.0); col = (255, 255, 255)
            cap_text(img, disp, 540, 1450, 92, col, sc); return

if __name__ == '__main__':
    mode = sys.argv[1]; out = sys.argv[2]; os.makedirs(out, exist_ok=True)
    if mode == 'stills':
        for tt in sys.argv[3].split(','):
            cv2.imwrite(f'{out}/s_{float(tt):05.2f}.jpg', render(int(round(float(tt) * FPS))))
    else:
        a, b = map(int, sys.argv[3].split('-'))
        for f in range(a, b + 1): cv2.imwrite(f'{out}/f{f:05d}.jpg', render(f), [cv2.IMWRITE_JPEG_QUALITY, 92])
