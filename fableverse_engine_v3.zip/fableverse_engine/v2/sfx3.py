"""v3 sound design kit: crisp, bright foley synthesis + ambience beds + ducked music.
Every action gets a sound; aim ~1 hit per 0.7 s; lots of 3-10 kHz detail (swishes, clinks, rustles)."""
import numpy as np, math, wave, subprocess
SR = 44100
rnd = np.random.default_rng(3)
def tt(d): return np.arange(int(SR * d)) / SR
def lp(x, k): k = max(1, int(k)); return np.convolve(x, np.ones(k) / k, 'same')
def hp(x, k): return x - lp(x, k)
def bp(x, lo_k, hi_k): return lp(hp(x, lo_k), hi_k)
def add(*xs):
    n = max(len(x) for x in xs); return sum(np.pad(x, (0, n - len(x))) for x in xs)
def nz(d): return rnd.standard_normal(int(SR * d))
def env(d, a=0.003, r=None, curve=4.0):
    t = tt(d); r = r or d
    return np.minimum(1, t / max(a, 1e-4)) * np.exp(-t / r * curve)
def place(buf, x, t, g=1.0, pan=0.0):
    i = int(t * SR)
    if i < 0 or i >= len(buf): return
    x = x[:len(buf) - i]; l = g * math.cos((pan + 1) * math.pi / 4); r = g * math.sin((pan + 1) * math.pi / 4)
    buf[i:i + len(x), 0] += x * l * 1.41; buf[i:i + len(x), 1] += x * r * 1.41

# ---- foley ----
def swish(d=0.28, bright=1.0):
    t = tt(d); e = np.sin(np.pi * t / d) ** 2
    x = bp(nz(d), 6, 2) * (0.6 + 0.4 * bright) + bp(nz(d), 30, 6) * 0.5
    return x * e * 0.7
def whoosh_cut(): return swish(0.22, 1.0) * 0.8
def tick(f=4200): t = tt(0.025); return (np.sin(2 * np.pi * f * t) + hp(nz(0.025), 2) * 0.6) * np.exp(-t * 260) * 0.7
def clink(f=2400):
    t = tt(0.6); x = sum(np.sin(2 * np.pi * f * m * t) * a * np.exp(-t * (8 + 4 * m)) for m, a in ((1, 1), (2.76, 0.6), (5.4, 0.35), (8.9, 0.2)))
    return (x + hp(nz(0.6), 2) * np.exp(-t * 120) * 0.5) * 0.4
def thump(f=90, d=0.25): t = tt(d); return (np.sin(2 * np.pi * f * t * (1 + 0.6 * np.exp(-t * 40))) * np.exp(-t * 22) + lp(nz(d), 4) * np.exp(-t * 60) * 0.5) * 0.9
def heel(): return add(thump(140, 0.15) * 0.6, tick(3000) * 0.5)
def rustle(d=0.35, dens=1.0):
    t = tt(d); x = hp(nz(d), 3) * (0.4 + 0.6 * (rnd.random(len(t)) < 0.02 * dens).astype(float).cumsum() % 2)
    return lp(x, 2) * np.sin(np.pi * t / d) * 0.35
def paper(d=0.4): t = tt(d); return (hp(nz(d), 3) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 13 * t)))) * np.sin(np.pi * t / d) * 0.4
def scratch_quill(d=0.7):
    t = tt(d); x = np.zeros_like(t)
    for k in np.arange(0, d - 0.04, 0.035 + 0.02 * rnd.random()):
        i = int(k * SR); seg = hp(nz(0.03), 2) * np.exp(-tt(0.03) * 60); x[i:i + len(seg)] += seg[:len(x[i:i + len(seg)])]
    return x * 0.5
def sniff(): t = tt(0.09); return bp(nz(0.09), 8, 3) * np.sin(np.pi * t / 0.09) * 0.5
def squeak(f0=1900, f1=2900, d=0.09):
    t = tt(d); f = np.linspace(f0, f1, len(t)); return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / d) * 0.3
def boing_small(): t = tt(0.3); return np.sin(2 * np.pi * np.cumsum(500 + 300 * np.sin(2 * np.pi * 14 * t) * np.exp(-t * 6)) / SR) * np.exp(-t * 10) * 0.5
def plip(): t = tt(0.12); return np.sin(2 * np.pi * np.cumsum(1800 - 900 * t / 0.12) / SR) * np.exp(-t * 30) * 0.5
def hop_thud(): return add(thump(120, 0.18) * 0.7, rustle(0.12) * 0.6)
def shock_hit():
    t = tt(1.2); brass = sum(np.sin(2 * np.pi * f * t + 0.3 * np.sin(2 * np.pi * f * 2 * t)) for f in (196, 247, 294, 392)) / 4
    return add(brass * np.exp(-t * 4) * 0.8, hp(nz(1.2), 2) * np.exp(-t * 3) * 0.4, thump(55, 0.5) * 0.9)
def stamp_impact():
    t = tt(0.7); return np.sin(2 * np.pi * (55 + 60 * np.exp(-t * 25)) * t) * np.exp(-t * 7) + lp(nz(0.7), 3) * np.exp(-t * 30) * 0.6 + hp(nz(0.7), 2) * np.exp(-t * 80) * 0.5
def squish(): t = tt(0.25); return lp(nz(0.25), 6) * np.sin(np.pi * t / 0.25) * np.sin(2 * np.pi * 30 * t) * 0.5
def sparkle():
    out = np.zeros(int(SR * 0.9))
    for k in range(6):
        c = clink(3000 + 600 * k) * 0.35; i = int(k * 0.06 * SR); out[i:i + len(c)] += c[:len(out) - i]
    return out
def creak(d=0.4):
    t = tt(d); f = 180 + 60 * np.sin(2 * np.pi * 1.5 * t); saw = ((np.cumsum(f) / SR) % 1.0) * 2 - 1
    return lp(saw * (np.sin(2 * np.pi * 26 * t) > 0), 3) * np.sin(np.pi * t / d) * 0.25
def pat(): return add(thump(200, 0.08) * 0.5, hp(nz(0.08), 3) * np.exp(-tt(0.08) * 60) * 0.4)
def riser(d=1.2): t = tt(d); return (bp(nz(d), 3, 2) * (t / d) ** 2 * 0.4 + np.sin(2 * np.pi * np.cumsum(300 + 900 * (t / d) ** 2) / SR) * (t / d) ** 3 * 0.15)
def gulp(): t = tt(0.22); return np.sin(2 * np.pi * np.cumsum(420 - 260 * t / 0.22) / SR) * np.exp(-t * 12) * 0.6
# ---- beds ----
def room_tone(d): t = tt(d); return lp(nz(d), 120) * 2.0 + hp(nz(d), 3) * 0.012
def candle(d):
    x = np.zeros(int(SR * d))
    for k in np.arange(0, d, 0.11):
        if rnd.random() < 0.5: c = hp(nz(0.01), 2) * 0.25; i = int((k + rnd.random() * 0.1) * SR); x[i:i + len(c)] += c[:len(x) - i] if i < len(x) else 0
    return x
def birds(d, n=4):
    x = np.zeros(int(SR * d))
    for k in range(n):
        tb = tt(0.22); f = 3000 + rnd.uniform(-400, 600) + 900 * np.sin(2 * np.pi * 14 * tb) * np.exp(-tb * 6)
        c = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * tb / 0.22) ** 2 * 0.12
        i = int(rnd.uniform(0, max(0.01, d - 0.3)) * SR); x[i:i + len(c)] += c
    return x
def water(d): t = tt(d); return lp(nz(d), 30) * 1.2 + hp(nz(d), 4) * 0.03 * (1 + np.sin(2 * np.pi * 0.7 * t))
def crickets(d): t = tt(d); return np.sin(2 * np.pi * 4300 * t) * (np.sin(2 * np.pi * 30 * t) > 0.4) * (np.sin(2 * np.pi * 2 * t) > 0) * 0.06

# ---- music ----
def pizz(f, d=0.3): t = tt(d); return sum(np.sin(2 * np.pi * f * m * t) * a * np.exp(-t * (16 + 6 * m)) for m, a in ((1, 1), (2, 0.45), (3, 0.2))) * 0.5
def pad(fs, d):
    t = tt(d); x = sum(np.sin(2 * np.pi * f * t * (1 + 0.002 * np.sin(2 * np.pi * 0.3 * t + i))) for i, f in enumerate(fs)) / len(fs)
    return x * np.minimum(1, np.minimum(t / 0.4, (d - t) / 0.4)) * 0.35
NOTE = lambda n: 440 * 2 ** ((n - 69) / 12)

def load_voice(path, n):
    v = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True).stdout, np.float32).astype(np.float64)
    return np.pad(v, (0, max(0, n - len(v))))[:n]

def duck(music, voice, depth=0.55, att=0.02, rel=0.25):
    e = np.abs(voice); e = lp(e, int(SR * 0.03)); e = e / (e.max() + 1e-9)
    g = 1 - depth * np.clip(e * 4, 0, 1)
    out = np.zeros_like(g); a = math.exp(-1 / (att * SR)); r = math.exp(-1 / (rel * SR)); cur = 1.0
    gs = g[::64]; sm = np.zeros_like(gs)
    for i, v in enumerate(gs):
        k = math.exp(-64 / (att * SR)) if v < cur else math.exp(-64 / (rel * SR)); cur = v + (cur - v) * k; sm[i] = cur
    out = np.interp(np.arange(len(g)), np.arange(len(sm)) * 64, sm)
    return music * out[:, None]

def write(fn, x, norm=0.9):
    w = wave.open(fn, 'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    x = x / (np.abs(x).max() + 1e-9) * norm; w.writeframes((x * 32767).astype(np.int16).tobytes()); w.close()
