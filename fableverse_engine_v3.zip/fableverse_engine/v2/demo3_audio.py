import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sfx3 import *
D = 10.0; N = int(SR * D)
fx = np.zeros((N, 2)); bed = np.zeros((N, 2)); mus = np.zeros((N, 2))
P = place
cuts = [1.25, 2.30, 2.92, 4.25, 4.80, 5.95, 6.64, 7.90, 8.80]
for c in cuts: P(fx, whoosh_cut(), c - 0.12, 0.5)
# S1 hat macro
P(bed, room_tone(2.3), 0.0, 0.5); P(bed, candle(1.25), 0.0, 0.6, -0.4)
P(fx, thump(110, 0.25), 0.05, 0.6); P(fx, clink(2600), 0.08, 0.25, 0.3); P(fx, riser(1.1), 0.1, 0.35)
# S2 hero
P(fx, heel(), 1.3, 0.7, -0.1); P(fx, swish(0.25), 1.68, 0.5, 0.3); P(fx, rustle(0.3), 1.7, 0.5, 0.3)
for f in (NOTE(55), NOTE(59), NOTE(62), NOTE(67)): P(mus, pad([f], 1.1), 1.25, 0.5)
# S3 map
P(fx, paper(0.45), 2.32, 0.7); P(fx, bp(nz(0.55), 4, 2) * np.linspace(0, 1, int(SR * 0.55)) * 0.3, 2.35, 0.6, 0.2)
# S4 smug -> worried
P(bed, room_tone(1.4), 2.92, 0.4)
P(fx, tick(3600), 3.67, 0.6, 0.4); P(fx, gulp(), 3.75, 0.6); P(fx, swish(0.2), 3.67, 0.4, 0.4); P(fx, plip(), 3.95, 0.5, 0.5)
# S5 bunny
P(bed, birds(0.6, 2), 4.25, 0.8); P(fx, rustle(0.4, 2), 4.25, 0.5, -0.3)
for k in (4.32, 4.4, 4.48): P(fx, sniff(), k, 0.5)
P(fx, boing_small(), 4.52, 0.5)
# S6 reveal
P(fx, hop_thud(), 4.83, 0.7, 0.5); P(fx, hop_thud(), 5.03, 0.7, 0.3); P(fx, squeak(), 4.95, 0.4, 0.4)
P(fx, shock_hit(), 4.88, 0.9); P(fx, swish(0.3), 4.86, 0.6)
# S7 deadpan
P(bed, crickets(0.7), 5.95, 0.8); P(fx, tick(5200), 6.3, 0.4); P(fx, plip(), 6.1, 0.4, 0.5)
# S8 Tilsit
P(bed, water(1.26), 6.64, 0.6); P(bed, birds(1.2, 3), 6.64, 0.7); P(fx, creak(0.4), 6.8, 0.5, -0.3)
P(fx, swish(0.25), 7.03, 0.5, -0.2); P(fx, swish(0.25), 7.05, 0.5, 0.2); P(fx, pat(), 7.32, 0.6)
# S9 quill
P(bed, room_tone(2.1), 7.9, 0.4); P(fx, scratch_quill(0.7), 7.92, 0.8, 0.2); P(fx, tick(3000), 8.62, 0.4)
# S10 handshake + seal
for k in (8.85, 9.0, 9.15): P(fx, pat(), k, 0.7)
P(fx, swish(0.18), 9.3, 0.5); P(fx, stamp_impact(), 9.42, 1.0); P(fx, squish(), 9.44, 0.6); P(fx, sparkle(), 9.5, 0.5)
# music: light pizzicato bed, ducked
beat = 60 / 112; t = 6.64; k = 0
mel = [72, 76, 79, 76, 74, 77, 81, 77]
while t < 9.4:
    P(mus, pizz(NOTE(48 if k % 2 == 0 else 55)), t, 0.6, -0.2); P(mus, pizz(NOTE(mel[k % 8])), t, 0.45, 0.25); t += beat; k += 1
for f in (NOTE(60), NOTE(64), NOTE(67), NOTE(72)): P(mus, pad([f], 0.9), 9.42, 0.55)
voice = load_voice(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'work/voice.mp3'), N)
mus = duck(mus, voice, 0.6)
v2 = np.stack([voice, voice], 1)
def rms(x): m = x.mean(1); m = m[np.abs(m) > 1e-4]; return np.sqrt((m ** 2).mean()) if len(m) else 1
rv = rms(v2)
mus *= 0.42 * rv / rms(mus); fx *= 0.62 * rv / rms(fx); bed *= 0.22 * rv / rms(bed)
out = v2 + mus + fx + bed
write('work/demo3_mix.wav', out, 0.95)
print('ok')
