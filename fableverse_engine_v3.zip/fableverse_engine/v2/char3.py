"""v3 'toon' characters for FableVerse: original simple designs.
White egg-shaped heads, very thick ink outlines, dot eyes with expressive lids & brows,
thin tube limbs, one strong outfit colour + a signature hat. No lip sync: mouths are
expression shapes only (narration-driven acting).

toon(d, x, y, sc, who, P=expr(...), pose=dict(...))
  pose keys: aL, aR (deg, len), elL, elR (elbow bend deg), lean, tilt (head), bob, step, squash, look
"""
import math, numpy as np
from rig import C, INK, shade, bez, lerp, clamp, Aff, shadow, GOLD
from face import expr, BASE

OL = 8.0          # outline weight (thick, like premium toon shorts)
HEAD = C('fbf9f4'); HEADS = C('e6e2da')

WHO = {
    'napoleon': dict(coat=C('2d4594'), coat2=C('22356f'), pants=C('f2eee4'), boots=C('1d1a1f'), hat='bicorne', trim=C('f4f1ea'),
                     epaul=True, hair=True),
    'tsar':     dict(coat=C('eef0f3'), coat2=C('cfd3db'), pants=C('2f4a3a'), boots=C('1d1a1f'), hat='plume', trim=C('3f78c8'), sash=C('3f78c8'), epaul=True),
    'berthier': dict(coat=C('263a78'), coat2=C('1c2c5c'), pants=C('f2eee4'), boots=C('1d1a1f'), hat='bicorne_w', trim=C('e3b84a'), sash=C('c8323a'), tache=True),
    'hunter':   dict(coat=C('3f6b3c'), coat2=C('2f5230'), pants=C('d8c9a2'), boots=C('4a3324'), hat='tricorne', trim=C('c8a04a')),
    'farmer':   dict(coat=C('5a7fb8'), coat2=C('46679a'), pants=C('7a5a3a'), boots=C('4a3324'), hat='straw', trim=C('e8dcc0')),
}

def tube(d, pts, w, col):
    d.line(pts, INK, w + 2 * OL * 0.75)
    for p in (pts[0], pts[-1]): d.dot(p[0], p[1], (w + 2 * OL * 0.75) / 2, INK)
    d.line(pts, col, w)
    for p in (pts[0], pts[-1]): d.dot(p[0], p[1], w / 2, col)

def limb2(d, a, ang, ln, bend, w, col):
    r = math.radians(ang); r2 = math.radians(ang + bend)
    e = (a[0] + math.sin(r) * ln * 0.5, a[1] + math.cos(r) * ln * 0.5)
    h = (e[0] + math.sin(r2) * ln * 0.5, e[1] + math.cos(r2) * ln * 0.5)
    tube(d, [a, e, h], w, col)
    return h

def egg(d, cx, cy, rx, ry):
    return [(cx + math.cos(a) * rx * (1 - 0.08 * math.sin(a)), cy + math.sin(a) * ry * (1.0 if math.sin(a) > 0 else 1.05)) for a in np.linspace(0, 2 * math.pi, 48, endpoint=False)]

def face3(Hh, P, blink=False, mouth=None):
    lx, ly = P['look']
    for side in (-1, 1):
        cx, cy = side * 21, 2
        li = 1.0 if blink else P['lid'][0 if side < 0 else 1]
        lo = P['low'][0 if side < 0 else 1]
        ry = 11 * (1 + 0.25 * P.get('shock', 0))
        # dot eye
        ex, ey = cx + lx * 5, cy + ly * 5
        Hh.ell(ex, ey, 7.5 * (0.75 if P['shock'] > 0.5 else 1), ry * (0.75 if P['shock'] > 0.5 else 1), C('17121a'), None, 0)
        Hh.dot(ex + 2.5, ey - 4, 2.2, (255, 255, 255))
        # upper lid: a head-coloured cap that slides down + thick lid line
        if li > 0.05:
            yl = lerp(cy - ry - 3, cy + ry, li)
            Hh.poly([(cx - 14, cy - ry - 8), (cx + 14, cy - ry - 8), (cx + 14, yl), (cx - 14, yl)], HEAD, None)
            Hh.line([(cx - 13, yl + 1), (cx + 13, yl + 1)], INK, 4.5)
        if lo > 0.05:
            yb = lerp(cy + ry + 3, cy, lo)
            Hh.poly([(cx - 14, cy + ry + 8), (cx + 14, cy + ry + 8), (cx + 14, yb), (cx - 14, yb)], HEAD, None)
            Hh.line(bez((cx - 11, yb), (cx, yb - 3), (cx + 11, yb), 6), INK, 3.5)
        # brow
        r = P['brow'][0 if side < 0 else 1]; a = P['bang'][0 if side < 0 else 1]
        by = cy - 24 - r * 9
        Hh.line([(cx - side * 12, by + a * 6), (cx + side * 12, by - a * 4)], INK, 6)
    sm = P['smile']; my = 40
    m = mouth or ('o' if P['shock'] > 0.5 else 'grit' if (sm < -0.55 and P['bang'][0] > 0.5) else 'line')
    if m == 'o':
        Hh.ell(0, my + 4, 8, 11, C('3a1820'), INK, 4)
    elif m == 'grit':
        Hh.poly([(-16, my - 5), (16, my - 5), (14, my + 6), (-14, my + 6)], (252, 250, 247), INK, 4)
        Hh.line([(-15, my), (15, my)], INK, 2.5)
    elif m == 'grin':
        Hh.poly(list(bez((-18, my - 4), (0, my + 20), (18, my - 4), 12)), C('3a1820'), INK, 4)
        Hh.poly([(-14, my - 3), (14, my - 3), (11, my + 2), (-11, my + 2)], (252, 250, 247), None)
    else:
        Hh.line(bez((-14, my - sm * 5), (0, my + sm * 7), (14, my - sm * 5), 10), INK, 4.5)
    if P['sweat'] > 0.3:
        Hh.poly([(58, -36), (67, -16), (58, -10), (50, -16)], C('9fd8ff'), INK, 3)
    if P.get('tears', 0) > 0.3:
        for s_ in (-1, 1): Hh.poly([(s_ * 22, 16), (s_ * 26, 30), (s_ * 22, 35), (s_ * 18, 30)], C('9fd8ff'), INK, 2.5)
    if P['shock'] > 0.5:
        for k in range(3):
            a_ = -2.2 + k * 0.4
            Hh.line([(math.cos(a_) * 82, math.sin(a_) * 92 - 10), (math.cos(a_) * 104, math.sin(a_) * 114 - 10)], INK, 5)

def hat3(Hh, kind, o):
    if kind in ('bicorne', 'bicorne_w', 'plume'):
        hb = C('1c1a22')
        pts = list(bez((-118, -58), (-74, -168), (0, -146), 14)) + list(bez((0, -146), (74, -168), (118, -58), 14)) + list(bez((118, -58), (0, -90), (-118, -58), 16))
        Hh.poly(pts, hb, INK, OL)
        Hh.line(bez((-100, -68), (0, -96), (100, -68), 14), C('3a3644'), 4)
        if kind == 'bicorne_w': Hh.line(bez((-108, -64), (0, -94), (108, -64), 16), C('f4f1ea'), 9)
        if kind == 'plume':
            for k in range(-3, 4): Hh.ell(k * 20, -150 + abs(k) * 5, 15, 12, C('f4f1ea'), INK, 3)
        Hh.ell(64, -104, 14, 14, C('2b4aa8'), INK, 3); Hh.ell(64, -104, 9, 9, C('f4f1ea'), None, 0); Hh.ell(64, -104, 4.5, 4.5, C('d9323a'), None, 0)
    elif kind == 'tricorne':
        Hh.poly([(-96, -60), (-62, -120), (0, -106), (62, -120), (96, -60), (0, -78)], C('3a2a1e'), INK, OL)
        Hh.line([(-90, -64), (0, -82), (90, -64)], o['trim'], 4)
    elif kind == 'straw':
        Hh.ell(0, -64, 100, 18, C('e8c35a'), INK, OL)
        Hh.poly([(-48, -66), (48, -66), (38, -116), (-38, -116)], C('e8c35a'), INK, OL * 0.8)
        Hh.poly([(-48, -70), (48, -70), (46, -82), (-46, -82)], C('d94b3c'), None)

def toon(d, x, y, sc, who='napoleon', P=None, pose=None, blink=False, mouth=None, shadow_on=True, flip=1):
    o = WHO[who]; P = P or dict(BASE); pz = pose or {}
    aL = pz.get('aL', (25, 120)); aR = pz.get('aR', (-25, 120))
    elL = pz.get('elL', 0); elR = pz.get('elR', 0)
    lean = pz.get('lean', 0.0); tilt = pz.get('tilt', 0.0); bob = pz.get('bob', 0.0); step = pz.get('step', 0.0)
    sq = pz.get('squash', 0.0)
    if shadow_on: shadow(d.sub(Aff(x, y, sc)), 0, 2, 70, 15, 0.5)
    G = d.sub(Aff(x, y - bob * sc, sc, 0, flip)).sub(np.array([[1 + sq * 0.5, 0, 0], [0, 1 - sq, 0], [0, 0, 1]], float))
    st = math.sin(step) * 22 if step else 0
    # legs (thin)
    for side, ph in ((-1, st), (1, -st)):
        hx = side * 16; fx = side * 18 + ph; fy = -abs(ph) * 0.3
        tube(G, [(hx, -112), (fx * 0.9, -58 + fy * 0.5), (fx, -10 + fy)], 17, o['pants'])
        tube(G, [(fx * 0.95, -50 + fy * 0.6), (fx, -10 + fy)], 20, o['boots'])
        G.ell(fx + 9, -6 + fy, 20, 10, o['boots'], INK, OL * 0.7)
    B = G.sub(Aff(0, -110, 1, lean))
    # back arm
    hR = limb2(B, (-30, -88), aR[0], aR[1], elR, 15, o['coat2'])
    B.ell(hR[0], hR[1], 12, 12, HEAD, INK, OL * 0.65)
    # torso: compact rounded coat
    body = [(-40, 4), (-44, -40), (-38, -86), (-26, -100), (26, -100), (38, -86), (44, -40), (40, 4)]
    B.poly(body, o['coat'], INK, OL)
    B.poly([(14, -96), (28, -96), (40, -60), (40, 0), (22, 0)], o['coat2'], None)   # self-shade
    B.poly(body, None, INK, OL)
    B.poly([(-10, -98), (10, -98), (8, 2), (-8, 2)], o['trim'], INK, 3)
    for yy in (-74, -50, -26): B.dot(0, yy, 3, GOLD)
    if o.get('sash'): B.poly([(-38, -88), (-24, -96), (40, -18), (36, -4)], o['sash'], INK, 3)
    if o.get('epaul'):
        for s_ in (-1, 1): B.ell(s_ * 34, -94, 16, 8, GOLD, INK, 3)
    B.poly([(-42, -14), (42, -14), (42, -2), (-42, -2)], C('f2eee4') if who == 'napoleon' else C('4a3a2a'), INK, 3)
    # front arm
    hL = limb2(B, (30, -88), aL[0], aL[1], elL, 15, o['coat'])
    B.ell(hL[0], hL[1], 12, 12, HEAD, INK, OL * 0.65)
    if pz.get('prop'): pz['prop'](B, hL, hR)
    # head (egg) sits right on the collar
    Hh = B.sub(Aff(0, -176, 1, tilt))
    eg = egg(Hh, 0, 0, 64, 78)
    Hh.poly(eg, HEADS, INK, OL)
    Hh.poly(egg(Hh, -7, -3, 56, 72), HEAD, None)                                   # crescent self-shade on the right
    Hh.poly(eg, None, INK, OL)
    if o.get('hair'):
        Hh.poly([(-34, -62), (30, -66), (12, -48), (2, -56), (-10, -44), (-20, -56), (-36, -50)], C('2a1e1a'), INK, 3)
    if o.get('tache'):
        Hh.poly([(-22, 30), (-6, 24), (0, 27), (6, 24), (22, 30), (12, 34), (0, 30), (-12, 34)], C('3a2a22'), INK, 2.5)
    face3(Hh, P, blink, mouth)
    hat3(Hh, o['hat'], o)
    return hL, hR

def track(keys, t, snap=0.12):
    """snappy pose track: hold each pose, move to next in `snap` seconds with overshoot."""
    cur = keys[0][1]
    for i in range(1, len(keys)):
        tk, ps = keys[i]
        if t >= tk:
            u = clamp((t - tk) / snap)
            u = 1 + 2.4 * (u - 1) ** 3 + 1.4 * (u - 1) ** 2 if u < 1 else 1.0   # back-ease overshoot
            prev = keys[i - 1][1]
            out = {}
            for k in set(prev) | set(ps):
                a = prev.get(k, ps.get(k)); b = ps.get(k, a)
                if isinstance(a, tuple): out[k] = tuple(lerp(p, q, u) for p, q in zip(a, b))
                elif isinstance(a, (int, float)): out[k] = lerp(a, b, u)
                else: out[k] = b
            cur = out
    return cur
